Modification Originally by Snowshoelceboot, code copied from there.
Credit to Mojang for developing the code for Minecraft b1.8, 

Ported to NFC b1.8.5_01 by Logan