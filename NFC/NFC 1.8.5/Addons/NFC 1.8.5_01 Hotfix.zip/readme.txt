Features:

- Fixes broken NFC recipes (Gem Hats & Osmium Armor)
- Fixes broken Osmium textures & names