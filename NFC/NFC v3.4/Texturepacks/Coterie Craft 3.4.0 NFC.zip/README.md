# Coterie Craft by Cpt_Corn for NFC

Supports Panorama, Water Biome Colors (optional) and Bottom Chest Texture addons.

**Download versions:**

* [NFC v3.4.0](../Coterie%20Craft%203.4.0%20nfc.zip)
* [NFC v3.3.2](../Coterie%20Craft%203.3.2%20nfc.zip) *(also supports [JalC](../../mods/Just%20a%20little%20Cyrillic.zip) addon, which is not required for newer versions)*

[![Coterie Craft](https://i.imgur.com/nggoe4M.png)](https://newfrontiercraft.net/thread/131/coterie-craft-cpt-corn-nfc "Click to see more screenshots")

Originally by Cpt_Corn:

* [Original resource packs website](https://coteriecraft.net/downloads/)

* [Original resource packs Planet Minecraft](https://www.planetminecraft.com/texture-pack/16x-beta-17_01-coterie-craft-v16-regular-upd-6302011/)

* [Original resource packs Minecraft Forums](https://www.minecraftforum.net/forums/mapping-and-modding-java-edition/resource-packs/1223548-32x-16x-coterie-craft-default-revamped)
