This reverts code we added in NFC 1.8.7 which made it 
possible to view water through translucent blocks. AMD
broke our code and is making clients crash, so this reverts
the code to what it was in Vanilla Beta 1.7.3. We'll come
up with a better solution in the future

3rd times the charm