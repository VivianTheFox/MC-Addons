INSTALLATION INSTRUCTIONS :
- Open minecraft.jar with an archive editor (7zip, winrar, etc...)
- extract the mod inside the jar file
- delete folder META-INF from the jar file
- enjoy ! :)


This mod has been created by Spychopat
Here is my Steam profile if you want to contact me :
https://steamcommunity.com/profiles/76561197991952155


Playing any game in first person with mouse acceleration feels really bad !
But we don't want to disable mouse acceleration from Windows,
it's nice to have when moving the cursor around.
I've thinkered a lot to make this mod ! It is really simple, but believe me : 
i suffered ! ahah (one and half a day, but also trying other little things)
In the end, i'm really happy i have made it work, i was about to give up.
And also, i think i did a pretty clean job, there should not be any performance
impact (no infinite loop, multi thread, or stuff like that ahah)


The mod has been made for Minecraft Beta 1.7.3
but it should work with pretty much all older versions of Minecraft

Happy Minecrafting ! :)
