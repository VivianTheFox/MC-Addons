Fixes issue with v3.5.0 where ModLoader grabs wrong variable from StringTranslate
Fix will be native part of v3.5.1