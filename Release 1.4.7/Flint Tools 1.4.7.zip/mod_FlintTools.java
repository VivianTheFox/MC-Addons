package net.minecraft.src;

public class mod_FlintTools extends BaseMod {

	public mod_FlintTools()
	{
		//Flint Pickaxe
		FlintPick = (new ItemPickaxe(30000, EnumToolMaterial.STONE)).setItemName("FlintPick");
		FlintPick.iconIndex = ModLoader.addOverride("/gui/items.png", "/ft/FlintPick.png");
		ModLoader.addName(FlintPick, "Flint Pickaxe");
		ModLoader.addRecipe(new ItemStack(FlintPick), new Object[] 
		{
				"XXX", " # ", " # ", Character.valueOf('#'), Item.stick, Character.valueOf('X'), Item.flint
		});
		
		//Flint Shovel
		FlintShovel = (new ItemSpade(30001, EnumToolMaterial.STONE)).setItemName("FlintShovel");
		FlintShovel.iconIndex = ModLoader.addOverride("/gui/items.png", "/ft/FlintShovel.png");
		ModLoader.addName(FlintShovel, "Flint Shovel");
		ModLoader.addRecipe(new ItemStack(FlintShovel), new Object[] 
		{
				"X", "#", "#", Character.valueOf('#'), Item.stick, Character.valueOf('X'), Item.flint
		});

		//Flint Axe
		FlintAxe = (new ItemAxe(30002, EnumToolMaterial.STONE)).setItemName("FlintAxe");
		FlintAxe.iconIndex = ModLoader.addOverride("/gui/items.png", "/ft/FlintAxe.png");
		ModLoader.addName(FlintAxe, "Flint Axe");
		ModLoader.addRecipe(new ItemStack(FlintAxe), new Object[] 
		{
				"XX", "X#", " #", Character.valueOf('#'), Item.stick, Character.valueOf('X'), Item.flint
		});

		//Flint Sword
		FlintSword = (new ItemSword(30003, EnumToolMaterial.STONE)).setItemName("FlintSword");
		FlintSword.iconIndex = ModLoader.addOverride("/gui/items.png", "/ft/FlintSword.png");
		ModLoader.addName(FlintSword, "Flint Sword");
		ModLoader.addRecipe(new ItemStack(FlintSword), new Object[] 
		{
				"X", "X", "#", Character.valueOf('#'), Item.stick, Character.valueOf('X'), Item.flint
		});
		
		//Flint Hoe
		FlintHoe = (new ItemHoe(30004, EnumToolMaterial.STONE)).setItemName("FlintHoe");
		FlintHoe.iconIndex = ModLoader.addOverride("/gui/items.png", "/ft/FlintHoe.png");
		ModLoader.addName(FlintHoe, "Flint Hoe");
		ModLoader.addRecipe(new ItemStack(FlintHoe), new Object[] 
		{
				"XX", " #", " #", Character.valueOf('#'), Item.stick, Character.valueOf('X'), Item.flint
		});
	}
	
	public String getVersion() {
		return "1.0";
	}
	
	public void load() {
		return;
	}
	
	public Item FlintPick;
	public Item FlintShovel;
	public Item FlintAxe;
	public Item FlintSword;
	public Item FlintHoe;
}
