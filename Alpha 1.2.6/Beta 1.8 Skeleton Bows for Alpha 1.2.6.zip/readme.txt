gu.class (ModelSkeleton) enables the Beta 1.8 bow holding, with both arms touching in the bow
m.class (RenderBiped) tweaks the held model for bows in skeletons to the Beta 1.8 variant

Both features are optional, and if you want one feature but not the other you can just remove the class file.
This mod has no effect on player held bows.