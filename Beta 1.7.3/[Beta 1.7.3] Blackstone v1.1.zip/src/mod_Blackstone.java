package net.minecraft.src;

import java.util.Random;

public class mod_Blackstone extends BaseMod {

	public static final Block blackstone = (new BlockBlackstone(217, 1)).setHardness(1.5F).setResistance(10F).setBlockName("blackstone");
	public static final Block blackstonePolished = (new Block(218, Material.rock)).setHardness(2.0F).setResistance(10F).setBlockName("blackstonePolished");
	public static final Block blackstonePolishedBricks = (new Block(219, Material.rock)).setHardness(2.0F).setResistance(10F).setBlockName("blackstonePolishedBricks");
	public static final Block blackstonePolishedBricksCracked = (new Block(220, Material.rock)).setHardness(2.0F).setResistance(10F).setBlockName("blackstonePolishedBricksCracked");
	
	public mod_Blackstone()
	{
		initBlocks();
		initRecipes();
	}
	
	public static void initBlocks()
    {
		ModLoader.RegisterBlock(blackstone);
		ModLoader.RegisterBlock(blackstonePolished);
		ModLoader.RegisterBlock(blackstonePolishedBricks);
		ModLoader.RegisterBlock(blackstonePolishedBricksCracked);
		
		//blackStone.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/blackStone/blackstone.png");
		blackstonePolished.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/blackstone/polished_blackstone.png");
		blackstonePolishedBricks.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/blackstone/polished_blackstone_bricks.png");
		blackstonePolishedBricksCracked.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/blackstone/cracked_polished_blackstone_bricks.png");
		
		ModLoader.AddName(blackstone, "Blackstone");
		ModLoader.AddName(blackstonePolished, "Polished Blackstone");
		ModLoader.AddName(blackstonePolishedBricks, "Polished Blackstone Bricks");
		ModLoader.AddName(blackstonePolishedBricksCracked, "Cracked Polished Blackstone Bricks");
    }

	public static void initRecipes()
	{
		ModLoader.AddSmelting(Block.stone.blockID, new ItemStack(blackstone));
		
		ModLoader.AddShapelessRecipe(new ItemStack(blackstonePolished, 1), new Object[] {
				blackstone
		    });
		ModLoader.AddRecipe(new ItemStack(blackstonePolishedBricks, 4), new Object[] {
				"XX ", "XX ", 'X', blackstonePolished
		    });
		
		ModLoader.AddSmelting(blackstonePolishedBricks.blockID, new ItemStack(blackstonePolishedBricksCracked));
	}
		
	public String Version() {
		return "1.1";
	}
	
}
