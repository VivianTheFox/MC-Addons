This version of NFC requires Optifine to be installed.

Update History:

Pre4-1.8.4:
Fixed Texture for Blocks: Lead, Saph, platinum
Fixed Boron, Bismuth, Brass image position
Fixed Music Disc, zinc, hot/rusty ingot images
Added "Ingot" to the ingots' names
Added new skin system

Pre3-1.8.4 and before: Not properly documented yet