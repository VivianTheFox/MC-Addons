package net.minecraft.src;

import net.minecraft.src.forge.ITextureProvider;

import java.util.Random;

public class BlockFlopper extends BlockDispenser implements ITextureProvider {

    protected BlockFlopper(int i, int j, boolean bigFlopperMode) {
        super(i);
        blockIndexInTexture = !bigFlopperMode ? j - 2 : j;
        this.bigFlopperMode = bigFlopperMode;
    }

    public String getTextureFile()
    {
        return "/flopperMod/flopperTerrain.png";
    }
    public int idDropped(int i, Random random) {
        return this.blockID;
    }

    public boolean blockActivated(World world, int i, int j, int k, EntityPlayer entityplayer)
    {
        if(!world.multiplayerWorld)
        {
            TileEntityDispenser tileentitydispenser = (TileEntityDispenser) world.getBlockTileEntity(i, j, k);
            GuiScreen guiChooser = !bigFlopperMode ? new GuiFlopper(entityplayer.inventory, tileentitydispenser) : new GuiFlopperBig(entityplayer.inventory, tileentitydispenser);
            ModLoader.OpenGUI(entityplayer, guiChooser);
        }
        return true;
    }

    private void dispenseItem(World world, int i, int j, int k, Random random) {
        int l = world.getBlockMetadata(i, j, k);
        int i1 = 0;
        int j1 = 0;
        if (l == 3) {
            j1 = 1;
        } else if (l == 2) {
            j1 = -1;
        } else if (l == 5) {
            i1 = 1;
        } else {
            i1 = -1;
        }
        TileEntityDispenser tileentitydispenser = (TileEntityDispenser) world.getBlockTileEntity(i, j, k);
        ItemStack itemstack = tileentitydispenser.getRandomStackFromInventory();
        double d = (double) i + (double) i1 * 0.59999999999999998D + 0.5D;
        double d1 = (double) j + 0.5D;
        double d2 = (double) k + (double) j1 * 0.59999999999999998D + 0.5D;

        ItemStack twoFishCheck = itemstack != null && bigFlopperMode ? new ItemStack(Item.fishRaw, 2, 1) : new ItemStack(Item.fishRaw,1, 1);
        EntityItem entityitem = new EntityItem(world, d,
                d1 - 0.29999999999999999D, d2, twoFishCheck);

        if(itemstack == null && !bigFlopperMode)
        {
            world.func_28106_e(1001, i, j, k, 0);
            return;
        }
        double d3 = random.nextDouble() * 0.10000000000000001D + 0.20000000000000001D;
        entityitem.motionX = (double) i1 * d3;
        entityitem.motionY = 0.20000000298023221D;
        entityitem.motionZ = (double) j1 * d3;
        entityitem.motionX += random.nextGaussian() * 0.0074999998323619366D * 6D;
        entityitem.motionY += random.nextGaussian() * 0.0074999998323619366D * 6D;
        entityitem.motionZ += random.nextGaussian() * 0.0074999998323619366D * 6D;
        world.entityJoinedWorld(entityitem);
        world.func_28106_e(1000, i, j, k, 0);
        world.func_28106_e(2000, i, j, k, i1 + 1 + (j1 + 1) * 3);
    }

    public void updateTick(World world, int i, int j, int k, Random random) {
        if (world.isBlockIndirectlyGettingPowered(i, j, k)
                || world.isBlockIndirectlyGettingPowered(i, j + 1, k)) {
            dispenseItem(world, i, j, k, random);
        }
    }

    boolean bigFlopperMode;
}
