package net.minecraft.src;

import net.minecraft.client.Minecraft;
import net.minecraft.src.forge.ITextureProvider;

import java.io.*;

public class mod_Flopper extends BaseMod {

    File configFile;
    public int flopperID;
    public int flopperBigID;

    public mod_Flopper() {
        configFile = new File(Minecraft.getMinecraftDir(), "configFlopper.txt");
        loadConfig();

        Block bigFlopperMaterial = mod_Flopper.nmsClassExists("NFC") ? NFC.osmiumblock : Block.blockDiamond;

        Block flopper = (new BlockFlopper(flopperID, 45, false)).setHardness(3.5F)
                .setStepSound(Block.soundStoneFootstep).setBlockName("flopper")
                .disableNeighborNotifyOnMetadataChange();
        Block flopperBig = (new BlockFlopper(flopperBigID, 45, true)).setHardness(3.5F)
                .setStepSound(Block.soundStoneFootstep).setBlockName("flopperBig")
                .disableNeighborNotifyOnMetadataChange();

        ModLoader.RegisterBlock(flopper);
        ModLoader.RegisterBlock(flopperBig);

        ModLoader.AddName(flopper, "Flopper");
        ModLoader.AddName(flopperBig, "Big Flopper");
        ModLoader.AddLocalization("gui.flopper", "Flopper");
        ModLoader.AddLocalization("gui.flopperBig", "Big Flopper");

        ModLoader.AddRecipe(new ItemStack(flopper, 1), new Object[]{
                "###", "#X#", "#R#", Character.valueOf('#'), Block.cobblestone, Character.valueOf('X'), Item.fishRaw, Character.valueOf('R'), Item.redstone
        });
        ModLoader.AddRecipe(new ItemStack(flopperBig, 1), new Object[]{
                "###", "#X#", "###", Character.valueOf('#'), bigFlopperMaterial, Character.valueOf('X'), flopper
        });
    }

    public void loadConfig() {
        try {
            if (!configFile.exists()) {
                System.out.println("flopperConfig.txt not found, generating");
                PrintWriter printwriter = new PrintWriter(new FileWriter(configFile));
                printwriter.println("flopperID:" + 215);
                printwriter.println("flopperBigID:" + 216);
                printwriter.close();
            }

            System.out.println("flopperConfig.txt\n===========");

            BufferedReader bufferedreader = new BufferedReader(new FileReader(configFile));
            for (String s = ""; (s = bufferedreader.readLine()) != null; ) {
                String as[] = s.split(":");
                if (as[0].equals("flopperID")) {
                    flopperID = Integer.parseInt(as[1]);
                    System.out.println(s);
                }
                if (as[0].equals("flopperBigID")) {
                    flopperBigID = Integer.parseInt(as[1]);
                    System.out.println(s);
                }
            }
            System.out.println("===========");
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //Credit to Rek for this code
    public static boolean classExists(String className) {
        try {
            Class.forName(className);
        }
        catch (ClassNotFoundException e) {
            return false;
        }
        return true;
    }

    public static boolean nmsClassExists(String className) {
        return classExists(className) || classExists("net.minecraft.src." + className);
    }
    //

    public String Version() {
        return "v1.0";
    }


}
