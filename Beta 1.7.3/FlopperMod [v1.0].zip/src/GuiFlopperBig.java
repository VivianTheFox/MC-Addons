// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            GuiContainer, ContainerDispenser, FontRenderer, RenderEngine, 
//            InventoryPlayer, TileEntityDispenser

public class GuiFlopperBig extends GuiFlopper
{

    public GuiFlopperBig(InventoryPlayer inventoryplayer, TileEntityDispenser tileentitydispenser)
    {
        super(inventoryplayer, tileentitydispenser);
    }

    protected void drawGuiContainerForegroundLayer()
    {
    	StringTranslate stringtranslate = StringTranslate.getInstance();
        RuntimeException ex = new RuntimeException();
        StackTraceElement[] stackTrace = ex.getStackTrace();
        String invokingClass = stackTrace[1].getClassName();
        fontRenderer.drawString(stringtranslate.translateKey("gui.flopperBig"), 60, 6, 0x404040);
        fontRenderer.drawString(stringtranslate.translateKey(inventoryString), 8, (ySize - 96) + 2, 0x404040);
    }
}
