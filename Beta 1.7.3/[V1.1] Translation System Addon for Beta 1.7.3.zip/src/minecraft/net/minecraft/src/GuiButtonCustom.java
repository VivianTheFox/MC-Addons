package net.minecraft.src;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;

public class GuiButtonCustom extends GuiButton {
	
	public int disabledColour, enabledColour, hoverColour, customIcon;
	public boolean enableBg;
	
	public GuiButtonCustom(int i, int j, int k, int l, int i1, String s, int colour1, int colour2, int colour3, boolean bg) {
		super(i, j, k, l, i1, s);
		disabledColour = colour1;
		enabledColour = colour2;
		hoverColour = colour3;
		enableBg = bg;
		customIcon = -1;
	}
	
	public GuiButtonCustom(int i, int j, int k, int l, int i1, String s, int colour1, int colour2, int colour3, boolean bg, int icon) {
		super(i, j, k, l, i1, s);
		disabledColour = colour1;
		enabledColour = colour2;
		hoverColour = colour3;
		enableBg = bg;
		customIcon = icon;
	}
	
	public GuiButtonCustom(int i, int j, int k, int l, int i1, String s, boolean bg, int icon) {
		super(i, j, k, l, i1, s);
		disabledColour = 0xffa0a0a0;
		enabledColour = 0xe0e0e0;
		hoverColour = 0xffffa0;
		enableBg = bg;
		customIcon = icon;
	}

	public void drawButton(Minecraft minecraft, int i, int j) {
		if (!enabled2) {
			return;
		}
		FontRenderer fontrenderer = minecraft.fontRenderer;
		boolean flag = i >= xPosition && j >= yPosition
				&& i < xPosition + width && j < yPosition + height;
		int k = getHoverState(flag);
		if(enableBg) {
			GL11.glBindTexture(3553 /* GL_TEXTURE_2D */,
					minecraft.renderEngine.getTexture("/gui/gui.png"));
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			drawTexturedModalRect(xPosition, yPosition, 0, 46 + k * 20, width / 2,
					height);
			drawTexturedModalRect(xPosition + width / 2, yPosition,
					200 - width / 2, 46 + k * 20, width / 2, height);
		}
		mouseDragged(minecraft, i, j);
    		if (!enabled) {
    			drawCenteredString(fontrenderer, displayString, xPosition + width
    					/ 2, yPosition + (height - 8) / 2, disabledColour);
    		} else if (flag) {
    			drawCenteredString(fontrenderer, displayString, xPosition + width
    					/ 2, yPosition + (height - 8) / 2, hoverColour);
    		} else {
    			drawCenteredString(fontrenderer, displayString, xPosition + width
    					/ 2, yPosition + (height - 8) / 2, enabledColour);
    		}
    		if(customIcon > -1) {
    			GL11.glBindTexture(3553 /* GL_TEXTURE_2D */, minecraft.renderEngine.getTexture("/NFC/icons.png"));
    			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            	drawTexturedModalRect(xPosition, yPosition, (customIcon % 12) * 20, (customIcon / 12) * 20, 20, 20);
    		}
	}
}
