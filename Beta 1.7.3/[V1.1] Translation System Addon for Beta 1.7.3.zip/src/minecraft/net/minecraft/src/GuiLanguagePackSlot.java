package net.minecraft.src;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

import org.lwjgl.opengl.GL11;

public class GuiLanguagePackSlot extends GuiSlot {

    public GuiLanguagePackSlot(GuiLanguagePacks guilangpacks)
    {
        super(GuiLanguagePacks.func_22124_a(guilangpacks), guilangpacks.width, guilangpacks.height, 32, (guilangpacks.height - 55) + 4, 26);
        parentLanguagePackGui = guilangpacks;
    }

	@Override
    protected int getSize()
    {
        List list = parentLanguagePackGui.packlist.availableLanguagePacks();
        return list.size();
    }

	@Override
    protected void elementClicked(int i, boolean flag)
    {
        try {
			parentLanguagePackGui.packlist.setLanguagePack(parentLanguagePackGui, i);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	@Override
	protected boolean isSelected(int i) {
		return parentLanguagePackGui.packlist.availableLanguagePacks().get(i).equals(StringTranslate.langFile);
	}

	@Override
	protected void drawBackground() {
		parentLanguagePackGui.drawDefaultBackground();
	}

	@Override
	protected void drawSlot(int i, int j, int k, int l, Tessellator tessellator) {
		FontRenderer fontrenderer = GuiLanguagePacks.func_22127_j(parentLanguagePackGui);
		List<String> list = parentLanguagePackGui.packlist.availableLanguagePacks();
		Map<String, String[]> map = parentLanguagePackGui.packlist.packMetas();
		String title = map.get(list.get(i))[0];
		String author = map.get(list.get(i))[1];
	    parentLanguagePackGui.drawCenteredString(fontrenderer, title, parentLanguagePackGui.width / 2, k + 1, 0xffffff);
	    parentLanguagePackGui.drawCenteredString(fontrenderer, author, parentLanguagePackGui.width / 2, k + 12, 0x808080);
	}
	
    protected int getContentHeight()
    {
        return getSize() * 26;
    }
	
    final GuiLanguagePacks parentLanguagePackGui; /* synthetic field */

}
