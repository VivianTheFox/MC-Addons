// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.IntBuffer;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;

import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            GLAllocation, RenderEngine, Tessellator, GameSettings, 
//            ChatAllowedCharacters

public class FontRenderer
{

    public FontRenderer(GameSettings gamesettings, String texString, RenderEngine renderengine)
    {
        charWidth = new int[ChatAllowedCharacters.allowedCharacters.length()];
        fontTextureName = 0;
        buffer = GLAllocation.createDirectIntBuffer(1024 /*GL_FRONT_LEFT*/);
        fontTextureNames = new int[(ChatAllowedCharacters.allowedCharacters.length() / 256) + 1];
        fontPngName = "";
        updateFontImage(0, renderengine, texString);
        for(int k = 0; k < ChatAllowedCharacters.allowedCharacters.length(); k++)
        {
            updateFontImage(k, renderengine, texString);
        	int wrappedk = k % 256;
            int l = wrappedk % 16;
            int k1 = wrappedk / 16;
            int j2 = (textureWidth/16)-1;
            do
            {
                if(j2 < 0)
                {
                    break;
                }
                int i3 = l * (textureWidth/16) + j2;
                boolean flag = true;
                for(int l3 = 0; l3 < (textureWidth/16) && flag; l3++)
                {
                    int i4 = (k1 * (textureWidth/16) + l3) * textureWidth;
                    int k4 = imageRGB[i3 + i4] & 0xff;
                    if(k4 > 0)
                    {
                        flag = false;
                    }
                }

                if(!flag)
                {
                    break;
                }
                j2--;
            } while(true);
            if(k == 32)
            {
                j2 = (textureWidth/64) + (textureWidth/128) - 1;
            }
            charWidth[k] = (j2 + 2 + ((res/8) - 1)) / (res/8);
        }

        fontDisplayLists = GLAllocation.generateDisplayLists(288);
        Tessellator tessellator = Tessellator.instance;
        for(int i1 = 0; i1 < ChatAllowedCharacters.allowedCharacters.length(); i1++)
        {
            updateFontImage(i1, renderengine, texString);
            fontTextureName = getTextureId(i1, renderengine);
            GL11.glNewList(fontDisplayLists + i1 + (i1 >= 256 ? 512 : 0), 4864 /*GL_COMPILE*/);
            GL11.glBindTexture(3553, fontTextureName);
            int renderWidth = 128;
            tessellator.startDrawingQuads();
            int l1 = (i1 % 16) * (renderWidth/16);
            int k2 = (i1 / 16) * (renderWidth/16);
            float f = (float)(renderWidth/16);
            float f1 = 0.0F;
            float f2 = 0.0F;
            tessellator.addVertexWithUV(0.0D, 0.0F + f, 0.0D, (float)l1 / (float)(renderWidth) + f1, ((float)k2 + f) / (float)(renderWidth) + f2);
            tessellator.addVertexWithUV(0.0F + f, 0.0F + f, 0.0D, ((float)l1 + f) / (float)(renderWidth) + f1, ((float)k2 + f) / (float)(renderWidth) + f2);
            tessellator.addVertexWithUV(0.0F + f, 0.0D, 0.0D, ((float)l1 + f) / (float)(renderWidth) + f1, (float)k2 / (float)(renderWidth) + f2);
            tessellator.addVertexWithUV(0.0D, 0.0D, 0.0D, (float)l1 / (float)(renderWidth) + f1, (float)k2 / (float)(renderWidth) + f2);
            tessellator.draw();
            GL11.glTranslatef(charWidth[i1], 0.0F, 0.0F);
            GL11.glEndList();
//        	System.out.println(ChatAllowedCharacters.allowedCharacters.charAt(i1) + " ? " + ChatAllowedCharacters.isAllowedCharacter(ChatAllowedCharacters.allowedCharacters.charAt(i1)));
//            System.out.println("Width of ID " + i1 + " (" + ChatAllowedCharacters.allowedCharacters.charAt(i1) + "): " + charWidth[i1] + " texID " + getTextureId(i1, renderengine) + " PNGID " + fontPng);
        }

        for(int j1 = 0; j1 < colorChars.length() * 2; j1++)
        {
            int k1 = -1;
            if(j1 >= 32)
            	k1 = j1 - ((j1 / 16) * 16);
            int customPosition = k1 == -1 ? -1 : k1 % (((colorChars.length() - 16) / 2) + 1);
            if(customPosition == 0) {
            	//Rainbow is g, or the first (0) custom character.
            	//We skip rendering here because rainbow isn't compatible with this code block, we render it elsewhere.
            	continue;
            }
            int i2 = (j1 >> 3 & 1) * 85;
            int l2 = (j1 >> 2 & 1) * 170 + i2;
            int j3 = (j1 >> 1 & 1) * 170 + i2;
            int k3 = (j1 >> 0 & 1) * 170 + i2;
            if(j1 == 6)
            {
                l2 += 85;
            }
            if(customPosition == 1) {
                l2 = 0xFF;
                j3 = 0xFF;
                k3 = 0xA0;
            }
            boolean flag1 = j1 < 32 ? j1 >= 16 : j1 - 32 > (colorChars.length() - 16) / 2;
            if(gamesettings.anaglyph)
            {
                int j4 = (l2 * 30 + j3 * 59 + k3 * 11) / 100;
                int l4 = (l2 * 30 + j3 * 70) / 100;
                int i5 = (l2 * 30 + k3 * 70) / 100;
                l2 = j4;
                j3 = l4;
                k3 = i5;
            }
            if(flag1)
            {
                l2 /= 4;
                j3 /= 4;
                k3 /= 4;
            }
            GL11.glNewList(fontDisplayLists + 256 + j1, 4864 /*GL_COMPILE*/);
            GL11.glColor3f((float)(l2 / 255F), (float)j3 / 255F, (float)k3 / 255F);
//            Below commented line used to ensure the colour was outputted correctly
//            System.out.println("Color values for value " + j1 + (flag1 ? "'s shadow" : "") + " are... Red: " + l2 + " Green: " + j3 + " Blue: " + k3);
            GL11.glEndList();
        }
    }

    public void updateFontImage(int i, RenderEngine renderengine, String texString) {
    	String prevPngName = fontPngName;
    	if(i >= 256) {
    		fontPngName = "font_" + String.format("%02X", (byte)(i/256));
    	} else {
    		fontPngName = "default";
    	}
    	if(prevPngName.equals(fontPngName)) {
    		return;
    	}
    	try
    	{
    		BufferedImage image = ImageIO.read((net.minecraft.client.Minecraft.class).getResource("/font/" + fontPngName + ".png"));
    		fontPng = image;
    	}
    	catch(IOException ioexception)
    	{
    		System.err.println("Image \"" + fontPngName + ".png\" was null!");
    		throw new RuntimeException(ioexception);
    	}
        textureWidth = fontPng.getWidth();
        textureHeight = fontPng.getHeight();
        res = textureWidth/16;
        for(int j = 0; j < textureWidth * textureHeight; j++) {
            int l = j % textureWidth;
            int k1 = j / textureHeight;
        	Color c = new Color(fontPng.getRGB(l, k1), true);
        	if(c.getAlpha() <= 2) {
        		fontPng.setRGB(l, k1, 0);
        	}
        }
        imageRGB = new int[textureWidth * textureHeight];
        imageRGB = fontPng.getRGB(0, 0, textureWidth, textureHeight, imageRGB, 0, textureWidth);
    }
    
    public int getTextureId(int i, RenderEngine renderengine) {
    	int j = i/256;
    	if(fontTextureNames[j] == 0) {
        	fontTextureNames[j] = renderengine.allocateAndSetupTexture(fontPng);
    	}
    	return fontTextureNames[j];
    }

    public void drawStringWithShadow(String s, int i, int j, int k)
    {
        renderString(s, i + 1, j + 1, k, true);
        drawString(s, i, j, k);
    }

    public void drawString(String s, int i, int j, int k)
    {
        renderString(s, i, j, k, false);
    }

    public void renderString(String s, int i, int j, int k, boolean flag)
    {
        if(s == null)
        {
            return;
        }
        if(flag)
        {
            int l = k & 0xff000000;
            k = (k & 0xfcfcfc) >> 2;
            k += l;
        }
        float f = (float)(k >> 16 & 0xff) / 255F;
        float f1 = (float)(k >> 8 & 0xff) / 255F;
        float f2 = (float)(k & 0xff) / 255F;
        float f3 = (float)(k >> 24 & 0xff) / 255F;
        if(f3 == 0.0F)
        {
            f3 = 1.0F;
        }
        GL11.glColor4f(f, f1, f2, f3);
        buffer.clear();
        GL11.glPushMatrix();
        GL11.glTranslatef(i, j, 0.0F);
        for(int i1 = 0; i1 < s.length(); i1++)
        {
            for(; s.length() > i1 + 1 && s.charAt(i1) == '\247'; i1 += 2)
            {
                int j1 = colorChars.indexOf(s.toLowerCase().charAt(i1 + 1));
                int k1 = j1 / 16;
                char ch = s.toLowerCase().charAt(i1 + 1);
                if(ch == 'g') {
                    int k4 = Color.HSBtoRGB(((System.currentTimeMillis() % 10000L) / 10000F), 1.0F, 1.0F) & 0xffffff;
                    if(flag)
                    {
                        int l = k4 & 0xff000000;
                        k4 = (k4 & 0xfcfcfc) >> 2;
                        k4 += l;
                    }
                    f = (float)(k4 >> 16 & 0xff) / 255F;
                    f1 = (float)(k4 >> 8 & 0xff) / 255F;
                    f2 = (float)(k4 & 0xff) / 255F;
                }
                if(j1 < 0 || j1 > colorChars.length() - 1)
                {
                    j1 = 15;
                }
                buffer.put(fontDisplayLists + 256 + j1 + (k1 * 16) + (flag ? j1 > 15 ? ((colorChars.length() - 16) / 2) + 1 : 16 : 0));
                if(buffer.remaining() == 0)
                {
                    buffer.flip();
                    GL11.glCallLists(buffer);
                    buffer.clear();
                }
                if(ch == 'g')
                    GL11.glColor4f(f, f1, f2, f3);
            }

            if(i1 < s.length())
            {
                int k1 = ChatAllowedCharacters.allowedCharacters.indexOf(s.charAt(i1));
                if(k1 >= 0)
                {
                    buffer.put(fontDisplayLists + k1 + (k1 >= 256 ? 512 : 0));
                }
            }
            if(buffer.remaining() == 0)
            {
                buffer.flip();
                GL11.glCallLists(buffer);
                buffer.clear();
            }
        }

        buffer.flip();
        GL11.glCallLists(buffer);
        GL11.glColor4f(1, 1, 1, 1);
        GL11.glPopMatrix();
    }

    public int getStringWidth(String s)
    {
        if(s == null)
        {
            return 0;
        }
        int i = 0;
        for(int j = 0; j < s.length(); j++)
        {
            if(s.charAt(j) == '\247')
            {
                j++;
                continue;
            }
            int k = ChatAllowedCharacters.allowedCharacters.indexOf(s.charAt(j));
            if(k >= 0)
            {
                i += charWidth[k];
            }
        }

        return i;
    }

    public void func_27278_a(String s, int i, int j, int k, int l)
    {
        String as[] = s.split("\n");
        if(as.length > 1)
        {
            for(int i1 = 0; i1 < as.length; i1++)
            {
                func_27278_a(as[i1], i, j, k, l);
                j += func_27277_a(as[i1], k);
            }

            return;
        }
        String as1[] = s.split(" ");
        int j1 = 0;
        do
        {
            if(j1 >= as1.length)
            {
                break;
            }
            String s1;
            for(s1 = (new StringBuilder()).append(as1[j1++]).append(" ").toString(); j1 < as1.length && getStringWidth((new StringBuilder()).append(s1).append(as1[j1]).toString()) < k; s1 = (new StringBuilder()).append(s1).append(as1[j1++]).append(" ").toString()) { }
            int k1;
            for(; getStringWidth(s1) > k; s1 = s1.substring(k1))
            {
                for(k1 = 0; getStringWidth(s1.substring(0, k1 + 1)) <= k; k1++) { }
                if(s1.substring(0, k1).trim().length() > 0)
                {
                    drawString(s1.substring(0, k1), i, j, l);
                    j += 8;
                }
            }

            if(s1.trim().length() > 0)
            {
                drawString(s1, i, j, l);
                j += 8;
            }
        } while(true);
    }

    public int func_27277_a(String s, int i)
    {
        String as[] = s.split("\n");
        if(as.length > 1)
        {
            int j = 0;
            for(int k = 0; k < as.length; k++)
            {
                j += func_27277_a(as[k], i);
            }

            return j;
        }
        String as1[] = s.split(" ");
        int l = 0;
        int i1 = 0;
        do
        {
            if(l >= as1.length)
            {
                break;
            }
            String s1;
            for(s1 = (new StringBuilder()).append(as1[l++]).append(" ").toString(); l < as1.length && getStringWidth((new StringBuilder()).append(s1).append(as1[l]).toString()) < i; s1 = (new StringBuilder()).append(s1).append(as1[l++]).append(" ").toString()) { }
            int j1;
            for(; getStringWidth(s1) > i; s1 = s1.substring(j1))
            {
                for(j1 = 0; getStringWidth(s1.substring(0, j1 + 1)) <= i; j1++) { }
                if(s1.substring(0, j1).trim().length() > 0)
                {
                    i1 += 8;
                }
            }

            if(s1.trim().length() > 0)
            {
                i1 += 8;
            }
        } while(true);
        if(i1 < 8)
        {
            i1 += 8;
        }
        return i1;
    }
    
    public int splitStringWidth(String par1Str, int par2) {
		return this.listFormattedStringToWidth(par1Str, par2).size();
	}

	public void drawSplitString(String par1Str, int par2, int par3, int par4,
			int par5) {
		par1Str = this.trimStringNewline(par1Str);
		this.renderSplitString(par1Str, par2, par3, par4, false);
	}

	private String trimStringNewline(String par1Str) {
		while (par1Str != null && par1Str.endsWith("\n")) {
			par1Str = par1Str.substring(0, par1Str.length() - 1);
		}

		return par1Str;
	}

	private void renderSplitString(String par1Str, int par2, int par3,
			int par4, boolean par5) {
		List var6 = this.listFormattedStringToWidth(par1Str, par4);

		for (Iterator var7 = var6.iterator(); var7.hasNext(); par3 += 8) {
			String var8 = (String) var7.next();
			this.renderString(var8, par2, par3, 0, par5);
		}
	}

	public List listFormattedStringToWidth(String par1Str, int par2) {
		return Arrays.asList(this.wrapFormattedStringToWidth(par1Str, par2)
				.split("\n"));
	}

	String wrapFormattedStringToWidth(String par1Str, int par2) {
		int var3 = this.sizeStringToWidth(par1Str, par2);

		if (par1Str.length() <= var3) {
			return par1Str;
		} else {
			String var4 = par1Str.substring(0, var3);
			char var5 = par1Str.charAt(var3);
			boolean var6 = var5 == 32 || var5 == 10;
			String var7 = getFormatFromString(var4)
					+ par1Str.substring(var3 + (var6 ? 1 : 0));
			return var4 + "\n" + this.wrapFormattedStringToWidth(var7, par2);

		}
	}

	private static String getFormatFromString(String par0Str) {
		String var1 = "";
		int var2 = -1;
		int var3 = par0Str.length();

		while ((var2 = par0Str.indexOf(167, var2 + 1)) != -1) {
			if (var2 < var3 - 1) {
				char var4 = par0Str.charAt(var2 + 1);

			}
		}

		return var1;
	}

	private int sizeStringToWidth(String par1Str, int par2) {
		int var3 = par1Str.length();
		int var4 = 0;
		int var5 = 0;
		int var6 = -1;

		for (boolean var7 = false; var5 < var3; ++var5) {
			char var8 = par1Str.charAt(var5);

			switch (var8) {
			case 10:
				--var5;
				break;

			case 167:
				if (var5 < var3 - 1) {
					++var5;
					char var9 = par1Str.charAt(var5);

					if (var9 != 108 && var9 != 76) {
						if (var9 == 114 || var9 == 82) {
							var7 = false;
						}
					} else {
						var7 = true;
					}
				}

				break;

			case 32:
				var6 = var5;

			default:
				var4 += this.getCharWidth(var8);

				if (var7) {
					++var4;
				}
			}

			if (var8 == 10) {
				++var5;
				var6 = var5;
				break;
			}

			if (var4 > par2) {
				break;
			}
		}

		return var5 != var3 && var6 != -1 && var6 < var5 ? var6 : var5;
	}

	public int getCharWidth(char par1) {
		if (par1 == 167) {
			return -1;
		} else if (par1 == 32) {
			return 4;
		} else {
			int var2 = ChatAllowedCharacters.allowedCharacters.indexOf(par1);

			if (par1 > 0 && var2 != -1) {
				return this.charWidth[var2];
			} else {
				return 0;
			}
		}
	}

    private int charWidth[];
    private int res;
    public int fontTextureName;
    public int fontTextureNames[];
    public String fontPngName;
    public int textureWidth;
    public int textureHeight;
    public int imageRGB[];
    public BufferedImage fontPng;
    private int fontDisplayLists;
    private IntBuffer buffer;
    private static final String colorChars = "0123456789abcdefgh";
}
