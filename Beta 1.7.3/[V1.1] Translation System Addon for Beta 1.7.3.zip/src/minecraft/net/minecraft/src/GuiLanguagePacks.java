package net.minecraft.src;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.Collections;

import org.lwjgl.Sys;

import net.minecraft.client.Minecraft;

public class GuiLanguagePacks extends GuiScreen {

	public GuiLanguagePacks(GuiScreen guiscreen) {
		field_6454_o = -1;
		guiScreen = guiscreen;
	}

	public void initGui() {
		StringTranslate stringtranslate = StringTranslate.getInstance();
		controlList.add(new GuiSmallButton(5, width / 2 - 154, height - 48,
				stringtranslate.translateKey("languagePack.openFolder")));
		controlList.add(new GuiSmallButton(6, width / 2 + 4, height - 48,
				stringtranslate.translateKey("gui.done")));
		packlist = new LanguagePackList(mc, mc.getMinecraftDir());
		packlist.updateAvaliableLanguagePacks();
		guiLanguagePackSlot = new GuiLanguagePackSlot(this);
		guiLanguagePackSlot.registerScrollButtons(controlList, 7, 8);
	}

	protected void actionPerformed(GuiButton guibutton) {
		if (!guibutton.enabled) {
			return;
		}
		if (guibutton.id == 5) {
			//Sys.openURL((new StringBuilder()).append("file://").append(mc.getMinecraftDir()).append("/languagepacks").toString());
			try {
			    Desktop.getDesktop().open(new File("languagepacks"));
			} catch (IOException e) {
			    e.printStackTrace();
			} 
		} else if (guibutton.id == 6) {
			mc.renderEngine.refreshTextures();
			mc.displayGuiScreen(guiScreen);
		} else {
			guiLanguagePackSlot.actionPerformed(guibutton);
		}
	}

	protected void mouseClicked(int i, int j, int k) {
		super.mouseClicked(i, j, k);
	}

	protected void mouseMovedOrUp(int i, int j, int k) {
		super.mouseMovedOrUp(i, j, k);
	}

	public void drawScreen(int i, int j, float f) {
		guiLanguagePackSlot.drawScreen(i, j, f);
		StringTranslate stringtranslate = StringTranslate.getInstance();
		drawCenteredString(fontRenderer,
				stringtranslate.translateKey("languagePack.title"), width / 2,
				16, 0xffffff);
		drawCenteredString(fontRenderer,
				stringtranslate.translateKey("languagePack.folderInfo"),
				width / 2 - 77, height - 26, 0x808080);
		super.drawScreen(i, j, f);
//		guiTexturePackSlot.registerScrollButtons(controlList, 7, 8);
	}

    protected void keyTyped(char c, int i)
    {
    	if(i == 1 && guiScreen instanceof GuiMainMenu)
    	{
            mc.displayGuiScreen(guiScreen);
    	} else {
            super.keyTyped(c, i);
    	}
    }

	public void updateScreen() {
		super.updateScreen();
		field_6454_o--;
	}
	
	static Minecraft func_22124_a(GuiLanguagePacks guilanguagepacks) {
		return guilanguagepacks.mc;
	}
	
	static FontRenderer func_22127_j(GuiLanguagePacks guilanguagepacks) {
		return guilanguagepacks.fontRenderer;
	}

	protected GuiScreen guiScreen;
	private int field_6454_o;
	public LanguagePackList packlist;
	private GuiLanguagePackSlot guiLanguagePackSlot;
}
