package net.minecraft.src;

import java.util.Map;

public class mod_bouncyBall extends BaseMod {

	public String Version() {
		return "1.0";
	}

	public static final Item bounceball = (new ItemBouncyBall(9000).setItemName("bounceball"));
	
	public mod_bouncyBall()
	{
		bounceball.iconIndex = ModLoader.addOverride("/gui/items.png", "/bounceball.png");
		ModLoader.AddName(bounceball, "Bouncy Ball");
		ModLoader.AddSmelting(Item.slimeBall.shiftedIndex, new ItemStack(bounceball, 1));
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void AddRenderer(Map map)
    {
		map.put(net.minecraft.src.EntityBounceball.class, new RenderSnowball(bounceball.iconIndex));
    }
}
