package net.minecraft.src;

public class mod_Blackstone extends BaseModMp {

	public mod_Blackstone()
	{
		initBlocks();
	}
	
	public static void initBlocks()
    {
		ModLoader.RegisterBlock(blackstone);
		ModLoader.RegisterBlock(blackstonePolished);
		ModLoader.RegisterBlock(blackstonePolishedBricks);
		ModLoader.RegisterBlock(blackstonePolishedBricksCracked);
		
		//blackStone.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/blackStone/blackstone.png");
		blackstonePolished.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/blackstone/polished_blackstone.png");
		blackstonePolishedBricks.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/blackstone/polished_blackstone_bricks.png");
		blackstonePolishedBricksCracked.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/blackstone/cracked_polished_blackstone_bricks.png");
		
		ModLoader.AddName(blackstone, "Blackstone");
		ModLoader.AddName(blackstonePolished, "Polished Blackstone");
		ModLoader.AddName(blackstonePolishedBricks, "Polished Blackstone Bricks");
		ModLoader.AddName(blackstonePolishedBricksCracked, "Cracked Polished Blackstone Bricks");
    }

	public static final Block blackstone = (new BlockBlackstone(217, 1)).setBlockName("blackstone");
	public static final Block blackstonePolished = (new BlockStoneBrick(218, 1)).setBlockName("blackstonePolished");
	public static final Block blackstonePolishedBricks = (new BlockStoneBrick(219, 1)).setBlockName("blackstonePolishedBricks");
	public static final Block blackstonePolishedBricksCracked = (new BlockStoneBrick(220, 1)).setBlockName("blackstonePolishedBricksCracked");
	
	public String Version() {
		return "1.0";
	}
	
}
