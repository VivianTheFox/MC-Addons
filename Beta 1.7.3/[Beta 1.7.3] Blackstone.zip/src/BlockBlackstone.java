package net.minecraft.src;

public class BlockBlackstone extends Block {
	
	public BlockBlackstone(int i, int j)
	{
		super(i, j, Material.rock);
	}
	
	int blockTopBottom = ModLoader.addOverride("/terrain.png", "/blackstone/blackstone_top.png");
	int blockSide = ModLoader.addOverride("/terrain.png", "/blackstone/blackstone.png");
	
	public int getBlockTextureFromSide(int i)
    {
        if(i == 0 || i == 1)
        {
        	return blockTopBottom;
        }
        else
        {
        	return blockSide;
        }
    }

}
