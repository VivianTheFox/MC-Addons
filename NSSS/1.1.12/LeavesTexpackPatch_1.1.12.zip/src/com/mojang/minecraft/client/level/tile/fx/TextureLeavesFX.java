package com.mojang.minecraft.client.level.tile.fx;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import javax.imageio.ImageIO;

import com.mojang.minecraft.client.Minecraft;
import com.mojang.minecraft.core.enums.EnumSeason;
import com.mojang.minecraft.core.level.World;
import com.mojang.minecraft.core.level.tile.Block;
import com.mojang.minecraft.core.util.MathHelper;

import java.awt.image.BufferedImage;

public class TextureLeavesFX extends TextureFX
{
	private int[] leaves;
	private int[] branches;
	private int[] buds;
	private Minecraft minec;
	

    private int alternate;
    private int tickCounter;
    

    public TextureLeavesFX(final int n, Minecraft mc) {
        super(105 + n);
        leaves = new int[1024];
        branches = new int[1024];
        buds = new int[8192];
        minec = mc;

        this.alternate = (n << 1) - 1;
        this.tickCounter = 2;
        try{
            BufferedImage leaves, branches, buds;
            leaves = ImageIO.read(mc.texturePackList.selectedTexturePack.getResourceAsStream("/leaves.png"));
            branches = ImageIO.read(mc.texturePackList.selectedTexturePack.getResourceAsStream("/branches.png"));
            buds = ImageIO.read(mc.texturePackList.selectedTexturePack.getResourceAsStream("/buds.png"));
            leaves.getRGB(0 + (n * 16), 0, 16, 16, this.leaves, 0, 16);
            branches.getRGB(0 + (n * 16), 0, 16, 16, this.branches, 0, 16);
            buds.getRGB(0 + (n * 16), 0, 16, 128, this.buds, 0, 16);
        }catch(Exception ex){
        	ex.printStackTrace();
        }
        //field_1154_k = 0;
    }
    
    public final void render() {
        try {
            if(leaves != null || branches != null || buds != null);
            {
                this.tickCounter = (1 + this.alternate & 0x3F);
                final float a = MathHelper.sin(this.tickCounter / 64.0f * 3.1415927f * 2.0f);
                final float b = MathHelper.cos(this.tickCounter / 64.0f * 3.1415927f * 2.0f);
                for (int u = 0; u < 16; ++u) {
                    for (int v = 0; v < 16; ++v) {
                        float n = (u / 15.0f - 0.5f) * 31.0f;
                        final float n2 = (v / 15.0f - 0.5f) * 31.0f;
                        final float n3 = b * n - a * n2;
                        n = b * n2 + a * n;
                        int n4 = (int)(n3 + 16.0f);
                        int n5 = (int)(n + 16.0f);
                        int n6 = 0;
                        //if (n4 >= 0 && n5 >= 0 && n4 < 156 && n5 < 156) {
                        //n6 = this.leaves[n4 + (n5 << 5)];
                        if ((n5 = this.leaves[u + (v << 4)]) >>> 24 > 128/* && worldObj != null && worldObj.getCurrentSeason() == EnumSeason.winter*/) {
                            n6 = n5;
                            if(minec.mcWorld != null){
                                if(minec.mcWorld.getCurrentSeason() == EnumSeason.winter && (n5 = this.buds[u + (v << 4)]) >>> 24 > -1){
                                    n6 = n5;
                                }
                                if(minec.mcWorld.getCurrentSeason() == EnumSeason.spring && (n5 = this.buds[u + ((v + 16 *(int)(Math.floor(minec.mcWorld.getSeasonProgress() * 8)) << 4))]) >>> 24 > -1){
                                    n6 = n5;
                                }
                                if((minec.mcWorld.getCurrentSeason() == EnumSeason.summer) && (n5 = this.buds[u + ((v + 112) << 4)]) >>> 24 > -1){
                                    n6 = n5;
                                }
                                if((minec.mcWorld.getCurrentSeason() == EnumSeason.fall) && (n5 = this.leaves[u + (v << 4)]) >>> 24 > -1){
                                    n6 = n5;
                                }
                            }

                        }/*else if ((n5 = this.leaves[i + (j << 4)]) >>> 24 > 128 && worldObj != null && worldObj.getCurrentSeason() == EnumSeason.fall){
                    	n6 = n5;
                    }*/
                        //}
                        n5 = (n6 >> 16 & 0xFF);
                        n4 = (n6 >> 8 & 0xFF);
                        final int n7 = n6 & 0xFF;
                        n6 = ((n6 >>> 24 > 128) ? 255 : 0);
                        final int n8 = u + (v << 4);
                        this.bitMap[n8 << 2] = (byte)n5;
                        this.bitMap[(n8 << 2) + 1] = (byte)n4;
                        this.bitMap[(n8 << 2) + 2] = (byte)n7;
                        this.bitMap[(n8 << 2) + 3] = (byte)n6;
                    }
                }
            }
        } catch (Exception e) {}
    }

    public void render_()
    {
        //field_1154_k++;
        
        for(int pixelIndex = 0; pixelIndex < 256; pixelIndex++)
        {
            int colorPix = leaves[pixelIndex];
            //System.out.println(colorPix);
            int red = colorPix >> 16 & 0xff;
            int green = colorPix >> 8 & 0xff;
            int blue = colorPix & 0xff;
            int alpha = pixelIndex % 2 == 0 ? 0 : 128;
            if(!field_1131_c)
            {
                int r2 = (red * 30 + green * 59 + blue * 11) / 100;
                int g2 = (red * 30 + green * 70) / 100;
                int b2 = (red * 30 + blue * 70) / 100;
                red = r2;
                green = g2;
                blue = b2;
            }
            bitMap[pixelIndex * 4 + 0] = (byte)red;
            bitMap[pixelIndex * 4 + 1] = (byte)green;
            bitMap[pixelIndex * 4 + 2] = (byte)blue;
            bitMap[pixelIndex * 4 + 3] = (byte)alpha;
        }

    }

   
    //private int field_1154_k;
}
