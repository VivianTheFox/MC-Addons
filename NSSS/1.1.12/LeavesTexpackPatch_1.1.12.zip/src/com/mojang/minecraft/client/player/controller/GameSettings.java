package com.mojang.minecraft.client.player.controller;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.io.*;
import java.util.ArrayList;

import org.lwjgl.LWJGLException;
//import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;

import com.mojang.minecraft.client.Minecraft;
import com.mojang.minecraft.core.util.MathHelper;

public class GameSettings
{

    public GameSettings(Minecraft minecraft, File file)
    {
        musicVolume = 1.0F;
        soundVolume = 1.0F;
        ambienceVolume = 1.0F;
        mouseSensitivity = 0.5F;
        modemVolume = 0.0F;
        invertMouse = false;
        renderDistance = 0;
        viewBobbing = true;
        fog = true;
        clouds = true;
        particles = true;
        anaglyph = false;
        limitFramerate = false;
        fancyGraphics = true;
        skin = "Default";
        lastServer = "";
        chunkSavingInterval = 0;
        advancedOpenGL = false;
        keyBindForward = new KeyBinding("Forward", 17);
        keyBindLeft = new KeyBinding("Left", 30);
        keyBindBack = new KeyBinding("Back", 31);
        keyBindRight = new KeyBinding("Right", 32);
        keyBindJump = new KeyBinding("Jump", 57);
        keyBindBuild = new KeyBinding("Build", 48);
        keyBindInventory = new KeyBinding("Inventory", 18);
        keyBindDrop = new KeyBinding("Drop", 16);
        keyBindChat = new KeyBinding("Chat", 20);
        keyBindToggleFog = new KeyBinding("Toggle fog", 33);
        keyBindSneak = new KeyBinding("Sneak", 42);
        keyBindRun = new KeyBinding("Run", 29);
        keyBindSaveLocation = new KeyBinding("Save Location", 28);
        keyBindLoadLocation = new KeyBinding("Load Location", 19);
        keyBindAttack = new KeyBinding("Attack", -100);
        keyBindUse = new KeyBinding("Use", -99);
        keyBindings = (new KeyBinding[] {
            keyBindForward, keyBindLeft, keyBindBack, keyBindRight, keyBindJump, keyBindSneak, keyBindDrop, keyBindInventory, keyBindChat, keyBindToggleFog, keyBindRun, keyBindBuild, keyBindSaveLocation, keyBindLoadLocation, keyBindAttack, keyBindUse
        });
        /*buttonBindAttack = new KeyBinding("Attack", 5);
        buttonBindUse = new KeyBinding("Use", 7);
        buttonBindEscape = new KeyBinding("Back", 9);
        buttonBindPick = new KeyBinding("Pick", 11);
        buttonBindJump = new KeyBinding("Jump", 2);
        buttonBindBuild = new KeyBinding("Build", 3);
        buttonBindInventory = new KeyBinding("Inventory", 0);
        buttonBindDrop = new KeyBinding("Drop", 1);
        buttonBindChat = new KeyBinding("Chat", 8);
        buttonBindToggleFog = new KeyBinding("Toggle fog", 33);
        buttonBindSneak = new KeyBinding("Sneak", 6);
        buttonBindRun = new KeyBinding("Run", 4);
        buttonBindSaveLocation = new KeyBinding("Save Location", 28);
        buttonBindLoadLocation = new KeyBinding("Load Location", 19);
        buttonBindings = (new KeyBinding[] {
        	buttonBindAttack, buttonBindUse, buttonBindEscape, buttonBindPick, buttonBindJump, buttonBindSneak, buttonBindDrop, buttonBindInventory, buttonBindChat, buttonBindToggleFog, buttonBindRun, buttonBindBuild, buttonBindSaveLocation, buttonBindLoadLocation
        });*/
        numberOfOptions = 12;
        difficulty = 2;
        thirdPersonView = false;
        guiScale = 0;
        FOV = 0;
        mc = minecraft;
        ignoreJavaWarning = false;
        displayMode = 0;
        cloudLevel = 2;
        leafLevel = 3;
        precipLevel = true;
        vignette = true;
        mobShadows = true;
        vSync = false;
        hints = true;
        noTextures = false;
        smoothCamera = false;
        randomTickRate = 80;
        optionsFile = new File(file, "optionsNSSS.txt");
        readOptions();
    }

    public GameSettings()
    {
        musicVolume = 1.0F;
        soundVolume = 1.0F;
        ambienceVolume = 1.0F;
        mouseSensitivity = 0.5F;
        modemVolume = 0.0F;
        invertMouse = false;
        renderDistance = 0;
        viewBobbing = true;
        fog = true;
        clouds = true;
        particles = true;
        anaglyph = false;
        limitFramerate = false;
        fancyGraphics = true;
        skin = "Default";
        chunkSavingInterval = 0;
        advancedOpenGL = false;
        keyBindForward = new KeyBinding("Forward", 17);
        keyBindLeft = new KeyBinding("Left", 30);
        keyBindBack = new KeyBinding("Back", 31);
        keyBindRight = new KeyBinding("Right", 32);
        keyBindJump = new KeyBinding("Jump", 57);
        keyBindBuild = new KeyBinding("Build", 48);
        keyBindInventory = new KeyBinding("Inventory", 18);
        keyBindDrop = new KeyBinding("Drop", 16);
        keyBindChat = new KeyBinding("Chat", 20);
        keyBindToggleFog = new KeyBinding("Toggle fog", 33);
        keyBindSneak = new KeyBinding("Sneak", 42);
        keyBindRun = new KeyBinding("Run", 29);
        keyBindSaveLocation = new KeyBinding("Save Location", 28);
        keyBindLoadLocation = new KeyBinding("Load Location", 19);
        keyBindAttack = new KeyBinding("Attack", -100);
        keyBindUse = new KeyBinding("Use", -99);
        keyBindings = (new KeyBinding[] {
            keyBindForward, keyBindLeft, keyBindBack, keyBindRight, keyBindJump, keyBindSneak, keyBindDrop, keyBindInventory, keyBindChat, keyBindToggleFog, keyBindRun, keyBindBuild, keyBindSaveLocation, keyBindLoadLocation, keyBindAttack, keyBindUse
        });
        /*buttonBindAttack = new KeyBinding("Attack", 5);
        buttonBindUse = new KeyBinding("Use", 7);
        buttonBindEscape = new KeyBinding("Back", 9);
        buttonBindPick = new KeyBinding("Pick", 11);
        buttonBindJump = new KeyBinding("Jump", 2);
        buttonBindBuild = new KeyBinding("Build", 3);
        buttonBindInventory = new KeyBinding("Inventory", 0);
        buttonBindDrop = new KeyBinding("Drop", 1);
        buttonBindChat = new KeyBinding("Chat", 8);
        buttonBindToggleFog = new KeyBinding("Toggle fog", 33);
        buttonBindSneak = new KeyBinding("Sneak", 6);
        buttonBindRun = new KeyBinding("Run", 4);
        buttonBindSaveLocation = new KeyBinding("Save Location", 28);
        buttonBindLoadLocation = new KeyBinding("Load Location", 19);
        buttonBindings = (new KeyBinding[] {
        	buttonBindAttack, buttonBindUse, buttonBindEscape, buttonBindPick, buttonBindJump, buttonBindSneak, buttonBindDrop, buttonBindInventory, buttonBindChat, buttonBindToggleFog, buttonBindRun, buttonBindBuild, buttonBindSaveLocation, buttonBindLoadLocation
        });*/
        numberOfOptions = 12;
        difficulty = 2;
        thirdPersonView = false;
        guiScale = 0;
        FOV = 0;
        ignoreJavaWarning = false;
        displayMode = 0;
        cloudLevel = 2;
        leafLevel = 3;
        precipLevel = true;
        vignette = true;
        mobShadows = true;
        vSync = false;
        hints = true;
        noTextures = false;
        smoothCamera = false;
        randomTickRate = 80;
    }

    public String getKeyBindInfo(int i)
    {
    	if(keyBindings[i].keyCode <= 0){
    		return (new StringBuilder()).append(keyBindings[i].keyDescription).append(": ").append("MISSINGNO").toString();
    	}
        return (new StringBuilder()).append(keyBindings[i].keyDescription).append(": ").append(Keyboard.getKeyName(keyBindings[i].keyCode)).toString();
    }

    public void setKeyBinding(int i, int j)
    {
        keyBindings[i].keyCode = j;
        save();
    }
    
    /*public String getButtonBindInfo(int i)
    {
        return (new StringBuilder()).append(buttonBindings[i].keyDescription).append(": ").append((buttonBindings[i].keyCode)).toString();
    }

    public void setButtonBinding(int i, int j)
    {
        buttonBindings[i].keyCode = j;
        save();
    }*/
    
    public ArrayList<String> getDisplayModes(boolean force){
//    	if(Modes != null && Modes.size() > displayMode && !force){
//    		return Modes;
//    	}
//    	Resolutions = new ArrayList<DisplayMode>();
//    	Modes = new ArrayList<String>();
//    	Modes.add("Display: DEFAULT");
//        try {
//            DisplayMode[] modes;
//                modes = Display.getAvailableDisplayModes(); //get all resolution
//            for (int i=0;i<modes.length;i++) {
//                DisplayMode current = modes[i]; //add all DisplaMode to arraylist
//                Resolutions.add(current);
//            }
//            } catch (LWJGLException e) {
//                e.printStackTrace();
//            }
        int i = 0;
        for (DisplayMode mode : Resolutions) { //optional just to see all resolution
            //System.out.println(i + " | " + mode.getWidth() + "x" + mode.getHeight() + "x"+mode.getBitsPerPixel() + " " + mode.getFrequency() + "Hz");
            Modes.add("Display: " + mode.getWidth() + "x" + mode.getHeight() + "x"+mode.getBitsPerPixel() + " " + mode.getFrequency() + "Hz");
            i++;

        }
        return Modes;
    }

    public void setDisplayModes(ArrayList setModes) {
        Modes = setModes;
    }

    public void saveSliderValue(int i, float f)
    {
        if(i == 0)
        {
            musicVolume = f;
            mc.soundMGR.updateVolume();
        }
        if(i == 1)
        {
            soundVolume = f;
            mc.soundMGR.updateVolume();
        }
        if(i == 2)
        {
            ambienceVolume = f;
            mc.soundMGR.updateVolume();
        }
        if(i == 3)
        {
            mouseSensitivity = f;
        }
        if(i == 4)
        {
            renderDistance = 3 - MathHelper.floor_float(f * 6);
            save();
            //System.out.println("Render distance is " + renderDistance);
            //System.out.println("Render distance is " + renderDistance + " / " + RENDER_DISTANCES[renderDistance + 1]);
        }
        if(i == 12)
        {
            FOV = (int)(f * 60);
        }
        if(i == 566)
        {
            modemVolume = f;
        }
        if(i == 104)
        {
            chunkSavingInterval = MathHelper.floor_float(f * 58);
        }
    }

    public void setOptionValue(int i, int j)
    {
        if(i == 10)
        {
            invertMouse = !invertMouse;
        }
        if(i == 4)
        {
            renderDistance += j;
            if(renderDistance > 3) {
                renderDistance = -2;
            }
            else if(renderDistance < -2) {
                renderDistance = 3;
            }

        }
        if(i == 5)
        {
            viewBobbing = !viewBobbing;
        }
        if(i == 6)
        {
            anaglyph = !anaglyph;
            mc.renderEngine.refreshTextures();
        }
        if(i == 7)
        {
            limitFramerate = false;//!limitFramerate;
        }
        if(i == 8)
        {
            difficulty = difficulty + j & 3;
        }
        if(i == 9)
        {
            fancyGraphics = !fancyGraphics;
            mc.renderGlobal.loadRenderers();
        }
        if(i == 11)
        {
          guiScale += j;
          if(guiScale > 3) 
          {
          	guiScale = 0;
          }
        }
        if(i == 101)
        {
            clouds = !clouds;
        }
        if(i == 100) {
            fog = !fog;
        }
        if(i == 1993)
        {
            advancedOpenGL = !advancedOpenGL;
        }
        if(i == 1997)
        {
        	cloudLevel += j;
            if(cloudLevel > 2) {
            	cloudLevel = 0;
            }
            else if(cloudLevel < 0) {
            	cloudLevel = 2;
            }
        }
        if(i == 1998)
        {
            leafLevel += j;
            if(leafLevel > 3) {
            	leafLevel = 0;
            }
            else if(leafLevel < 0) {
            	leafLevel = 3;
            }
            mc.renderGlobal.loadRenderers();
        }if(i == 1999)
        {
            vignette = !vignette;
        }
        if(i == 2000)
        {
            precipLevel = !precipLevel;
        }        
        if(i == 2001)
        {
            mobShadows = !mobShadows;
        }
        if(i == 2002)
        {
            vSync = !vSync;
            Display.setVSyncEnabled(vSync);
        }
        if(i == 2003)
        {
            hints = !hints;
        }
        save();
    }

    public int func_1046_b(int i)
    {
        if(i == 0)
        {
            return 1;
        }
        if(i == 1)
        {
            return 1;
        }
        if(i == 2)
        {
        	return 1;
        }
        if(i == 3)
        {
        	return 1;
        }
        return i != 4 ? 0 : 1;
    }

    public float sliderType(int i)
    {
        if(i == 0)
        {
            return musicVolume;
        }
        if(i == 1)
        {
            return soundVolume;
        }
        if(i == 2)
        {
            return ambienceVolume;
        }
        if(i == 3)
        {
            return mouseSensitivity;
        }
        if(i == 4)
        {
            return renderDistance;
        }
        if(i == 104)
        {
            return chunkSavingInterval;
        }
        if(i == 12)
	    {
	        return FOV;
	    }
        if(i == 566)
	    {
	        return modemVolume;
	    }
        else
        {
            return 0.0F;
        }
    }

    public String getOptionValue(int i)
    {
        if(i == 0)
        {
            return (new StringBuilder()).append("Music: ").append(musicVolume <= 0.0F ? "OFF" : (new StringBuilder()).append((int)(musicVolume * 100F)).append("%").toString()).toString();
        }
        if(i == 1)
        {
            return (new StringBuilder()).append("Sound: ").append(soundVolume <= 0.0F ? "OFF" : (new StringBuilder()).append((int)(soundVolume * 100F)).append("%").toString()).toString();
        }
        if(i == 2)
        {
            return (new StringBuilder()).append("Ambience: ").append(ambienceVolume <= 0.0F ? "OFF" : (new StringBuilder()).append((int)(ambienceVolume * 100F)).append("%").toString()).toString();
        }
        if(i == 12)
        {
            if(FOV == 0)
            {
                return "FOV: Normal";
            }
            if(FOV == 60)
            {
                return "FOV: CinemaScope";
            } else
            {
            	return (new StringBuilder()).append("FOV: ").append((int)(FOV + 70)).append("�").toString();
            }
        }
        if(i == 10)
        {
            return (new StringBuilder()).append("Invert mouse: ").append(invertMouse ? "ON" : "OFF").toString();
        }
        if(i == 3)
        {
            if(mouseSensitivity == 0.0F)
            {
                return "Sensitivity: *yawn*";
            }
            if(mouseSensitivity == 1.0F)
            {
                return "Sensitivity: HYPERSPEED!!!";
            } else
            {
                return (new StringBuilder()).append("Sensitivity: ").append((int)(mouseSensitivity * 200F)).append("%").toString();
            }
        }
        if(i == 4)
        {
            //System.out.println(renderDistance);
            if(renderDistance >= -2  && renderDistance <= 4) {
                return (new StringBuilder()).append("Render distance: ").append(RENDER_DISTANCES[renderDistance + 2]).toString();
            } else {
            	//renderDistance = 0;
            	return (new StringBuilder()).append("Render distance: ").append(RENDER_DISTANCES[renderDistance + 3]).toString();
                //return (new StringBuilder().append("Render distance: INFINITE").toString()); //no longer in game
            }
        }
        if(i == 5)
        {
            return (new StringBuilder()).append("View bobbing: ").append(viewBobbing ? "ON" : "OFF").toString();
        }
        if(i == 6)
        {
            return (new StringBuilder()).append("3d anaglyph: ").append(anaglyph ? "ON" : "OFF").toString();
        }
        if(i == 7)
        {
            return "Credits...";//(new StringBuilder()).append("Limit framerate: ").append(limitFramerate ? "ON" : "OFF").toString();
        }
        if(i == 8)
        {
        	if(mc.mcWorld == null || !mc.mcWorld.multiplayerWorld){
            	return (new StringBuilder()).append("Difficulty: ").append(DIFFICULTY_LEVELS[difficulty]).toString();
        	}else{
            	return (new StringBuilder()).append("Server Difficulty: ").append(DIFFICULTY_LEVELS[ mc.mcWorld.multiplayerDifficulty]).toString();
        	}
            
        }
        if(i == 11)
        {
            return (new StringBuilder()).append("Gui Scale: ").append(GUI_SCALES[guiScale]).toString();
        }
        if(i == 104)
        {
            return "Save every " + (chunkSavingInterval + 2) + " seconds";
        }
        if(i == 100) {
            return (new StringBuilder().append("Fog: ").append(fog ? "ON" : "OFF").toString());
        }
        if(i == 101) {
            return (new StringBuilder().append("Clouds: ").append(clouds ? "ON" : "OFF").toString());
        }
        if(i == 102) { //Particles
            return (new StringBuilder().append("Particles: ").append(particles ? "ON" : "OFF").toString());
        }
        if(i == 1993) { //ARB occlusion
            return (new StringBuilder().append("*Advanced OpenGL: ").append(advancedOpenGL ? "ON" : "OFF").toString());
        }
        if(i == 566) // Modem Volume
        {
            return (new StringBuilder()).append("Modem Volume: ").append(modemVolume <= 0.0F ? "OFF" : (new StringBuilder()).append((int)(modemVolume * 100F)).append("%").toString()).toString();
        }
        if(i == 9) // Fast/Fancy (DEPRECATED)
        {
            return (new StringBuilder()).append("Graphics: ").append(fancyGraphics ? "FANCY" : "FAST").toString();
        }
        if(i == 1996) //Display mode
        {
        	if(displayMode == -1){
        		return "Display: DEFAULT";
        	}
        	else{
        		return (new StringBuilder()).append("Display: ").append(getDisplayModes(false).get(displayMode)).toString();
        	}
        } 
        if(i == 1997) // Cloud fanciness
        {
            return (new StringBuilder()).append("Clouds: ").append(CLOUD_LEVELS[cloudLevel]).toString();
        }
        if(i == 1998) // Leaf fanciness
        {
            return (new StringBuilder()).append("Leaves: ").append(LEAF_LEVELS[leafLevel]).toString();
        }
        if(i == 1999) // Vignette
        {
            return (new StringBuilder()).append("Vignette: ").append(vignette ? "ON" : "OFF").toString();
        }
        if(i == 2000) // Precipitation
        {
            return (new StringBuilder()).append("Precipitation: ").append(precipLevel ? "FANCY" : "FAST").toString();
        }
        if(i == 2001) // Mob Shadows
        {
            return (new StringBuilder()).append("Mob Shadows: ").append(mobShadows ? "ON" : "OFF").toString();
        }
        if(i == 2002) // Vsync
        {
            return (new StringBuilder()).append("Vsync: ").append(vSync ? "ON" : "OFF").toString();
        }
        if(i == 2003) // Hints
        {
            return (new StringBuilder()).append("Hints: ").append(hints ? "ON" : "OFF").toString();
        }
        else
        {
            return "";
        }
    }

    public void readOptions()
    {
        try
        {
            if(!optionsFile.exists())
            {
                return;
            }
            BufferedReader bufferedreader = new BufferedReader(new FileReader(optionsFile));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
            {
                String as[] = s.split(":");
                if(as[0].equals("music"))
                {
                    musicVolume = func_1050_a(as[1]);
                }
                if(as[0].equals("sound"))
                {
                    soundVolume = func_1050_a(as[1]);
                }
                if(as[0].equals("ambience"))
                {
                    ambienceVolume = func_1050_a(as[1]);
                }
                if(as[0].equals("FOV"))
                {
                    FOV = Integer.parseInt(as[1]);
                }
                if(as[0].equals("mouseSensitivity"))
                {
                    mouseSensitivity = func_1050_a(as[1]);
                }
                if(as[0].equals("modemVolume"))
                {
                    modemVolume = func_1050_a(as[1]);
                }
                if(as[0].equals("invertYMouse"))
                {
                    invertMouse = as[1].equals("true");
                }
                if(as[0].equals("viewDistance"))
                {
                    renderDistance = Integer.parseInt(as[1]);
                }
                if(as[0].equals("bobView"))
                {
                    viewBobbing = as[1].equals("true");
                }
                if(as[0].equals("anaglyph3d"))
                {
                    anaglyph = as[1].equals("true");
                }
                if(as[0].equals("limitFramerate"))
                {
                    limitFramerate = as[1].equals("true");
                }
                if(as[0].equals("difficulty"))
                {
                    difficulty = Integer.parseInt(as[1]);
                }
                if(as[0].equals("guiScale"))
                {
                    guiScale = Integer.parseInt(as[1]);
                }
                if(as[0].equals("fancyGraphics"))
                {
                    fancyGraphics = as[1].equals("true");
                }
                if(as[0].equals("lastServer") && as.length > 1)
                {
                	lastServer = as[1] + ":" + as[2];
                }
                if(as[0].equals("fog"))
                {
                    fog = as[1].equals("true");
                }
                if(as[0].equals("Clouds"))
                {
                    clouds = as[1].equals("true");
                }
                if(as[0].equals("particles")) // particles
                {
                    particles = as[1].equals("true");
                }
                if(as[0].equals("ignoreJavaWarning"))
                {
                	ignoreJavaWarning = as[1].equals("true");
                }
                if(as[0].equals("saverate"))
                {
                    chunkSavingInterval = Integer.parseInt(as[1]);
                }
                if(as[0].equals("advancedopengl"))
                {
                    advancedOpenGL = as[1].equals("true");
                }
                if(as[0].equals("displayMode"))
                {
                    displayMode = Integer.parseInt(as[1]);
                }
                if(as[0].equals("cloudLevel"))
                {
                    cloudLevel = Integer.parseInt(as[1]);
                }
                if(as[0].equals("leafLevel"))
                {
                    leafLevel = Integer.parseInt(as[1]);
                }
                if(as[0].equals("precipLevel"))
                {
                    precipLevel = as[1].equals("true");
                }
                if(as[0].equals("vignette"))
                {
                    vignette = as[1].equals("true");
                }
                if(as[0].equals("mobShadows"))
                {
                    mobShadows = as[1].equals("true");
                }
                if(as[0].equals("vsync"))
                {
                    vSync = as[1].equals("true");
                }
                if(as[0].equals("notextures"))
                {
                    noTextures = as[1].equals("true");
                }
                if(as[0].equals("skin"))
                {
                    skin = as[1];
                }
                if(as[0].equals("rantick"))
                {
                    randomTickRate = Integer.parseInt(as[1]);
                }
                if(as[0].equals("hints"))
                {
                    hints = as[1].equals("true");
                }
                int i = 0;
                while(i < keyBindings.length) 
                {
                    if(as[0].equals((new StringBuilder()).append("key_").append(keyBindings[i].keyDescription).toString()))
                    {
                        keyBindings[i].keyCode = Integer.parseInt(as[1]);
                    }
                    i++;
                }
                i = 0;
                /*while(i < buttonBindings.length) 
                {
                    if(as[0].equals((new StringBuilder()).append("button_").append(buttonBindings[i].keyDescription).toString()))
                    {
                        buttonBindings[i].keyCode = Integer.parseInt(as[1]);
                    }
                    i++;
                }*/
            }

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            System.out.println("Failed to load options");
            exception.printStackTrace();
        }
    }

    private float func_1050_a(String s)
    {
        if(s.equals("true"))
        {
            return 1.0F;
        }
        if(s.equals("false"))
        {
            return 0.0F;
        } else
        {
            return Float.parseFloat(s);
        }
    }

    public void save()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(optionsFile));
            printwriter.println((new StringBuilder()).append("music:").append(musicVolume).toString());
            printwriter.println((new StringBuilder()).append("sound:").append(soundVolume).toString());
            printwriter.println((new StringBuilder()).append("ambience:").append(ambienceVolume).toString());
            printwriter.println((new StringBuilder()).append("FOV:").append(FOV).toString());
            printwriter.println((new StringBuilder()).append("invertYMouse:").append(invertMouse).toString());
            printwriter.println((new StringBuilder()).append("mouseSensitivity:").append(mouseSensitivity).toString());
            printwriter.println((new StringBuilder()).append("modemVolume:").append(modemVolume).toString());
            printwriter.println((new StringBuilder()).append("viewDistance:").append(renderDistance).toString());
            printwriter.println((new StringBuilder()).append("bobView:").append(viewBobbing).toString());
            printwriter.println((new StringBuilder()).append("anaglyph3d:").append(anaglyph).toString());
            printwriter.println((new StringBuilder()).append("limitFramerate:").append(limitFramerate).toString());
            printwriter.println((new StringBuilder()).append("difficulty:").append(difficulty).toString());
            printwriter.println((new StringBuilder()).append("guiScale:").append(guiScale).toString());
            printwriter.println((new StringBuilder()).append("fancyGraphics:").append(fancyGraphics).toString());
            printwriter.println((new StringBuilder()).append("lastServer:").append(lastServer));
            printwriter.println((new StringBuilder()).append("fog:").append(fog).toString());
            printwriter.println((new StringBuilder()).append("Clouds:").append(clouds).toString());
            printwriter.println((new StringBuilder()).append("particles:").append(particles).toString());
            printwriter.println((new StringBuilder()).append("ignoreJavaWarning:").append(ignoreJavaWarning).toString());
            printwriter.println((new StringBuilder()).append("saverate:").append(chunkSavingInterval).toString());
            printwriter.println((new StringBuilder()).append("advancedopengl:").append(advancedOpenGL).toString());
            printwriter.println((new StringBuilder()).append("displayMode:").append(displayMode).toString());
            printwriter.println((new StringBuilder()).append("cloudLevel:").append(cloudLevel).toString());
            printwriter.println((new StringBuilder()).append("leafLevel:").append(leafLevel).toString());
            printwriter.println((new StringBuilder()).append("precipLevel:").append(precipLevel).toString());
            printwriter.println((new StringBuilder()).append("vignette:").append(vignette).toString());
            printwriter.println((new StringBuilder()).append("mobShadows:").append(mobShadows).toString());
            printwriter.println((new StringBuilder()).append("vsync:").append(vSync).toString());
            printwriter.println((new StringBuilder()).append("notextures:").append(noTextures).toString());
            printwriter.println((new StringBuilder()).append("skin:").append(skin).toString());
            printwriter.println((new StringBuilder()).append("rantick:").append(randomTickRate).toString());
            printwriter.println((new StringBuilder()).append("hints:").append(hints).toString());
            for(int i = 0; i < keyBindings.length; i++)
            {
                printwriter.println((new StringBuilder()).append("key_").append(keyBindings[i].keyDescription).append(":").append(keyBindings[i].keyCode).toString());
            }
            /*for(int i = 0; i < buttonBindings.length; i++)
            {
                printwriter.println((new StringBuilder()).append("button_").append(buttonBindings[i].keyDescription).append(":").append(buttonBindings[i].keyCode).toString());
            }*/

            printwriter.close();
        }
        catch(Exception exception)
        {
            System.out.println("Failed to save options");
            exception.printStackTrace();
        }
    }

    private static final String RENDER_DISTANCES[] = {
        "FURTHEST", "FURTHER", "FAR", "NORMAL", "SHORT", "TINY"
    };
    private static final String DIFFICULTY_LEVELS[] = {
        "Peaceful", "Easy", "Normal", "Hard"
    };
    private static final String GUI_SCALES[] = {
    		"Big", "Eyestrain", "Small", "Normal"
    };
    private static final String CLOUD_LEVELS[] = {
    		"OFF", "FAST", "FANCY"
    };
    private static final String LEAF_LEVELS[] = {
    		"FAST", "QUICK", "PRETTY", "FANCY"
    };
    
    public String lastServer;
    public float musicVolume;
    public float soundVolume;
    public float ambienceVolume;
    public float mouseSensitivity;
    public float modemVolume;
    public boolean invertMouse;
    public int renderDistance;
    public boolean viewBobbing;
    public boolean anaglyph;
    public boolean limitFramerate;
    public boolean fancyGraphics;
    public String skin;
    public KeyBinding keyBindForward;
    public KeyBinding keyBindLeft;
    public KeyBinding keyBindBack;
    public KeyBinding keyBindRight;
    public KeyBinding keyBindJump;
    public KeyBinding keyBindBuild;
    public KeyBinding keyBindInventory;
    public KeyBinding keyBindDrop;
    public KeyBinding keyBindChat;
    public KeyBinding keyBindToggleFog;
    public KeyBinding keyBindSneak;
    public KeyBinding keyBindRun;
    public KeyBinding keyBindSaveLocation;
    public KeyBinding keyBindLoadLocation;
    public KeyBinding keyBindAttack;
    public KeyBinding keyBindUse;
    public KeyBinding keyBindings[];
    

    /*public KeyBinding buttonBindAttack;
    public KeyBinding buttonBindUse;
    public KeyBinding buttonBindEscape;
    public KeyBinding buttonBindPick;
    public KeyBinding buttonBindJump;
    public KeyBinding buttonBindBuild;
    public KeyBinding buttonBindInventory;
    public KeyBinding buttonBindDrop;
    public KeyBinding buttonBindChat;
    public KeyBinding buttonBindToggleFog;
    public KeyBinding buttonBindSneak;
    public KeyBinding buttonBindRun;
    public KeyBinding buttonBindSaveLocation;
    public KeyBinding buttonBindLoadLocation;
    public KeyBinding buttonBindings[];*/
    
    public Minecraft mc;
    private File optionsFile;
    public int numberOfOptions;
    public int difficulty;
    public int chunkSavingInterval;
    public int guiScale;
    public int FOV;
    public boolean thirdPersonView;
    public boolean fog;
    public boolean clouds;
    public boolean particles;
    public boolean advancedOpenGL;
    public int displayMode;
    public int cloudLevel;
    public int leafLevel;
    public boolean precipLevel;
    public boolean vignette;
    public boolean mobShadows;
    public boolean vSync;
    public boolean hints;
    
    public boolean noTextures/* = false*/;
	public boolean firstPersonParticles = false;

    public boolean hideUI;
    public boolean smoothCamera;
    public int randomTickRate;
    
    public boolean ignoreJavaWarning;
    
    
    

	ArrayList<DisplayMode> Resolutions = new ArrayList<DisplayMode>();
	public ArrayList<String> Modes = new ArrayList<String>();

}
