package com.mojang.minecraft.render;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.nio.FloatBuffer;
import java.util.List;
import java.util.Random;

import org.lwjgl.input.Keyboard;
//import net.minecraft.client.Minecraft;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.*;
import org.lwjgl.util.glu.GLU;

import com.mojang.minecraft.Minecraft;
import com.mojang.minecraft.entity.Entity;
import com.mojang.minecraft.entity.EntityPlayer;
import com.mojang.minecraft.entity.EntityPlayerSP;
import com.mojang.minecraft.entity.EntityRainFX;
import com.mojang.minecraft.entity.MovingObjectPosition;
import com.mojang.minecraft.entity.item.Item;
import com.mojang.minecraft.entity.item.ItemRenderer;
import com.mojang.minecraft.level.World;
import com.mojang.minecraft.level.chunk.ChunkProviderLoadOrGenerate;
import com.mojang.minecraft.level.generate.IChunkProvider;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.level.tile.material.Material;
import com.mojang.minecraft.level.tile.phys.AxisAlignedBB;
import com.mojang.minecraft.level.tile.phys.ClippingHelperImplementation;
import com.mojang.minecraft.player.controller.PlayerControllerCreative;
import com.mojang.minecraft.util.MathHelper;

public class EntityRenderer {

    public EntityRenderer(Minecraft minecraft) {
        farPlaneDistance = 0.0F;
        field_1385_k = null;
        field_21155_l = 1.0D;
        field_21154_m = 0.0D;
        field_21153_n = 0.0D;
        field_1384_l = System.currentTimeMillis();
        random = new Random();
        field_1394_b = 0;
        field_1393_c = 0;
        field_1392_d = GLAllocation.func_1123_d(16);
        mc = minecraft;
        itemRenderer = new ItemRenderer(minecraft);
    }

    public void updateRenderer() {
        field_1382_n = hasSubtypes;
        float f = mc.mcWorld.getBrightness(MathHelper.floor_double(mc.thePlayer.posX), MathHelper.floor_double(mc.thePlayer.posY), MathHelper.floor_double(mc.thePlayer.posZ));
        float f1 = (float) (3 - mc.options.renderDistance) / 3F;
        float f2 = f * (1.0F - f1) + f1;
        hasSubtypes += (f2 - hasSubtypes) * 0.1F;
        field_1386_j++;
        itemRenderer.updateEquippedItem();
        if(mc.enableRain) {
            //raining();
            //rainFall(f);
        }
    }
    
    public void getMouseOver(float f)
    {
        if(mc.thePlayer != null)
        {
            double d = mc.playerController.getBlockReachDistance();
            mc.objectMouseOver = mc.thePlayer.rayTrace(d, f);
            double d1 = d;
            Vec3D vec3d = mc.thePlayer.getPosition(f);
            if(mc.objectMouseOver != null)
            {
                d1 = mc.objectMouseOver.hitVec.distanceTo(vec3d);
            }
            if(mc.playerController instanceof PlayerControllerCreative)
            {
                d = 32D;
                d1 = 32D;
            } else
            {
                if(d1 > 3D)
                {
                    d1 = 3D;
                }
                d = d1;
            }
            Vec3D vec3d1 = mc.thePlayer.getLook(f);
            Vec3D vec3d2 = vec3d.addVector(vec3d1.xCoord * d, vec3d1.yCoord * d, vec3d1.zCoord * d);
            field_1385_k = null;
            float f1 = 1.0F;
            List list = mc.mcWorld.getEntitiesWithinAABBExcludingEntity(mc.thePlayer, mc.thePlayer.boundingBox.addCoord(vec3d1.xCoord * d, vec3d1.yCoord * d, vec3d1.zCoord * d).expand(f1, f1, f1));
            double d2 = 0.0D;
            for(int i = 0; i < list.size(); i++)
            {
                Entity entity = (Entity)list.get(i);
                if(!entity.canBeCollidedWith())
                {
                    continue;
                }
                float f2 = 0.1F;//entity.getCollisionBorderSize();
                AxisAlignedBB axisalignedbb = entity.boundingBox.expand(f2, f2, f2);
                MovingObjectPosition movingobjectposition = axisalignedbb.func_1169_a(vec3d, vec3d2);
                if(axisalignedbb.isVecInside(vec3d))
                {
                    if(0.0D < d2 || d2 == 0.0D)
                    {
                        field_1385_k = entity;
                        d2 = 0.0D;
                    }
                    continue;
                }
                if(movingobjectposition == null)
                {
                    continue;
                }
                double d3 = vec3d.distanceTo(movingobjectposition.hitVec);
                if(d3 < d2 || d2 == 0.0D)
                {
                    field_1385_k = entity;
                    d2 = d3;
                }
            }

            if(field_1385_k != null)
            {
                mc.objectMouseOver = new MovingObjectPosition(field_1385_k);
            }
        }
    }

    /*public void getMouseOver_(float f) {
        if(mc.thePlayer == null) {
            return;
        }
        double d = mc.playerController.getBlockReachDistance();
        mc.objectMouseOver = mc.thePlayer.rayTrace(d, f);
        double d1 = d;
        Vec3D vec3d = mc.thePlayer.getPosition(f);
        if(mc.objectMouseOver != null) {
            d1 = mc.objectMouseOver.hitVec.distanceTo(vec3d);
        }
        if(mc.playerController instanceof PlayerControllerCreative) {
            d1 = d = 32D;
        } else {
            if(d1 > 3D) {
                d1 = 3D;
            }
            d = d1;
        }
        Vec3D vec3d1 = mc.thePlayer.getLook(f);
        Vec3D vec3d2 = vec3d.addVector(vec3d1.xCoord * d, vec3d1.yCoord * d, vec3d1.zCoord * d);
        field_1385_k = null;
        List<Entity> list = mc.mcWorld.getEntitiesWithinAABBExcludingEntity(mc.thePlayer, mc.thePlayer.boundingBox.addCoord(vec3d1.xCoord * d, vec3d1.yCoord * d, vec3d1.zCoord * d));
        double d2 = 0.0D;
        for(int i = 0; i < list.size(); i++) {
            Entity entity = (Entity) list.get(i);
            if(!entity.canBeCollidedWith()) {
                continue;
            }
            float f1 = 0.1F;
            AxisAlignedBB axisalignedbb = entity.boundingBox.expand(f1, f1, f1);
            MovingObjectPosition movingobjectposition = axisalignedbb.func_1169_a(vec3d, vec3d2);
            if(movingobjectposition == null) {
                continue;
            }
            double d3 = vec3d.distanceTo(movingobjectposition.hitVec);
            if(d3 < d2 || d2 == 0.0D) {
                field_1385_k = entity;
                d2 = d3;
            }
        }

        if(field_1385_k != null/* && !(mc.playerController instanceof PlayerControllerCreative)*//*) {
            mc.objectMouseOver = new MovingObjectPosition(field_1385_k);
        }
    }*/

    private float getFOV(float f) {
        EntityPlayerSP entityplayersp = mc.thePlayer;
        float f1 = 70F;
        if(entityplayersp.isInsideOfMaterial(Material.water)) {
            f1 = 60F;
        }
        if(entityplayersp.isRunning() && mc.options.difficulty < 3) {
            f1 = 71.5F;
        }
        if(entityplayersp.health <= 0) {
            float f2 = (float) entityplayersp.deathTime + f;
            f1 /= (1.0F - 500F / (f2 + 500F)) * 2.0F + 1.0F;
        }
        return f1 + mc.options.FOV;
    }

    private void hurtCameraEffect(float f) {
        EntityPlayerSP entityplayersp = mc.thePlayer;
        float f1 = (float)entityplayersp.hurtTime - f;
        if(entityplayersp.health <= 0) {
            float f2 = (float)entityplayersp.deathTime + f;
            GL11.glRotatef(40F - 8000F / (f2 + 200F), 0.0F, 0.0F, 1.0F);
        }
        if(f1 >= 0.0F) {
            f1 /= entityplayersp.maxHurtTime;
            f1 = MathHelper.sin(f1 * f1 * f1 * f1 * 3.141593F);
            float f3 = entityplayersp.attackedAtYaw;
            GL11.glRotatef(-f3, 0.0F, 1.0F, 0.0F);
            GL11.glRotatef(-f1 * 14F, 0.0F, 0.0F, 1.0F);
            GL11.glRotatef(f3, 0.0F, 1.0F, 0.0F);
        }
    }

    private void setupViewBobbing(float f) {
        if(!mc.options.thirdPersonView) {
            EntityPlayerSP entityplayersp = mc.thePlayer;
            float f1 = entityplayersp.distanceWalkedModified - entityplayersp.prevDistanceWalkedModified;
            float f2 = entityplayersp.distanceWalkedModified + f1 * f;
            float f3 = entityplayersp.field_775_e + (entityplayersp.field_774_f - entityplayersp.field_775_e) * f;
            float f4 = entityplayersp.lookPitch + (entityplayersp.field_709_M - entityplayersp.lookPitch) * f;
            GL11.glTranslatef(MathHelper.sin(f2 * 3.141593F) * f3 * 0.5F, -Math.abs(MathHelper.cos(f2 * 3.141593F) * f3), 0.0F);
            GL11.glRotatef(MathHelper.sin(f2 * 3.141593F) * f3 * 3F, 0.0F, 0.0F, 1.0F);
            GL11.glRotatef(Math.abs(MathHelper.cos(f2 * 3.141593F + 0.2F) * f3) * 5F, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(f4, 1.0F, 0.0F, 0.0F);
        }
    }
    
    private void orientCamera(float f)
    {
        EntityPlayerSP entityplayersp = mc.thePlayer;
        double d = entityplayersp.prevPosX + (entityplayersp.posX - entityplayersp.prevPosX) * (double)f;
        double d1 = entityplayersp.prevPosY + (entityplayersp.posY - entityplayersp.prevPosY) * (double)f;
        double d2 = entityplayersp.prevPosZ + (entityplayersp.posZ - entityplayersp.prevPosZ) * (double)f;
        if(mc.options.thirdPersonView)
        {
            double d3 = 4D;
            float f1 = entityplayersp.rotationYaw;
            float f2 = entityplayersp.rotationPitch;
            if(Keyboard.isKeyDown(59))
            {
                f2 += 180F;
                d3 += 2D;
            }
            double d4 = (double)(-MathHelper.sin((f1 / 180F) * 3.141593F) * MathHelper.cos((f2 / 180F) * 3.141593F)) * d3;
            double d5 = (double)(MathHelper.cos((f1 / 180F) * 3.141593F) * MathHelper.cos((f2 / 180F) * 3.141593F)) * d3;
            double d6 = (double)(-MathHelper.sin((f2 / 180F) * 3.141593F)) * d3;
            for(int i = 0; i < 8; i++)
            {
                float f3 = (i & 1) * 2 - 1;
                float f4 = (i >> 1 & 1) * 2 - 1;
                float f5 = (i >> 2 & 1) * 2 - 1;
                f3 *= 0.1F;
                f4 *= 0.1F;
                f5 *= 0.1F;
                MovingObjectPosition movingobjectposition = mc.mcWorld.rayTraceBlocks(Vec3D.createVector(d + (double)f3, d1 + (double)f4, d2 + (double)f5), Vec3D.createVector((d - d4) + (double)f3 + (double)f5, (d1 - d6) + (double)f4, (d2 - d5) + (double)f5));
                if(movingobjectposition == null)
                {
                    continue;
                }
                double d7 = movingobjectposition.hitVec.distanceTo(Vec3D.createVector(d, d1, d2));
                if(d7 < d3)
                {
                    d3 = d7;
                }
            }

            if(Keyboard.isKeyDown(59))
            {
                GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
            }
            GL11.glRotatef(entityplayersp.rotationPitch - f2, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(entityplayersp.rotationYaw - f1, 0.0F, 1.0F, 0.0F);
            GL11.glTranslatef(0.0F, 0.0F, (float)(-d3));
            GL11.glRotatef(f1 - entityplayersp.rotationYaw, 0.0F, 1.0F, 0.0F);
            GL11.glRotatef(f2 - entityplayersp.rotationPitch, 1.0F, 0.0F, 0.0F);
        } else
        {
            GL11.glTranslatef(0.0F, 0.0F, -0.1F);
        }
        GL11.glRotatef(entityplayersp.prevRotationPitch + (entityplayersp.rotationPitch - entityplayersp.prevRotationPitch) * f, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(entityplayersp.prevRotationYaw + (entityplayersp.rotationYaw - entityplayersp.prevRotationYaw) * f + 180F, 0.0F, 1.0F, 0.0F);
    }

    /*private void orientCamera(float f) {
        EntityPlayerSP entityplayersp = mc.thePlayer;
        double d = entityplayersp.prevPosX + (entityplayersp.posX - entityplayersp.prevPosX) * (double) f;
        double d1 = entityplayersp.prevPosY + (entityplayersp.posY - entityplayersp.prevPosY) * (double) f;
        double d2 = entityplayersp.prevPosZ + (entityplayersp.posZ - entityplayersp.prevPosZ) * (double) f;
        if(mc.options.thirdPersonView) {
            double d3 = 4D;
            float f1 = entityplayersp.rotationYaw;
            float f2 = entityplayersp.rotationPitch;
            double d4 = (double) (-MathHelper.sin((f1 / 180F) * 3.141593F) * MathHelper.cos((f2 / 180F) * 3.141593F)) * d3;
            double d5 = (double) (MathHelper.cos((f1 / 180F) * 3.141593F) * MathHelper.cos((f2 / 180F) * 3.141593F)) * d3;
            double d6 = (double) (-MathHelper.sin((f2 / 180F) * 3.141593F)) * d3;
            for(int i = 0; i < 8; i++) {
                float f3 = (i & 1) * 2 - 1;
                float f4 = (i >> 1 & 1) * 2 - 1;
                float f5 = (i >> 2 & 1) * 2 - 1;
                f3 *= 0.1F;
                f4 *= 0.1F;
                f5 *= 0.1F;
                MovingObjectPosition movingobjectposition = mc.mcWorld.rayTraceBlocks(Vec3D.createVector(d + (double) f3, d1 + (double) f4, d2 + (double) f5), Vec3D.createVector((d - d4) + (double) f3 + (double) f5, (d1 - d6) + (double) f4, (d2 - d5) + (double) f5));
                if(movingobjectposition == null) {
                    continue;
                }
                double d7 = movingobjectposition.hitVec.distanceTo(Vec3D.createVector(d, d1, d2));
                if(d7 < d3) {
                    d3 = d7;
                }
            }

            GL11.glRotatef(((EntityPlayer) (entityplayersp)).rotationPitch - f2, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(((EntityPlayer) (entityplayersp)).rotationYaw - f1, 0.0F, 1.0F, 0.0F);
            GL11.glTranslatef(0.0F, 0.0F, (float) (-d3));
            GL11.glRotatef(f1 - ((EntityPlayer) (entityplayersp)).rotationYaw, 0.0F, 1.0F, 0.0F);
            GL11.glRotatef(f2 - ((EntityPlayer) (entityplayersp)).rotationPitch, 1.0F, 0.0F, 0.0F);
        } else {
            GL11.glTranslatef(0.0F, 0.0F, -0.1F);
        }
        GL11.glRotatef(((EntityPlayer) (entityplayersp)).prevRotationPitch + (((EntityPlayer) (entityplayersp)).rotationPitch - ((EntityPlayer) (entityplayersp)).prevRotationPitch) * f, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(((EntityPlayer) (entityplayersp)).prevRotationYaw + (((EntityPlayer) (entityplayersp)).rotationYaw - ((EntityPlayer) (entityplayersp)).prevRotationYaw) * f + 180F, 0.0F, 1.0F, 0.0F);
    }*/

    private void setupCameraTransform(float f, int i) {
    	if(mc.options.fog){
    		if(mc.options.renderDistance > 0){
    			farPlaneDistance = 256 >> mc.options.renderDistance; //Determines how far away fog should be rendered (originally 256)
    		}else{
    			farPlaneDistance = 256 << -mc.options.renderDistance;
    		}
    	}else{
    		farPlaneDistance = 256 << 1; //forces fog to stay as far as possible (originally 256 >> 0)
    	}
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        float f1 = 0.07F;
        if(mc.options.anaglyph) {
            GL11.glTranslatef((float) (-(i * 2 - 1)) * f1, 0.0F, 0.0F);
        }
        GLU.gluPerspective(getFOV(f), (float) mc.displayWidth / (float) mc.displayHeight, 0.05F, farPlaneDistance);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        if(mc.options.anaglyph) {
            GL11.glTranslatef((float) (i * 2 - 1) * 0.1F, 0.0F, 0.0F);
        }
        hurtCameraEffect(f);
        if(mc.options.viewBobbing) {
            setupViewBobbing(f);
        }
        orientCamera(f);
    }

    private void func_907_b(float f, int i) {
        GL11.glLoadIdentity();
        if(mc.options.anaglyph) {
            GL11.glTranslatef((float) (i * 2 - 1) * 0.1F, 0.0F, 0.0F);
        }
        GL11.glPushMatrix();
        hurtCameraEffect(f);
        if(mc.options.viewBobbing) {
            setupViewBobbing(f);
        }
        if(!mc.options.thirdPersonView) {
            itemRenderer.func_894_a(f);
        }
        GL11.glPopMatrix();
        if(!mc.options.thirdPersonView) {
            itemRenderer.func_893_b(f);
            hurtCameraEffect(f);
        }
        if(mc.options.viewBobbing) {
            setupViewBobbing(f);
        }
    }

    public void func_909_b(float f) {
        if(!Display.isActive()) {
            if(System.currentTimeMillis() - field_1384_l > 500L) {
                mc.func_117_g();
            }
        } else {
            field_1384_l = System.currentTimeMillis();
        }
        if(mc.field_150_I) {
            mc.mouseHelper.mouseXYChange();
            float f1 = mc.options.mouseSensitivity * 0.6F + 0.2F;
            float f2 = f1 * f1 * f1 * 8F;
            float f3 = (float) mc.mouseHelper.field_1114_a * f2;
            float f4 = (float) mc.mouseHelper.field_1113_b * f2;
            int l = 1;
            if(mc.options.invertMouse) {
                l = -1;
            }
            mc.thePlayer.func_346_d(f3, f4 * (float) l);
        }
        
        if(!mc.field_163_v)
        {
            ScaledResolution scaledresolution = new ScaledResolution(mc.displayWidth, mc.displayHeight, mc);
            int i = scaledresolution.getScaledWidth();
            int j = scaledresolution.getScaledHeight();
            int k = (Mouse.getX() * i) / mc.displayWidth;
            int i1 = j - (Mouse.getY() * j) / mc.displayHeight - 1;
            if(mc.mcWorld != null)
            {
                renderWorld(f);
                if(!Keyboard.isKeyDown(59))
                {
                    mc.ingameGUI.renderGameOverlay(f, mc.currentScreen != null, k, i1);
                }
            } else
            {
                GL11.glViewport(0, 0, mc.displayWidth, mc.displayHeight);
                GL11.glMatrixMode(5889 /*GL_PROJECTION*/);
                GL11.glLoadIdentity();
                GL11.glMatrixMode(5888 /*GL_MODELVIEW0_ARB*/);
                GL11.glLoadIdentity();
                func_905_b();
            }
            if(mc.currentScreen != null)
            {
                GL11.glClear(256);
                mc.currentScreen.drawScreen(k, i1, f);
            }
        }
        
        /*if(mc.field_163_v) {
            return;
        }
        ScaledResolution scaledresolution = new ScaledResolution(mc.displayWidth, mc.displayHeight, mc);
        int i = scaledresolution.getScaledWidth();
        int j = scaledresolution.getScaledHeight();
        int k = (Mouse.getX() * i) / mc.displayWidth;
        int i1 = j - (Mouse.getY() * j) / mc.displayHeight - 1;
        if(mc.mcWorld != null) {
            renderWorld(f);
            mc.ingameGUI.func_557_a(f, mc.currentScreen != null, k, i1);
        } else {
            GL11.glViewport(0, 0, mc.displayWidth, mc.displayHeight);
            GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            GL11.glClear(16640);
            GL11.glMatrixMode(5889);
            GL11.glLoadIdentity();
            GL11.glMatrixMode(5888);
            GL11.glLoadIdentity();
            func_905_b();
        }
        if(mc.currentScreen != null) {
            GL11.glClear(256);
            mc.currentScreen.drawScreen(k, i1, f);
        }*/
    }

    public void renderWorld(float f) {
        getMouseOver(f);
        EntityPlayerSP entityplayersp = mc.thePlayer;
        RenderGlobal renderglobal = mc.field_179_f;
        EffectRenderer effectrenderer = mc.effectRenderer;
        double d = entityplayersp.lastTickPosX + (entityplayersp.posX - entityplayersp.lastTickPosX) * (double) f;
        double d1 = entityplayersp.lastTickPosY + (entityplayersp.posY - entityplayersp.lastTickPosY) * (double) f;
        double d2 = entityplayersp.lastTickPosZ + (entityplayersp.posZ - entityplayersp.lastTickPosZ) * (double) f;
        IChunkProvider ichunkprovider = mc.mcWorld.getIChunkProvider();
        if(ichunkprovider instanceof ChunkProviderLoadOrGenerate)
        {
            ChunkProviderLoadOrGenerate chunkproviderloadorgenerate = (ChunkProviderLoadOrGenerate)ichunkprovider;
            int l = MathHelper.floor_float((int)d) >> 4;
            int i = MathHelper.floor_float((int)d2) >> 4;
            chunkproviderloadorgenerate.setCurrentChunkOver(l, i);
        }
        for(int k = 0; k < 2; k++) {
            if(mc.options.anaglyph) {
                if(k == 0) {
                    GL11.glColorMask(false, true, true, false);
                } else {
                    GL11.glColorMask(true, false, false, false);
                }
            }
            GL11.glViewport(0, 0, mc.displayWidth, mc.displayHeight);
            updateFogColor(f);
            //GL11.glClear(16640);
            GL11.glClear(16384 /*GL_LIGHT0*/);
            GL11.glClear(256);
            GL11.glEnable(2884);
            setupCameraTransform(f, k);
            ClippingHelperImplementation.func_1155_a();
            if(mc.options.fog){
	            if(mc.options.renderDistance < 4) {
	            	renderFog(-1);
	                renderglobal.renderSky(f);
	            }
            }else{
            	renderFog(4);
            	renderglobal.renderSky(f);

            }
            GL11.glEnable(2912);
            renderFog(1);
            GL11.glShadeModel(7425 /*GL_SMOOTH*/);
            Frustrum frustrum = new Frustrum();
            //frustrum.func_343_a(-100, 50, 100);
            //System.out.println(entityplayersp.motionX);
            frustrum.func_343_a(d, d1, d2);
            mc.field_179_f.func_960_a(frustrum, f);
            mc.field_179_f.updateRenderers(entityplayersp, false);
            renderFog(0);
            GL11.glEnable(2912);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, mc.renderEngine.getTex("/terrain.png"));
            RenderHelper.disableStandardItemLighting();
            renderglobal.func_943_a(entityplayersp, 0, f);
            GL11.glShadeModel(7424 /*GL_FLAT*/);
            RenderHelper.enableStandardItemLighting();
            renderglobal.handleTileEntityRendering(entityplayersp.getPosition(f), frustrum, f);
            effectrenderer.func_1187_b(entityplayersp, f);
            RenderHelper.disableStandardItemLighting();
            renderFog(0);
            effectrenderer.renderParticles(entityplayersp, f);
            if(mc.objectMouseOver != null && entityplayersp.isInsideOfMaterial(Material.water)) {
                GL11.glDisable(3008);
                renderglobal.renderHeldItem(entityplayersp, mc.objectMouseOver, 0, entityplayersp.inventory.getCurrentItem(), f);
                renderglobal.drawSelectionBox(entityplayersp, mc.objectMouseOver, 0, entityplayersp.inventory.getCurrentItem(), f);
                GL11.glEnable(3008);
            }
            GL11.glBlendFunc(770, 771);
            renderFog(0);
            GL11.glEnable(3042);
            GL11.glDisable(2884);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, mc.renderEngine.getTex("/terrain.png"));
            if(mc.options.fancyGraphics) {
            	GL11.glShadeModel(7425 /*GL_SMOOTH*/);
                /*GL11.glColorMask(false, false, false, false);
                int j = renderglobal.func_943_a(entityplayersp, 1, f);
                GL11.glColorMask(true, true, true, true);*/
                if(mc.options.anaglyph) {
                    if(k == 0) {
                        GL11.glColorMask(false, true, true, false);
                    } else {
                        GL11.glColorMask(true, false, false, false);
                    }
                }
                /*if(j > 0) {
                    renderglobal.func_944_a(1, f);
                }*/
                int j = renderglobal.func_943_a(entityplayersp, 1, f);
                GL11.glShadeModel(7424 /*GL_FLAT*/);
            } else {
                renderglobal.func_943_a(entityplayersp, 1, f);
            }
            GL11.glDepthMask(true);
            GL11.glEnable(2884);
            GL11.glDisable(3042);
            if(mc.objectMouseOver != null && !entityplayersp.isInsideOfMaterial(Material.water)) {
                GL11.glDisable(3008);
                renderglobal.renderHeldItem(entityplayersp, mc.objectMouseOver, 0, entityplayersp.inventory.getCurrentItem(), f);
                renderglobal.drawSelectionBox(entityplayersp, mc.objectMouseOver, 0, entityplayersp.inventory.getCurrentItem(), f);
                GL11.glEnable(3008);
            }
            GL11.glDisable(2912);
            if(mc.mcWorld.snowCovered) {
                snowFall(f);
            }
            if(mc.enableRain) {
                rainFall(f);
                if(mc.currentScreen == null)
                raining();
            }
            if(field_1385_k == null) ;
            renderFog(0);
            GL11.glEnable(2912);
            renderglobal.func_947_b(f);
            GL11.glDisable(2912);
            renderFog(1);
            GL11.glClear(256);
            func_907_b(f, k);
            if(!mc.options.anaglyph) {
                return;
            }
        }

        GL11.glColorMask(true, true, true, false);
    }

    private void raining() { //rainfall
        if(mc.options.fancyGraphics && mc.options.particles == true) {
	        EntityPlayerSP entityplayersp = mc.thePlayer;
	        World world = mc.mcWorld;
	        int i = MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posX);
	        int j = MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posY);
	        int k = MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posZ);
	        byte byte0 = 16;
	        //rainFall(1.0F);
	        for(int l = 0; l < 150; l++) {
	            int i1 = (i + random.nextInt(byte0)) - random.nextInt(byte0);
	            int j1 = (k + random.nextInt(byte0)) - random.nextInt(byte0);
	            int k1 = world.func_696_e(i1, j1);
	            int l1 = world.getBlockId(i1, k1 - 1, j1);
	            if(k1 > j + byte0 || k1 < j - byte0) {
	                continue;
	            }
	            Random random2 = new Random();
	            float f = random2.nextFloat();
	            float f1 = random2.nextFloat();
	            if(l1 > 0) {
	                //field_1388_h.field_177_h.func_1192_a(new EntityRainFX(world, (float) i1 + f, (double) ((float) k1 + 0.1F) - Block.allBlocks[l1].field_368_bg, (float) j1 + f1));
	            	mc.effectRenderer.addEffect(new EntityRainFX(world, (float) i1 + f, (double) ((float) k1 + 0.1F) - Block.allBlocks[l1].minY, (float) j1 + f1));
	            }
	        }
        }
    }
    private void rainFall(float f) { //rainfall also
        EntityPlayerSP entityplayersp = mc.thePlayer;
        World world = mc.mcWorld;
        int i = MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posX);
        int j = MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posY);
        int k = MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posZ);
        Tessellator tessellator = Tessellator.instance;
        GL11.glDisable(2884);
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, mc.renderEngine.getTex("/rain.png"));
        double d = ((EntityPlayer) (entityplayersp)).lastTickPosX + (((EntityPlayer) (entityplayersp)).posX - ((EntityPlayer) (entityplayersp)).lastTickPosX) * (double) f;
        double d1 = ((EntityPlayer) (entityplayersp)).lastTickPosY + (((EntityPlayer) (entityplayersp)).posY - ((EntityPlayer) (entityplayersp)).lastTickPosY) * (double) f;
        double d2 = ((EntityPlayer) (entityplayersp)).lastTickPosZ + (((EntityPlayer) (entityplayersp)).posZ - ((EntityPlayer) (entityplayersp)).lastTickPosZ) * (double) f;
        int l = 5;
        if(mc.options.fancyGraphics) {
            l = 10;
        }
        for(int i1 = i - l; i1 <= i + l; i1++) {
            for(int j1 = k - l; j1 <= k + l; j1++) {
                int k1 = world.getTopSolidOrLiquidBlock(i1, j1);
                if(k1 < 0) {
                    k1 = 0;
                }
                int l1 = j - l;
                int i2 = j + l;
                if(l1 < k1) {
                    l1 = k1;
                }
                if(i2 < k1) {
                    i2 = k1;
                }
                float f1 = 2.0F;
                //field_1388_h.field_177_h.func_1192_a(new EntityRainFX(world, (float) i1 + f, (double) ((float) k1 + 0.1F) - Block.allBlocks[l1].field_368_bg, (float) j1 + f1));
                if(l1 != i2) {
                    random.setSeed(i1 * i1 * 3121 + i1 * 0x2b24abb + j1 * j1 * 0x66397 + j1 * 13761);
                    float f2 = (float) field_1386_j;
                    float f3 = ((float) (field_1386_j & 0x1ff) + f) / 25F;
                    float f4 = random.nextFloat() + f2 * 0.01F * (float) random.nextGaussian();
                    float f5 = random.nextFloat() + f2 * (float) random.nextGaussian() * 0.001F;
                    double d3 = (double) ((float) i1 + 0.5F) - ((EntityPlayer) (entityplayersp)).posX;
                    double d4 = (double) ((float) j1 + 0.5F) - ((EntityPlayer) (entityplayersp)).posZ;
                    float f6 = MathHelper.sqrt_double(d3 * d3 + d4 * d4) / (float) l;
                    tessellator.startDrawingQuads();
                    float f7 = world.getBrightness(i1, 128, j1);
                    GL11.glColor4f(f7, f7, f7, (1.0F - f6 * f6) * 0.7F);
                    tessellator.setTranslationD(-d * 1.0D, -d1 * 1.0D, -d2 * 1.0D);
                    tessellator.addVertexWithUV(i1 + 0, l1, j1 + 0, 0.0F * f1 + f4, ((float) l1 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 1, l1, j1 + 1, 1.0F * f1 + f4, ((float) l1 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 1, i2, j1 + 1, 1.0F * f1 + f4, ((float) i2 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 0, i2, j1 + 0, 0.0F * f1 + f4, ((float) i2 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 0, l1, j1 + 1, 0.0F * f1 + f4, ((float) l1 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 1, l1, j1 + 0, 1.0F * f1 + f4, ((float) l1 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 1, i2, j1 + 0, 1.0F * f1 + f4, ((float) i2 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 0, i2, j1 + 1, 0.0F * f1 + f4, ((float) i2 * f1) / 8F + f3 * f1 + f5);
                    tessellator.setTranslationD(0.0D, 0.0D, 0.0D);
                    tessellator.draw();
                }
            }

        }

        GL11.glEnable(2884);
        GL11.glDisable(3042);
    }

    private void snowFall(float f) { //snowfall
        EntityPlayerSP entityplayersp = mc.thePlayer;
        World world = mc.mcWorld;
        int i = MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posX);
        int j = MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posY);
        int k = MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posZ);
        Tessellator tessellator = Tessellator.instance;
        GL11.glDisable(2884);
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, mc.renderEngine.getTex("/snow.png"));
        double d = ((EntityPlayer) (entityplayersp)).lastTickPosX + (((EntityPlayer) (entityplayersp)).posX - ((EntityPlayer) (entityplayersp)).lastTickPosX) * (double) f;
        double d1 = ((EntityPlayer) (entityplayersp)).lastTickPosY + (((EntityPlayer) (entityplayersp)).posY - ((EntityPlayer) (entityplayersp)).lastTickPosY) * (double) f;
        double d2 = ((EntityPlayer) (entityplayersp)).lastTickPosZ + (((EntityPlayer) (entityplayersp)).posZ - ((EntityPlayer) (entityplayersp)).lastTickPosZ) * (double) f;
        int l = 5;
        if(mc.options.fancyGraphics) {
            l = 10;
        }
        for(int i1 = i - l; i1 <= i + l; i1++) {
            for(int j1 = k - l; j1 <= k + l; j1++) {
                int k1 = world.getTopSolidOrLiquidBlock(i1, j1);
                if(k1 < 0) {
                    k1 = 0;
                }
                int l1 = j - l;
                int i2 = j + l;
                if(l1 < k1) {
                    l1 = k1;
                }
                if(i2 < k1) {
                    i2 = k1;
                }
                float f1 = 2.0F;
                if(l1 != i2) {
                    random.setSeed(i1 * i1 * 3121 + i1 * 0x2b24abb + j1 * j1 * 0x66397 + j1 * 13761);
                    float f2 = (float) field_1386_j + f;
                    float f3 = ((float) (field_1386_j & 0x1ff) + f) / 512F;
                    float f4 = random.nextFloat() + f2 * 0.01F * (float) random.nextGaussian();
                    float f5 = random.nextFloat() + f2 * (float) random.nextGaussian() * 0.001F;
                    double d3 = (double) ((float) i1 + 0.5F) - ((EntityPlayer) (entityplayersp)).posX;
                    double d4 = (double) ((float) j1 + 0.5F) - ((EntityPlayer) (entityplayersp)).posZ;
                    float f6 = MathHelper.sqrt_double(d3 * d3 + d4 * d4) / (float) l;
                    tessellator.startDrawingQuads();
                    float f7 = world.getBrightness(i1, 128, j1);
                    GL11.glColor4f(f7, f7, f7, (1.0F - f6 * f6) * 0.7F);
                    tessellator.setTranslationD(-d * 1.0D, -d1 * 1.0D, -d2 * 1.0D);
                    tessellator.addVertexWithUV(i1 + 0, l1, j1 + 0, 0.0F * f1 + f4, ((float) l1 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 1, l1, j1 + 1, 1.0F * f1 + f4, ((float) l1 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 1, i2, j1 + 1, 1.0F * f1 + f4, ((float) i2 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 0, i2, j1 + 0, 0.0F * f1 + f4, ((float) i2 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 0, l1, j1 + 1, 0.0F * f1 + f4, ((float) l1 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 1, l1, j1 + 0, 1.0F * f1 + f4, ((float) l1 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 1, i2, j1 + 0, 1.0F * f1 + f4, ((float) i2 * f1) / 8F + f3 * f1 + f5);
                    tessellator.addVertexWithUV(i1 + 0, i2, j1 + 1, 0.0F * f1 + f4, ((float) i2 * f1) / 8F + f3 * f1 + f5);
                    tessellator.setTranslationD(0.0D, 0.0D, 0.0D);
                    tessellator.draw();
                }
            }

        }

        GL11.glEnable(2884);
        GL11.glDisable(3042);
    }

    public void func_905_b() {
        ScaledResolution scaledresolution = new ScaledResolution(mc.displayWidth, mc.displayHeight, mc);
        int i = scaledresolution.getScaledWidth();
        int j = scaledresolution.getScaledHeight();
        //GL11.glClear(256);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0D, i, j, 0.0D, 1000D, 3000D);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0F, 0.0F, -2000F);
    }

    private void updateFogColor(float f) {
        World world = mc.mcWorld;
        EntityPlayerSP entityplayersp = mc.thePlayer;
        float f1 = 1.0F;
        if(mc.options.fog){
        	f1 = 1.0F / (float) (4 - mc.options.renderDistance);
        }
        f1 = 1.0F - (float) Math.pow(f1, 0.25D);
        Vec3D vec3d = world.func_626_b(f);
        float f2 = (float) vec3d.xCoord;
        float f3 = (float) vec3d.yCoord;
        float f4 = (float) vec3d.zCoord;
        Vec3D vec3d1 = world.func_686_e(f);
        fogColorRed = (float) vec3d1.xCoord;
        fogColorGreen = (float) vec3d1.yCoord;
        fogColorBlue = (float) vec3d1.zCoord;
        fogColorRed += (f2 - fogColorRed) * f1;
        fogColorGreen += (f3 - fogColorGreen) * f1;
        fogColorBlue += (f4 - fogColorBlue) * f1;
        if(entityplayersp.isInsideOfMaterial(Material.water)) {
            fogColorRed = 0.02F;
            fogColorGreen = 0.02F;
            fogColorBlue = 0.2F;
        } else if(entityplayersp.isInsideOfMaterial(Material.lava)) {
            fogColorRed = 0.6F;
            fogColorGreen = 0.1F;
            fogColorBlue = 0.0F;
        }
        float f5 = field_1382_n + (hasSubtypes - field_1382_n) * f;
        fogColorRed *= f5;
        fogColorGreen *= f5;
        fogColorBlue *= f5;
        if(mc.options.anaglyph) {
            float f6 = (fogColorRed * 30F + fogColorGreen * 59F + fogColorBlue * 11F) / 100F;
            float f7 = (fogColorRed * 30F + fogColorGreen * 70F) / 100F;
            float f8 = (fogColorRed * 30F + fogColorBlue * 70F) / 100F;
            fogColorRed = f6;
            fogColorGreen = f7;
            fogColorBlue = f8;
        }
        GL11.glClearColor(fogColorRed, fogColorGreen, fogColorBlue, 0.0F);
    }

    private void renderFog(int i) {
        EntityPlayerSP entityplayersp = mc.thePlayer;
        GL11.glFog(2918, func_908_a(fogColorRed, fogColorGreen, fogColorBlue, 1.0F));
        GL11.glNormal3f(0.0F, -1F, 0.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        if(entityplayersp.isInsideOfMaterial(Material.water)) {
            GL11.glFogi(2917, 2048);
            if(entityplayersp.inventory.armorInventory[3] != null && entityplayersp.inventory.armorInventory[3].itemID == Item.helmetSponge.shiftedIndex){
            	GL11.glFogf(2914, 0.025F);
            }else{
            	GL11.glFogf(2914, 0.1F);
            }
            
            float f = 0.4F;
            float f2 = 0.4F;
            float f4 = 0.9F;
            if(mc.options.anaglyph) {
                float f6 = (f * 30F + f2 * 59F + f4 * 11F) / 100F;
                float f8 = (f * 30F + f2 * 70F) / 100F;
                float f10 = (f * 30F + f4 * 70F) / 100F;
                f = f6;
                f2 = f8;
                f4 = f10;
            }
        } else if(entityplayersp.isInsideOfMaterial(Material.lava)) {
            GL11.glFogi(2917, 2048);
            GL11.glFogf(2914, 2.0F);
            float f1 = 0.4F;
            float f3 = 0.3F;
            float f5 = 0.3F;
            if(mc.options.anaglyph) {
                float f7 = (f1 * 30F + f3 * 59F + f5 * 11F) / 100F;
                float f9 = (f1 * 30F + f3 * 70F) / 100F;
                float f11 = (f1 * 30F + f5 * 70F) / 100F;
                f1 = f7;
                f3 = f9;
                f5 = f11;
            }
        } else {
            if(true){//field_1388_h.options.fog) {
                GL11.glFogi(2917, GL11.GL_LINEAR);
                GL11.glFogf(2915, farPlaneDistance * 0.25F);
                GL11.glFogf(2916, farPlaneDistance);
                if(i < 0) {
                    GL11.glFogf(2915, 0.0F);
                    GL11.glFogf(2916, farPlaneDistance * 0.8F);
                }
                if(GLContext.getCapabilities().GL_NV_fog_distance) {
                    GL11.glFogi(34138, 34139);
                }
            }/* else {
            	GL11.glFogi(GL11.GL_FOG_MODE, 9729);
                GL11.glFogf(GL11.GL_FOG_START, 10e5f);
                GL11.glFogf(GL11.GL_FOG_END, 10e5f + 100);
                GL11.glDisable(GL11.GL_FOG);
            }*/
        }
        GL11.glEnable(2903);
        GL11.glColorMaterial(1028, 4608);
    }

    private FloatBuffer func_908_a(float f, float f1, float f2, float f3) {
        field_1392_d.clear();
        field_1392_d.put(f).put(f1).put(f2).put(f3);
        field_1392_d.flip();
        return field_1392_d;
    }

    private Minecraft mc;
    private float farPlaneDistance;
    public ItemRenderer itemRenderer;
    private int field_1386_j;
    private Entity field_1385_k;
    private double field_21155_l;
    private double field_21154_m;
    private double field_21153_n;
    private long field_1384_l;
    private Random random;
    volatile int field_1394_b;
    volatile int field_1393_c;
    FloatBuffer field_1392_d;
    float fogColorRed;
    float fogColorGreen;
    float fogColorBlue;
    private float field_1382_n;
    private float hasSubtypes;
}
