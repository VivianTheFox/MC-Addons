package com.mojang.minecraft.render;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.util.*;
import org.lwjgl.opengl.GL11;

import com.mojang.minecraft.entity.Entity;
import com.mojang.minecraft.entity.render.RenderItem;
import com.mojang.minecraft.entity.tile.TileEntity;
import com.mojang.minecraft.entity.tile.TileEntityRenderer;
import com.mojang.minecraft.level.World;
import com.mojang.minecraft.level.chunk.Chunk;
import com.mojang.minecraft.level.chunk.ChunkCache;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.level.tile.phys.AxisAlignedBB;
import com.mojang.minecraft.util.MathHelper;

public class WorldRenderer
{

    public WorldRenderer(World world, List<TileEntity> list, int x, int y, int z, int size, int renderList, int LOD)
    {
        glRenderList = -1;
        isInFrustrum = false;
        skipRenderPass = new boolean[2];
        isVisible = true;
        isInitialized = false;
        tileEntityRenderers = new ArrayList<TileEntity>();
        worldObj = world;
        tileEntities = list;
        sizeWidth = sizeHeight = sizeDepth = size;
        rendererRadius = MathHelper.sqrt_float(sizeWidth * sizeWidth + sizeHeight * sizeHeight + sizeDepth * sizeDepth) / 2.0F;
        glRenderList = renderList;
        posX = -999;
        setPosition(x, y, z);
        needsUpdate = false;
        levelOfDetail = LOD; //Lower LOD means more detail... it's like golf
        //System.out.println("LOD is " + levelOfDetail);
    }

    public void setPosition(int i, int j, int k)
    {
    	if(i != posX || j != posY || k != posZ)
        {
            func_1195_b();
            posX = i;
            posY = j;
            posZ = k;
            field_1746_q = i + sizeWidth / 2;
            field_1743_r = j + sizeHeight / 2;
            field_1741_s = k + sizeDepth / 2;
            field_1752_l = i & 0x3ff;
            field_1751_m = j;
            field_1750_n = k & 0x3ff;
            field_1755_i = i - field_1752_l;
            field_1754_j = j - field_1751_m;
            field_1753_k = k - field_1750_n;
            float f = 2F;
            field_1736_v = AxisAlignedBB.getBoundingBox((float)i - f, (float)j - f, (float)k - f, (float)(i + sizeWidth) + f, (float)(j + sizeHeight) + f, (float)(k + sizeDepth) + f);
            GL11.glNewList(glRenderList + 2, GL11.GL_COMPILE);
            RenderItem.renderAABB(AxisAlignedBB.getBoundingBoxFromPool((float)field_1752_l - f, (float)field_1751_m - f, (float)field_1750_n - f, (float)(field_1752_l + sizeWidth) + f, (float)(field_1751_m + sizeHeight) + f, (float)(field_1750_n + sizeDepth) + f));
            GL11.glEndList();
            markDirty();
            //return;
        }
    }

    private void setupGLTranslation()
    {
        GL11.glTranslatef(field_1752_l, field_1751_m, field_1750_n);
    }

    public void updateRenderer()
    {
    	if(needsUpdate)
        {
            chunksUpdated++;
            int minX = posX;
            int minY = posY;
            int minZ = posZ;
            int maxX = posX + sizeWidth;
            int maxY = posY + sizeHeight;
            int maxZ = posZ + sizeDepth;
            //System.out.println(posY);
            
            for(int k1 = 0; k1 < 2; k1++)
            {
                skipRenderPass[k1] = true;
            }

            Chunk.isLit = false;
            HashSet<TileEntity> hashset = new HashSet<TileEntity>();
            hashset.addAll(tileEntityRenderers);
            tileEntityRenderers.clear();
            int bufferZone = 1;
            ChunkCache chunkcache = new ChunkCache(worldObj, minX - bufferZone, minY - bufferZone, minZ - bufferZone, maxX + bufferZone, maxY + bufferZone, maxZ + bufferZone);
            RenderBlocks renderblocks = new RenderBlocks(chunkcache);
            int passNumber = 0;
            /*if(levelOfDetail > 2 && posY < 48){
            	passNumber = 2;
            }*/
            do
            {
                if(passNumber >= 2)
                {
                    break;
                }
                boolean flag = false;
                boolean flag1 = false;
                boolean madeList = false;
                for(int y = minY; y < maxY; y++)
                {
                    for(int z = minZ; z < maxZ; z++)
                    {
                        for(int x = minX; x < maxX; x++)
                        {
                            int i3 = chunkcache.getBlockId(x, y, z);
                            if(i3 <= 0)
                            {
                                continue;
                            }
                            if(!madeList)
                            {
                            	madeList = true;
                                GL11.glNewList(glRenderList + passNumber, GL11.GL_COMPILE);
                                tessellator.setRenderingChunk(true);
                                //tessellator.startDrawingQuads();
                                

                                //GL11.glPushMatrix();
                                //setupGLTranslation();
                                //float f = 1F;
                                //GL11.glTranslatef((float)(-sizeDepth) / 2.0F, (float)(-sizeHeight) / 2.0F, (float)(-sizeDepth) / 2.0F);
                                //GL11.glScalef(f, f, f);
                                //GL11.glTranslatef((float)sizeDepth / 2.0F, (float)sizeHeight / 2.0F, (float)sizeDepth / 2.0F);
                                GL11.glShadeModel(7425 /*GL_SMOOTH*/);
                                tessellator.startDrawingQuads();
                                //tessellator.setTranslationD(-posX, -posY, -posZ);
                            }
                            if(passNumber == 0 && Block.isBlockContainer[i3])
                            {
                                TileEntity tileentity = chunkcache.getBlockTileEntity(x, y, z);
                                if(TileEntityRenderer.instance.checkIfTileEntity(tileentity))
                                {
                                    tileEntityRenderers.add(tileentity);
                                }
                            }
                            Block block = Block.allBlocks[i3];
                            int j3 = block.getRenderBlockPass();
                            if(j3 != passNumber)
                            {
                                flag = true;
                                continue;
                            }
                            if(j3 == passNumber)
                            {
                                flag1 |= renderblocks.renderBlockByRenderType(block, x, y, z);
                            }
                        }

                    }

                }

                if(madeList)
                {
                    tessellator.draw();
                    GL11.glEndList();
                    tessellator.setRenderingChunk(false);
                    //GL11.glPopMatrix();
                    //GL11.glEndList();
                    //tessellator.setTranslationD(0.0D, 0.0D, 0.0D);
                } else
                {
                    flag1 = false;
                }
                if(flag1)
                {
                    skipRenderPass[passNumber] = false;
                }
                if(!flag)
                {
                    break;
                }
                passNumber++;
            } while(true);
            HashSet<TileEntity> hashset1 = new HashSet<TileEntity>();
            hashset1.addAll(tileEntityRenderers);
            hashset1.removeAll(hashset);
            tileEntities.addAll(hashset1);
            hashset.removeAll(tileEntityRenderers);
            tileEntities.removeAll(hashset);
            field_1747_A = Chunk.isLit;
            isInitialized = true;
        }
    }
    
    public void updateRenderer_(){
        if(!needsUpdate)
        {
            return;
        }
        chunksUpdated++;
        int minX = posX;
        int minY = posY;
        int minZ = posZ;
        int maxX = posX + sizeWidth;
        int maxY = posY + sizeHeight;
        int maxZ = posZ + sizeDepth;
        for(int k1 = 0; k1 < 2; k1++)
        {
            skipRenderPass[k1] = true;
        }

        Chunk.isLit = false;
        HashSet<TileEntity> hashset = new HashSet<TileEntity>();
        hashset.addAll(tileEntityRenderers);
        tileEntityRenderers.clear();
        int bufferZone = 1;
        ChunkCache chunkcache = new ChunkCache(worldObj, minX - bufferZone, minY - bufferZone, minZ - bufferZone, maxX + bufferZone, maxY + bufferZone, maxZ + bufferZone);
        RenderBlocks renderblocks = new RenderBlocks(chunkcache);
        int passNumber = 0;
        do
        {
            if(passNumber >= 2)
            {
                break;
            }
            boolean flag = false;
            boolean flag1 = false;
            boolean madeList = false;
            for(int y = minY; y < maxY; y++)
            {
                for(int z = minZ; z < maxZ; z++)
                {
                    for(int x = minX; x < maxX; x++)
                    {
                        int blockId = chunkcache.getBlockId(x, y, z);
                        if(blockId <= 0)
                        {
                            continue;
                        }
                        if(!madeList)
                        {
                        	madeList = true;
                            GL11.glNewList(glRenderList + passNumber, 4864);
                            GL11.glPushMatrix();
                            setupGLTranslation();
                            float f = 1.000001F;
                            GL11.glTranslatef((float)(-sizeDepth) / 2.0F, (float)(-sizeHeight) / 2.0F, (float)(-sizeDepth) / 2.0F);
                            GL11.glScalef(f, f, f);
                            GL11.glTranslatef((float)sizeDepth / 2.0F, (float)sizeHeight / 2.0F, (float)sizeDepth / 2.0F);
                            tessellator.startDrawingQuads();
                            tessellator.setTranslationD(-posX, -posY, -posZ);
                        }
                        if(passNumber == 0 && Block.isBlockContainer[blockId])
                        {
                            TileEntity tileentity = chunkcache.getBlockTileEntity(x, y, z);
                            if(TileEntityRenderer.instance.checkIfTileEntity(tileentity))
                            {
                                tileEntityRenderers.add(tileentity);
                            }
                        }
                        Block block = Block.allBlocks[blockId];
                        int j3 = block.getRenderBlockPass();
                        if(j3 != passNumber)
                        {
                            flag = true;
                            continue;
                        }
                        if(j3 == passNumber)
                        {
                            flag1 |= renderblocks.renderBlockByRenderType(block, x, y, z);
                        }
                    }

                }

            }

            if(madeList)
            {
            	tessellator.draw();
                GL11.glPopMatrix();
                GL11.glEndList();
                tessellator.setTranslationD(0.0D, 0.0D, 0.0D);
            } else
            {
                flag1 = false;
            }
            if(flag1)
            {
                skipRenderPass[passNumber] = false;
            }
            if(!flag)
            {
                break;
            }
            passNumber++;
        } while(true);
        HashSet<TileEntity> hashset1 = new HashSet<TileEntity>();
        hashset1.addAll(tileEntityRenderers);
        hashset1.removeAll(hashset);
        tileEntities.addAll(hashset1);
        hashset.removeAll(tileEntityRenderers);
        tileEntities.removeAll(hashset);
        field_1747_A = Chunk.isLit;
        isInitialized = true;
        
        traceDone = true;
    }

    public float distanceToEntitySquared(Entity entity)
    {
        float f = (float)(entity.posX - (double)field_1746_q);
        float f1 = (float)(entity.posY - (double)field_1743_r);
        float f2 = (float)(entity.posZ - (double)field_1741_s);
        return f * f + f1 * f1 + f2 * f2;
    }

    public void func_1195_b()
    {
        for(int i = 0; i < 2; i++)
        {
            skipRenderPass[i] = true;
        }

        isInFrustrum = false;
        isInitialized = false;
    }

    public void func_1204_c()
    {
        func_1195_b();
        worldObj = null;
    }

    public int getGLCallListForPass(int i)
    {
    	return isInFrustrum ? skipRenderPass[i] ? -1 : glRenderList + i : -1;
    }

    public void updateInFrustrum(ICamera icamera)
    {
        isInFrustrum = icamera.func_342_a(field_1736_v);
    }

    public void callOcclusionQueryList()
    {
    	//GL11.glPolygonMode(1028, 6913); //ADDED
        GL11.glCallList(glRenderList + 2);
        //GL11.glPolygonMode(1028, 6914); //ADDED
    }

    public boolean canRender()
    {
    	return isInitialized ? skipRenderPass[0] && skipRenderPass[1] : false;
    }

    public void markDirty()
    {
        needsUpdate = true;
    }

    public float distance;
    public World worldObj;
    private int glRenderList;
    private static Tessellator tessellator;
    public static int chunksUpdated = 0;
    public int posX;
    public int posY;
    public int posZ;
    public int sizeWidth;
    public int sizeHeight;
    public int sizeDepth;
    public int field_1755_i;
    public int field_1754_j;
    public int field_1753_k;
    public int field_1752_l;
    public int field_1751_m;
    public int field_1750_n;
    public boolean isInFrustrum;
    public boolean skipRenderPass[];
    public int field_1746_q;
    public int field_1743_r;
    public int field_1741_s;
    public float rendererRadius;
    public boolean needsUpdate;
    public AxisAlignedBB field_1736_v;
    public int chunkIndex;
    public boolean isVisible;
    public boolean isWaitingOnOcclusionQuery;
    public int field_1732_z;
    public boolean field_1747_A;
    private boolean isInitialized;
    public List<TileEntity> tileEntityRenderers;
    private List<TileEntity> tileEntities;
    static boolean traceDone = false;
    public int levelOfDetail;

    static 
    {
        tessellator = Tessellator.instance;
    }
}
