package com.mojang.minecraft.render;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.util.Random;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.Color;

import com.mojang.minecraft.entity.tile.IBlockAccess;
import com.mojang.minecraft.level.World;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.level.tile.BlockDoor;
import com.mojang.minecraft.level.tile.BlockFluids;
import com.mojang.minecraft.level.tile.BlockRedstoneWire;
import com.mojang.minecraft.level.tile.material.Material;
import com.mojang.minecraft.util.MathHelper;

//import net.minecraft.client.renderer.Tessellator;

public class RenderBlocks
{

    public RenderBlocks(IBlockAccess iblockaccess)
    {
        overrideBlockTexture = -1;
        flipTexture = false;
        renderAllFaces = false;
        field_31088_b = true;
        field_31087_g = 0;
        field_31086_h = 0;
        field_31085_i = 0;
        field_31084_j = 0;
        field_31083_k = 0;
        field_31082_l = 0;
        field_22352_G = 1;
        renderIBlockAccess = iblockaccess;
    }

    public RenderBlocks()
    {
        overrideBlockTexture = -1;
        flipTexture = false;
        renderAllFaces = false;
        
        field_31088_b = true;
        field_31087_g = 0;
        field_31086_h = 0;
        field_31085_i = 0;
        field_31084_j = 0;
        field_31083_k = 0;
        field_31082_l = 0;
        field_22352_G = 1;
    }

    public void renderBlockUsingTexture(Block block, int i, int j, int k, int l)
    {
        overrideBlockTexture = l;
        renderBlockByRenderType(block, i, j, k);
        overrideBlockTexture = -1;
    }

    public boolean renderBlockByRenderType(Block block, int i, int j, int k)
    {
        int renderType = block.getRenderType();
        block.setBlockBoundsBasedOnState(renderIBlockAccess, i, j, k);
        if(renderType == 0)
        {
            return renderBlock(block, i, j, k);
        }
        if(renderType == 4)
        {
            return renderFluid(block, i, j, k);
        }
        if(renderType == 13)
        {
            return renderCactus(block, i, j, k);
        }
        if(renderType == 1)
        {
            return renderPlant(block, i, j, k);
        }
        if(renderType == 6)
        {
            return renderCrops(block, i, j, k);
        }
        if(renderType == 2)
        {
            return renderTorch(block, i, j, k);
        }
        if(renderType == 3)
        {
            return renderFire(block, i, j, k);
        }
        if(renderType == 5)
        {
            return renderRedstoneWire(block, i, j, k);
        }
        if(renderType == 8)
        {
            return renderLadder(block, i, j, k);
        }
        if(renderType == 7)
        {
            return renderDoor(block, i, j, k);
        }
        if(renderType == 9)
        {
            return renderMinecartTrack(block, i, j, k);
        }
        if(renderType == 10)
        {
            return renderStairs(block, i, j, k);
        }
        if(renderType == 11)
        {
            return renderPressurePlate(block, i, j, k);
        }
        if(renderType == 12)
        {
            return renderLever(block, i, j, k);
        }
        if(renderType == 14){
        	return renderGear(block, i, j, k);
        }else
        {
            return false;
        }
    }
    
    public boolean renderGear(Block block, int n, int n2, int n3){
        final int n29 = n;
        final int n30 = n2;
        int a = n3;
        n3 = n30;
        n2 = n29;
        final Tessellator a8 = Tessellator.instance;
        //System.out.println(" " + n2 + ", " +  n3 + ", " + a);
        int n18 = block.getBlockTextureFromSideAndMetadata(1, renderIBlockAccess.getBlockMetadata(n2, n3, a));//78;//block.getTextureIndex(0);
        if (overrideBlockTexture >= 0) {
            n18 = overrideBlockTexture;
        }
        final float n15 = block.getBlockBrightness(renderIBlockAccess, n2, n3, a);
        a8.setColorOpaque_F(n15, n15, n15);
        n = ((n18 & 0xF) << 4) + 16;
        int n19 = (n18 & 0xF) << 4;
        final int n31 = n18 & 0xF0;
        if ((n2 + n3 + a & 0x1) == 0x1) {
            n = (n18 & 0xF) << 4;
            n19 = ((n18 & 0xF) << 4) + 16;
        }
        final float av = n / 256.0f;
        final float ay = (n + 15.99f) / 256.0f;
        final float n8 = n31 / 256.0f;
        final float n32 = (n31 + 15.99f) / 256.0f;
        final float n21 = n19 / 256.0f;
        final float n22 = (n19 + 15.99f) / 256.0f;
        final float n23 = n31 / 256.0f;
        final float n24 = (n31 + 15.99f) / 256.0f;
        if (renderIBlockAccess.isBlockNormalCube(n2 - 1, n3, a)) {
            a8.addVertexWithUV(n2 + 0.05f, n3 + 1 + 0.125f, a + 1 + 0.125f, av, n8);
            a8.addVertexWithUV(n2 + 0.05f, n3 - 0.125f, a + 1 + 0.125f, av, n32);
            a8.addVertexWithUV(n2 + 0.05f, n3 - 0.125f, a - 0.125f, ay, n32);
            a8.addVertexWithUV(n2 + 0.05f, n3 + 1 + 0.125f, a - 0.125f, ay, n8);
        }
        if (renderIBlockAccess.isBlockNormalCube(n2 + 1, n3, a)) {
            a8.addVertexWithUV(n2 + 1 - 0.05f, n3 - 0.125f, a + 1 + 0.125f, ay, n32);
            a8.addVertexWithUV(n2 + 1 - 0.05f, n3 + 1 + 0.125f, a + 1 + 0.125f, ay, n8);
            a8.addVertexWithUV(n2 + 1 - 0.05f, n3 + 1 + 0.125f, a - 0.125f, av, n8);
            a8.addVertexWithUV(n2 + 1 - 0.05f, n3 - 0.125f, a - 0.125f, av, n32);
        }
        if (renderIBlockAccess.isBlockNormalCube(n2, n3, a - 1)) {
            a8.addVertexWithUV(n2 + 1 + 0.125f, n3 - 0.125f, a + 0.05f, n22, n24);
            a8.addVertexWithUV(n2 + 1 + 0.125f, n3 + 1 + 0.125f, a + 0.05f, n22, n23);
            a8.addVertexWithUV(n2 - 0.125f, n3 + 1 + 0.125f, a + 0.05f, n21, n23);
            a8.addVertexWithUV(n2 - 0.125f, n3 - 0.125f, a + 0.05f, n21, n24);
        }
        if (renderIBlockAccess.isBlockNormalCube(n2, n3, a + 1)) {
            a8.addVertexWithUV(n2 + 1 + 0.125f, n3 + 1 + 0.125f, a + 1 - 0.05f, n21, n23);
            a8.addVertexWithUV(n2 + 1 + 0.125f, n3 - 0.125f, a + 1 - 0.05f, n21, n24);
            a8.addVertexWithUV(n2 - 0.125f, n3 - 0.125f, a + 1 - 0.05f, n22, n24);
            a8.addVertexWithUV(n2 - 0.125f, n3 + 1 + 0.125f, a + 1 - 0.05f, n22, n23);
        }
        return true;
    }

    public boolean renderTorch(Block block, int i, int j, int k)
    {
        int l = renderIBlockAccess.getBlockMetadata(i, j, k);
        Tessellator tessellator = Tessellator.instance;
        float f = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        if(Block.lightValue[block.blockID] > 0)
        {
            f = 1.0F;
        }
        tessellator.setColorOpaque_F(f, f, f);
        double d = 0.40000000596046448D;
        double d1 = 0.5D - d;
        double d2 = 0.20000000298023224D;
        if(l == 1)
        {
            func_1237_a(block, (double)i - d1, (double)j + d2, k, -d, 0.0D);
        } else
        if(l == 2)
        {
            func_1237_a(block, (double)i + d1, (double)j + d2, k, d, 0.0D);
        } else
        if(l == 3)
        {
            func_1237_a(block, i, (double)j + d2, (double)k - d1, 0.0D, -d);
        } else
        if(l == 4)
        {
            func_1237_a(block, i, (double)j + d2, (double)k + d1, 0.0D, d);
        } else
        {
            func_1237_a(block, i, j, k, 0.0D, 0.0D);
        }
        return true;
    }

    public boolean renderLever(Block block, int i, int j, int k)
    {
        int l = renderIBlockAccess.getBlockMetadata(i, j, k);
        int i1 = l & 7;
        boolean flag = (l & 8) > 0;
        Tessellator tessellator = Tessellator.instance;
        boolean flag1 = overrideBlockTexture >= 0;
        if(!flag1)
        {
            overrideBlockTexture = Block.cobblestone.blockIndexInTexture;
        }
        float f = 0.25F;
        float f1 = 0.1875F;
        float f2 = 0.1875F;
        if(i1 == 5)
        {
            block.setBlockBounds(0.5F - f1, 0.0F, 0.5F - f, 0.5F + f1, f2, 0.5F + f);
        } else
        if(i1 == 6)
        {
            block.setBlockBounds(0.5F - f, 0.0F, 0.5F - f1, 0.5F + f, f2, 0.5F + f1);
        } else
        if(i1 == 4)
        {
            block.setBlockBounds(0.5F - f1, 0.5F - f, 1.0F - f2, 0.5F + f1, 0.5F + f, 1.0F);
        } else
        if(i1 == 3)
        {
            block.setBlockBounds(0.5F - f1, 0.5F - f, 0.0F, 0.5F + f1, 0.5F + f, f2);
        } else
        if(i1 == 2)
        {
            block.setBlockBounds(1.0F - f2, 0.5F - f, 0.5F - f1, 1.0F, 0.5F + f, 0.5F + f1);
        } else
        if(i1 == 1)
        {
            block.setBlockBounds(0.0F, 0.5F - f, 0.5F - f1, f2, 0.5F + f, 0.5F + f1);
        }
        renderBlock(block, i, j, k);
        if(!flag1)
        {
            overrideBlockTexture = -1;
        }
        float f3 = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        if(Block.lightValue[block.blockID] > 0)
        {
            f3 = 1.0F;
        }
        tessellator.setColorOpaque_F(f3, f3, f3);
        int j1 = block.getTextureIndex(0);
        if(overrideBlockTexture >= 0)
        {
            j1 = overrideBlockTexture;
        }
        int k1 = (j1 & 0xf) << 4;
        int l1 = j1 & 0xf0;
        float f4 = (float)k1 / 256F;
        float f5 = ((float)k1 + 15.99F) / 256F;
        float f6 = (float)l1 / 256F;
        float f7 = ((float)l1 + 15.99F) / 256F;
        Vec3D avec3d[] = new Vec3D[8];
        float f8 = 0.0625F;
        float f9 = 0.0625F;
        float f10 = 0.625F;
        avec3d[0] = Vec3D.createVector(-f8, 0.0D, -f9);
        avec3d[1] = Vec3D.createVector(f8, 0.0D, -f9);
        avec3d[2] = Vec3D.createVector(f8, 0.0D, f9);
        avec3d[3] = Vec3D.createVector(-f8, 0.0D, f9);
        avec3d[4] = Vec3D.createVector(-f8, f10, -f9);
        avec3d[5] = Vec3D.createVector(f8, f10, -f9);
        avec3d[6] = Vec3D.createVector(f8, f10, f9);
        avec3d[7] = Vec3D.createVector(-f8, f10, f9);
        for(int i2 = 0; i2 < 8; i2++)
        {
            if(flag)
            {
                avec3d[i2].zCoord -= 0.0625D;
                avec3d[i2].rotateAroundX(0.6981317F);
            } else
            {
                avec3d[i2].zCoord += 0.0625D;
                avec3d[i2].rotateAroundX(-0.6981317F);
            }
            if(i1 == 6)
            {
                avec3d[i2].rotateAroundY(1.570796F);
            }
            if(i1 < 5)
            {
                avec3d[i2].yCoord -= 0.375D;
                avec3d[i2].rotateAroundX(1.570796F);
                if(i1 == 4)
                {
                    avec3d[i2].rotateAroundY(0.0F);
                }
                if(i1 == 3)
                {
                    avec3d[i2].rotateAroundY(3.141593F);
                }
                if(i1 == 2)
                {
                    avec3d[i2].rotateAroundY(1.570796F);
                }
                if(i1 == 1)
                {
                    avec3d[i2].rotateAroundY(-1.570796F);
                }
                avec3d[i2].xCoord += (double)i + 0.5D;
                avec3d[i2].yCoord += (float)j + 0.5F;
                avec3d[i2].zCoord += (double)k + 0.5D;
            } else
            {
                avec3d[i2].xCoord += (double)i + 0.5D;
                avec3d[i2].yCoord += (float)j + 0.125F;
                avec3d[i2].zCoord += (double)k + 0.5D;
            }
        }

        Vec3D vec3d = null;
        Vec3D vec3d1 = null;
        Vec3D vec3d2 = null;
        Vec3D vec3d3 = null;
        for(int j2 = 0; j2 < 6; j2++)
        {
            if(j2 == 0)
            {
                f4 = (float)(k1 + 7) / 256F;
                f5 = ((float)(k1 + 9) - 0.01F) / 256F;
                f6 = (float)(l1 + 6) / 256F;
                f7 = ((float)(l1 + 8) - 0.01F) / 256F;
            } else
            if(j2 == 2)
            {
                f4 = (float)(k1 + 7) / 256F;
                f5 = ((float)(k1 + 9) - 0.01F) / 256F;
                f6 = (float)(l1 + 6) / 256F;
                f7 = ((float)(l1 + 16) - 0.01F) / 256F;
            }
            if(j2 == 0)
            {
                vec3d = avec3d[0];
                vec3d1 = avec3d[1];
                vec3d2 = avec3d[2];
                vec3d3 = avec3d[3];
            } else
            if(j2 == 1)
            {
                vec3d = avec3d[7];
                vec3d1 = avec3d[6];
                vec3d2 = avec3d[5];
                vec3d3 = avec3d[4];
            } else
            if(j2 == 2)
            {
                vec3d = avec3d[1];
                vec3d1 = avec3d[0];
                vec3d2 = avec3d[4];
                vec3d3 = avec3d[5];
            } else
            if(j2 == 3)
            {
                vec3d = avec3d[2];
                vec3d1 = avec3d[1];
                vec3d2 = avec3d[5];
                vec3d3 = avec3d[6];
            } else
            if(j2 == 4)
            {
                vec3d = avec3d[3];
                vec3d1 = avec3d[2];
                vec3d2 = avec3d[6];
                vec3d3 = avec3d[7];
            } else
            if(j2 == 5)
            {
                vec3d = avec3d[0];
                vec3d1 = avec3d[3];
                vec3d2 = avec3d[7];
                vec3d3 = avec3d[4];
            }
            tessellator.addVertexWithUV(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord, f4, f7);
            tessellator.addVertexWithUV(vec3d1.xCoord, vec3d1.yCoord, vec3d1.zCoord, f5, f7);
            tessellator.addVertexWithUV(vec3d2.xCoord, vec3d2.yCoord, vec3d2.zCoord, f5, f6);
            tessellator.addVertexWithUV(vec3d3.xCoord, vec3d3.yCoord, vec3d3.zCoord, f4, f6);
        }

        return true;
    }

    public boolean renderFire(Block block, int i, int j, int k)
    {
        Tessellator tessellator = Tessellator.instance;
        int l = block.getTextureIndex(0);
        if(overrideBlockTexture >= 0)
        {
            l = overrideBlockTexture;
        }
        float f = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        tessellator.setColorOpaque_F(f, f, f);
        int i1 = (l & 0xf) << 4;
        int j1 = l & 0xf0;
        double d = (float)i1 / 256F;
        double d2 = ((float)i1 + 15.99F) / 256F;
        double d4 = (float)j1 / 256F;
        double d6 = ((float)j1 + 15.99F) / 256F;
        float f1 = 1.4F;
        if(renderIBlockAccess.isBlockNormalCube(i, j - 1, k) || Block.fire.canBlockCatchFire(renderIBlockAccess, i, j - 1, k))
        {
            double d8 = (double)i + 0.5D + 0.20000000000000001D;
            double d9 = ((double)i + 0.5D) - 0.20000000000000001D;
            double d12 = (double)k + 0.5D + 0.20000000000000001D;
            double d14 = ((double)k + 0.5D) - 0.20000000000000001D;
            double d16 = ((double)i + 0.5D) - 0.29999999999999999D;
            double d18 = (double)i + 0.5D + 0.29999999999999999D;
            double d20 = ((double)k + 0.5D) - 0.29999999999999999D;
            double d22 = (double)k + 0.5D + 0.29999999999999999D;
            tessellator.addVertexWithUV(d16, (float)j + f1, k + 1, d2, d4);
            tessellator.addVertexWithUV(d8, j + 0, k + 1, d2, d6);
            tessellator.addVertexWithUV(d8, j + 0, k + 0, d, d6);
            tessellator.addVertexWithUV(d16, (float)j + f1, k + 0, d, d4);
            tessellator.addVertexWithUV(d18, (float)j + f1, k + 0, d2, d4);
            tessellator.addVertexWithUV(d9, j + 0, k + 0, d2, d6);
            tessellator.addVertexWithUV(d9, j + 0, k + 1, d, d6);
            tessellator.addVertexWithUV(d18, (float)j + f1, k + 1, d, d4);
            d = (float)i1 / 256F;
            d2 = ((float)i1 + 15.99F) / 256F;
            d4 = (float)(j1 + 16) / 256F;
            d6 = ((float)j1 + 15.99F + 16F) / 256F;
            tessellator.addVertexWithUV(i + 1, (float)j + f1, d22, d2, d4);
            tessellator.addVertexWithUV(i + 1, j + 0, d14, d2, d6);
            tessellator.addVertexWithUV(i + 0, j + 0, d14, d, d6);
            tessellator.addVertexWithUV(i + 0, (float)j + f1, d22, d, d4);
            tessellator.addVertexWithUV(i + 0, (float)j + f1, d20, d2, d4);
            tessellator.addVertexWithUV(i + 0, j + 0, d12, d2, d6);
            tessellator.addVertexWithUV(i + 1, j + 0, d12, d, d6);
            tessellator.addVertexWithUV(i + 1, (float)j + f1, d20, d, d4);
            d8 = ((double)i + 0.5D) - 0.5D;
            d9 = (double)i + 0.5D + 0.5D;
            d12 = ((double)k + 0.5D) - 0.5D;
            d14 = (double)k + 0.5D + 0.5D;
            d16 = ((double)i + 0.5D) - 0.40000000000000002D;
            d18 = (double)i + 0.5D + 0.40000000000000002D;
            d20 = ((double)k + 0.5D) - 0.40000000000000002D;
            d22 = (double)k + 0.5D + 0.40000000000000002D;
            tessellator.addVertexWithUV(d16, (float)j + f1, k + 0, d, d4);
            tessellator.addVertexWithUV(d8, j + 0, k + 0, d, d6);
            tessellator.addVertexWithUV(d8, j + 0, k + 1, d2, d6);
            tessellator.addVertexWithUV(d16, (float)j + f1, k + 1, d2, d4);
            tessellator.addVertexWithUV(d18, (float)j + f1, k + 1, d, d4);
            tessellator.addVertexWithUV(d9, j + 0, k + 1, d, d6);
            tessellator.addVertexWithUV(d9, j + 0, k + 0, d2, d6);
            tessellator.addVertexWithUV(d18, (float)j + f1, k + 0, d2, d4);
            d = (float)i1 / 256F;
            d2 = ((float)i1 + 15.99F) / 256F;
            d4 = (float)j1 / 256F;
            d6 = ((float)j1 + 15.99F) / 256F;
            tessellator.addVertexWithUV(i + 0, (float)j + f1, d22, d, d4);
            tessellator.addVertexWithUV(i + 0, j + 0, d14, d, d6);
            tessellator.addVertexWithUV(i + 1, j + 0, d14, d2, d6);
            tessellator.addVertexWithUV(i + 1, (float)j + f1, d22, d2, d4);
            tessellator.addVertexWithUV(i + 1, (float)j + f1, d20, d, d4);
            tessellator.addVertexWithUV(i + 1, j + 0, d12, d, d6);
            tessellator.addVertexWithUV(i + 0, j + 0, d12, d2, d6);
            tessellator.addVertexWithUV(i + 0, (float)j + f1, d20, d2, d4);
        } else
        {
            float f3 = 0.2F;
            float f4 = 0.0625F;
            if((i + j + k & 1) == 1)
            {
                d = (float)i1 / 256F;
                d2 = ((float)i1 + 15.99F) / 256F;
                d4 = (float)(j1 + 16) / 256F;
                d6 = ((float)j1 + 15.99F + 16F) / 256F;
            }
            if((i / 2 + j / 2 + k / 2 & 1) == 1)
            {
                double d10 = d2;
                d2 = d;
                d = d10;
            }
            if(Block.fire.canBlockCatchFire(renderIBlockAccess, i - 1, j, k))
            {
                tessellator.addVertexWithUV((float)i + f3, (float)j + f1 + f4, k + 1, d2, d4);
                tessellator.addVertexWithUV(i + 0, (float)(j + 0) + f4, k + 1, d2, d6);
                tessellator.addVertexWithUV(i + 0, (float)(j + 0) + f4, k + 0, d, d6);
                tessellator.addVertexWithUV((float)i + f3, (float)j + f1 + f4, k + 0, d, d4);
                tessellator.addVertexWithUV((float)i + f3, (float)j + f1 + f4, k + 0, d, d4);
                tessellator.addVertexWithUV(i + 0, (float)(j + 0) + f4, k + 0, d, d6);
                tessellator.addVertexWithUV(i + 0, (float)(j + 0) + f4, k + 1, d2, d6);
                tessellator.addVertexWithUV((float)i + f3, (float)j + f1 + f4, k + 1, d2, d4);
            }
            if(Block.fire.canBlockCatchFire(renderIBlockAccess, i + 1, j, k))
            {
                tessellator.addVertexWithUV((float)(i + 1) - f3, (float)j + f1 + f4, k + 0, d, d4);
                tessellator.addVertexWithUV((i + 1) - 0, (float)(j + 0) + f4, k + 0, d, d6);
                tessellator.addVertexWithUV((i + 1) - 0, (float)(j + 0) + f4, k + 1, d2, d6);
                tessellator.addVertexWithUV((float)(i + 1) - f3, (float)j + f1 + f4, k + 1, d2, d4);
                tessellator.addVertexWithUV((float)(i + 1) - f3, (float)j + f1 + f4, k + 1, d2, d4);
                tessellator.addVertexWithUV((i + 1) - 0, (float)(j + 0) + f4, k + 1, d2, d6);
                tessellator.addVertexWithUV((i + 1) - 0, (float)(j + 0) + f4, k + 0, d, d6);
                tessellator.addVertexWithUV((float)(i + 1) - f3, (float)j + f1 + f4, k + 0, d, d4);
            }
            if(Block.fire.canBlockCatchFire(renderIBlockAccess, i, j, k - 1))
            {
                tessellator.addVertexWithUV(i + 0, (float)j + f1 + f4, (float)k + f3, d2, d4);
                tessellator.addVertexWithUV(i + 0, (float)(j + 0) + f4, k + 0, d2, d6);
                tessellator.addVertexWithUV(i + 1, (float)(j + 0) + f4, k + 0, d, d6);
                tessellator.addVertexWithUV(i + 1, (float)j + f1 + f4, (float)k + f3, d, d4);
                tessellator.addVertexWithUV(i + 1, (float)j + f1 + f4, (float)k + f3, d, d4);
                tessellator.addVertexWithUV(i + 1, (float)(j + 0) + f4, k + 0, d, d6);
                tessellator.addVertexWithUV(i + 0, (float)(j + 0) + f4, k + 0, d2, d6);
                tessellator.addVertexWithUV(i + 0, (float)j + f1 + f4, (float)k + f3, d2, d4);
            }
            if(Block.fire.canBlockCatchFire(renderIBlockAccess, i, j, k + 1))
            {
                tessellator.addVertexWithUV(i + 1, (float)j + f1 + f4, (float)(k + 1) - f3, d, d4);
                tessellator.addVertexWithUV(i + 1, (float)(j + 0) + f4, (k + 1) - 0, d, d6);
                tessellator.addVertexWithUV(i + 0, (float)(j + 0) + f4, (k + 1) - 0, d2, d6);
                tessellator.addVertexWithUV(i + 0, (float)j + f1 + f4, (float)(k + 1) - f3, d2, d4);
                tessellator.addVertexWithUV(i + 0, (float)j + f1 + f4, (float)(k + 1) - f3, d2, d4);
                tessellator.addVertexWithUV(i + 0, (float)(j + 0) + f4, (k + 1) - 0, d2, d6);
                tessellator.addVertexWithUV(i + 1, (float)(j + 0) + f4, (k + 1) - 0, d, d6);
                tessellator.addVertexWithUV(i + 1, (float)j + f1 + f4, (float)(k + 1) - f3, d, d4);
            }
            if(Block.fire.canBlockCatchFire(renderIBlockAccess, i, j + 1, k))
            {
                double d11 = (double)i + 0.5D + 0.5D;
                double d13 = ((double)i + 0.5D) - 0.5D;
                double d15 = (double)k + 0.5D + 0.5D;
                double d17 = ((double)k + 0.5D) - 0.5D;
                double d19 = ((double)i + 0.5D) - 0.5D;
                double d21 = (double)i + 0.5D + 0.5D;
                double d23 = ((double)k + 0.5D) - 0.5D;
                double d24 = (double)k + 0.5D + 0.5D;
                double d1 = (float)i1 / 256F;
                double d3 = ((float)i1 + 15.99F) / 256F;
                double d5 = (float)j1 / 256F;
                double d7 = ((float)j1 + 15.99F) / 256F;
                j++;
                float f2 = -0.2F;
                if((i + j + k & 1) == 0)
                {
                    tessellator.addVertexWithUV(d19, (float)j + f2, k + 0, d3, d5);
                    tessellator.addVertexWithUV(d11, j + 0, k + 0, d3, d7);
                    tessellator.addVertexWithUV(d11, j + 0, k + 1, d1, d7);
                    tessellator.addVertexWithUV(d19, (float)j + f2, k + 1, d1, d5);
                    d1 = (float)i1 / 256F;
                    d3 = ((float)i1 + 15.99F) / 256F;
                    d5 = (float)(j1 + 16) / 256F;
                    d7 = ((float)j1 + 15.99F + 16F) / 256F;
                    tessellator.addVertexWithUV(d21, (float)j + f2, k + 1, d3, d5);
                    tessellator.addVertexWithUV(d13, j + 0, k + 1, d3, d7);
                    tessellator.addVertexWithUV(d13, j + 0, k + 0, d1, d7);
                    tessellator.addVertexWithUV(d21, (float)j + f2, k + 0, d1, d5);
                } else
                {
                    tessellator.addVertexWithUV(i + 0, (float)j + f2, d24, d3, d5);
                    tessellator.addVertexWithUV(i + 0, j + 0, d17, d3, d7);
                    tessellator.addVertexWithUV(i + 1, j + 0, d17, d1, d7);
                    tessellator.addVertexWithUV(i + 1, (float)j + f2, d24, d1, d5);
                    d1 = (float)i1 / 256F;
                    d3 = ((float)i1 + 15.99F) / 256F;
                    d5 = (float)(j1 + 16) / 256F;
                    d7 = ((float)j1 + 15.99F + 16F) / 256F;
                    tessellator.addVertexWithUV(i + 1, (float)j + f2, d23, d3, d5);
                    tessellator.addVertexWithUV(i + 1, j + 0, d15, d3, d7);
                    tessellator.addVertexWithUV(i + 0, j + 0, d15, d1, d7);
                    tessellator.addVertexWithUV(i + 0, (float)j + f2, d23, d1, d5);
                }
            }
        }
        return true;
    }

    public boolean renderRedstoneWire(Block block, int i, int j, int k)
    {
        Tessellator tessellator = Tessellator.instance;
        int l = block.getBlockTextureFromSideAndMetadata(1, renderIBlockAccess.getBlockMetadata(i, j, k));
        if(overrideBlockTexture >= 0)
        {
            l = overrideBlockTexture;
        }
        float f = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        tessellator.setColorOpaque_F(f, f, f);
        int i1 = (l & 0xf) << 4;
        int j1 = l & 0xf0;
        double d = (float)i1 / 256F;
        double d1 = ((float)i1 + 15.99F) / 256F;
        double d2 = (float)j1 / 256F;
        double d3 = ((float)j1 + 15.99F) / 256F;
        float f1 = 0.0F;
        float f2 = 0.03125F;
        boolean flag = BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i - 1, j, k) || !renderIBlockAccess.isBlockNormalCube(i - 1, j, k) && BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i - 1, j - 1, k);
        boolean flag1 = BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i + 1, j, k) || !renderIBlockAccess.isBlockNormalCube(i + 1, j, k) && BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i + 1, j - 1, k);
        boolean flag2 = BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i, j, k - 1) || !renderIBlockAccess.isBlockNormalCube(i, j, k - 1) && BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i, j - 1, k - 1);
        boolean flag3 = BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i, j, k + 1) || !renderIBlockAccess.isBlockNormalCube(i, j, k + 1) && BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i, j - 1, k + 1);
        if(!renderIBlockAccess.isBlockNormalCube(i, j + 1, k))
        {
            if(renderIBlockAccess.isBlockNormalCube(i - 1, j, k) && BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i - 1, j + 1, k))
            {
                flag = true;
            }
            if(renderIBlockAccess.isBlockNormalCube(i + 1, j, k) && BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i + 1, j + 1, k))
            {
                flag1 = true;
            }
            if(renderIBlockAccess.isBlockNormalCube(i, j, k - 1) && BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i, j + 1, k - 1))
            {
                flag2 = true;
            }
            if(renderIBlockAccess.isBlockNormalCube(i, j, k + 1) && BlockRedstoneWire.isPowerProviderOrWire(renderIBlockAccess, i, j + 1, k + 1))
            {
                flag3 = true;
            }
        }
        float f3 = 0.3125F;
        float f4 = i + 0;
        float f5 = i + 1;
        float f6 = k + 0;
        float f7 = k + 1;
        byte byte0 = 0;
        if((flag || flag1) && !flag2 && !flag3)
        {
            byte0 = 1;
        }
        if((flag2 || flag3) && !flag1 && !flag)
        {
            byte0 = 2;
        }
        if(byte0 != 0)
        {
            d = (float)(i1 + 16) / 256F;
            d1 = ((float)(i1 + 16) + 15.99F) / 256F;
            d2 = (float)j1 / 256F;
            d3 = ((float)j1 + 15.99F) / 256F;
        }
        if(byte0 == 0)
        {
            if(flag1 || flag2 || flag3 || flag)
            {
                if(!flag)
                {
                    f4 += f3;
                }
                if(!flag)
                {
                    d += f3 / 16F;
                }
                if(!flag1)
                {
                    f5 -= f3;
                }
                if(!flag1)
                {
                    d1 -= f3 / 16F;
                }
                if(!flag2)
                {
                    f6 += f3;
                }
                if(!flag2)
                {
                    d2 += f3 / 16F;
                }
                if(!flag3)
                {
                    f7 -= f3;
                }
                if(!flag3)
                {
                    d3 -= f3 / 16F;
                }
            }
            tessellator.addVertexWithUV(f5 + f1, (float)j + f2, f7 + f1, d1, d3);
            tessellator.addVertexWithUV(f5 + f1, (float)j + f2, f6 - f1, d1, d2);
            tessellator.addVertexWithUV(f4 - f1, (float)j + f2, f6 - f1, d, d2);
            tessellator.addVertexWithUV(f4 - f1, (float)j + f2, f7 + f1, d, d3);
        }
        if(byte0 == 1)
        {
            tessellator.addVertexWithUV(f5 + f1, (float)j + f2, f7 + f1, d1, d3);
            tessellator.addVertexWithUV(f5 + f1, (float)j + f2, f6 - f1, d1, d2);
            tessellator.addVertexWithUV(f4 - f1, (float)j + f2, f6 - f1, d, d2);
            tessellator.addVertexWithUV(f4 - f1, (float)j + f2, f7 + f1, d, d3);
        }
        if(byte0 == 2)
        {
            tessellator.addVertexWithUV(f5 + f1, (float)j + f2, f7 + f1, d1, d3);
            tessellator.addVertexWithUV(f5 + f1, (float)j + f2, f6 - f1, d, d3);
            tessellator.addVertexWithUV(f4 - f1, (float)j + f2, f6 - f1, d, d2);
            tessellator.addVertexWithUV(f4 - f1, (float)j + f2, f7 + f1, d1, d2);
        }
        d = (float)(i1 + 16) / 256F;
        d1 = ((float)(i1 + 16) + 15.99F) / 256F;
        d2 = (float)j1 / 256F;
        d3 = ((float)j1 + 15.99F) / 256F;
        if(!renderIBlockAccess.isBlockNormalCube(i, j + 1, k))
        {
            if(renderIBlockAccess.isBlockNormalCube(i - 1, j, k) && renderIBlockAccess.getBlockId(i - 1, j + 1, k) == Block.redstoneWire.blockID)
            {
                tessellator.addVertexWithUV((float)i + f2, (float)(j + 1) + f1, (float)(k + 1) + f1, d1, d2);
                tessellator.addVertexWithUV((float)i + f2, (float)(j + 0) - f1, (float)(k + 1) + f1, d, d2);
                tessellator.addVertexWithUV((float)i + f2, (float)(j + 0) - f1, (float)(k + 0) - f1, d, d3);
                tessellator.addVertexWithUV((float)i + f2, (float)(j + 1) + f1, (float)(k + 0) - f1, d1, d3);
            }
            if(renderIBlockAccess.isBlockNormalCube(i + 1, j, k) && renderIBlockAccess.getBlockId(i + 1, j + 1, k) == Block.redstoneWire.blockID)
            {
                tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 0) - f1, (float)(k + 1) + f1, d, d3);
                tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 1) + f1, (float)(k + 1) + f1, d1, d3);
                tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 1) + f1, (float)(k + 0) - f1, d1, d2);
                tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 0) - f1, (float)(k + 0) - f1, d, d2);
            }
            if(renderIBlockAccess.isBlockNormalCube(i, j, k - 1) && renderIBlockAccess.getBlockId(i, j + 1, k - 1) == Block.redstoneWire.blockID)
            {
                tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 0) - f1, (float)k + f2, d, d3);
                tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 1) + f1, (float)k + f2, d1, d3);
                tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 1) + f1, (float)k + f2, d1, d2);
                tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 0) - f1, (float)k + f2, d, d2);
            }
            if(renderIBlockAccess.isBlockNormalCube(i, j, k + 1) && renderIBlockAccess.getBlockId(i, j + 1, k + 1) == Block.redstoneWire.blockID)
            {
                tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 1) + f1, (float)(k + 1) - f2, d1, d2);
                tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 0) - f1, (float)(k + 1) - f2, d, d2);
                tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 0) - f1, (float)(k + 1) - f2, d, d3);
                tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 1) + f1, (float)(k + 1) - f2, d1, d3);
            }
        }
        return true;
    }

    public boolean renderMinecartTrack(Block block, int i, int j, int k)
    {
        Tessellator tessellator = Tessellator.instance;
        int l = renderIBlockAccess.getBlockMetadata(i, j, k);
        int i1 = block.getBlockTextureFromSideAndMetadata(0, l);
        if(overrideBlockTexture >= 0)
        {
            i1 = overrideBlockTexture;
        }
        float f = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        tessellator.setColorOpaque_F(f, f, f);
        int j1 = (i1 & 0xf) << 4;
        int k1 = i1 & 0xf0;
        double d = (float)j1 / 256F;
        double d1 = ((float)j1 + 15.99F) / 256F;
        double d2 = (float)k1 / 256F;
        double d3 = ((float)k1 + 15.99F) / 256F;
        float f1 = 0.0625F;
        float f2 = i + 1;
        float f3 = i + 1;
        float f4 = i + 0;
        float f5 = i + 0;
        float f6 = k + 0;
        float f7 = k + 1;
        float f8 = k + 1;
        float f9 = k + 0;
        float f10 = (float)j + f1;
        float f11 = (float)j + f1;
        float f12 = (float)j + f1;
        float f13 = (float)j + f1;
        if(l == 1 || l == 2 || l == 3 || l == 7)
        {
            f2 = f5 = i + 1;
            f3 = f4 = i + 0;
            f6 = f7 = k + 1;
            f8 = f9 = k + 0;
        } else
        if(l == 8)
        {
            f2 = f3 = i + 0;
            f4 = f5 = i + 1;
            f6 = f9 = k + 1;
            f7 = f8 = k + 0;
        } else
        if(l == 9)
        {
            f2 = f5 = i + 0;
            f3 = f4 = i + 1;
            f6 = f7 = k + 0;
            f8 = f9 = k + 1;
        }
        if(l == 2 || l == 4)
        {
            f10++;
            f13++;
        } else
        if(l == 3 || l == 5)
        {
            f11++;
            f12++;
        }
        tessellator.addVertexWithUV(f2, f10, f6, d1, d2);
        tessellator.addVertexWithUV(f3, f11, f7, d1, d3);
        tessellator.addVertexWithUV(f4, f12, f8, d, d3);
        tessellator.addVertexWithUV(f5, f13, f9, d, d2);
        tessellator.addVertexWithUV(f5, f13, f9, d, d2);
        tessellator.addVertexWithUV(f4, f12, f8, d, d3);
        tessellator.addVertexWithUV(f3, f11, f7, d1, d3);
        tessellator.addVertexWithUV(f2, f10, f6, d1, d2);
        return true;
    }

    public boolean renderLadder(Block block, int i, int j, int k)
    {
        Tessellator tessellator = Tessellator.instance;
        int l = block.getTextureIndex(0);
        if(overrideBlockTexture >= 0)
        {
            l = overrideBlockTexture;
        }
        float f = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        tessellator.setColorOpaque_F(f, f, f);
        int i1 = (l & 0xf) << 4;
        int j1 = l & 0xf0;
        double d = (float)i1 / 256F;
        double d1 = ((float)i1 + 15.99F) / 256F;
        double d2 = (float)j1 / 256F;
        double d3 = ((float)j1 + 15.99F) / 256F;
        int k1 = renderIBlockAccess.getBlockMetadata(i, j, k);
        float f1 = 0.0F;
        float f2 = 0.05F;
        if(k1 == 5)
        {
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 1) + f1, (float)(k + 1) + f1, d, d2);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 0) - f1, (float)(k + 1) + f1, d, d3);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 0) - f1, (float)(k + 0) - f1, d1, d3);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 1) + f1, (float)(k + 0) - f1, d1, d2);
        }
        if(k1 == 4)
        {
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 0) - f1, (float)(k + 1) + f1, d1, d3);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 1) + f1, (float)(k + 1) + f1, d1, d2);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 1) + f1, (float)(k + 0) - f1, d, d2);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 0) - f1, (float)(k + 0) - f1, d, d3);
        }
        if(k1 == 3)
        {
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 0) - f1, (float)k + f2, d1, d3);
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 1) + f1, (float)k + f2, d1, d2);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 1) + f1, (float)k + f2, d, d2);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 0) - f1, (float)k + f2, d, d3);
        }
        if(k1 == 2)
        {
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 1) + f1, (float)(k + 1) - f2, d, d2);
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 0) - f1, (float)(k + 1) - f2, d, d3);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 0) - f1, (float)(k + 1) - f2, d1, d3);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 1) + f1, (float)(k + 1) - f2, d1, d2);
        }
        return true;
    }

    public boolean renderPlant(Block block, int i, int j, int k)
    {
        Tessellator tessellator = Tessellator.instance;
        float f = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        tessellator.setColorOpaque_F(f, f, f);
        renderCrossedSquares(block, renderIBlockAccess.getBlockMetadata(i, j, k), i, j, k);
        return true;
    }

    public boolean renderCrops(Block block, int i, int j, int k)
    {
        Tessellator tessellator = Tessellator.instance;
        float f = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        tessellator.setColorOpaque_F(f, f, f);
        func_1245_b(block, renderIBlockAccess.getBlockMetadata(i, j, k), i, (float)j - 0.0625F, k);
        return true;
    }

    public void func_1237_a(Block block, double d, double d1, double d2, 
            double d3, double d4)
    {
        Tessellator tessellator = Tessellator.instance;
        int i = block.getTextureIndex(0);
        if(overrideBlockTexture >= 0)
        {
            i = overrideBlockTexture;
        }
        int j = (i & 0xf) << 4;
        int k = i & 0xf0;
        float f = (float)j / 256F;
        float f1 = ((float)j + 15.99F) / 256F;
        float f2 = (float)k / 256F;
        float f3 = ((float)k + 15.99F) / 256F;
        double d5 = (double)f + 0.02734375D;
        double d6 = (double)f2 + 0.0234375D;
        double d7 = (double)f + 0.03515625D;
        double d8 = (double)f2 + 0.03125D;
        d += 0.5D;
        d2 += 0.5D;
        double d9 = d - 0.5D;
        double d10 = d + 0.5D;
        double d11 = d2 - 0.5D;
        double d12 = d2 + 0.5D;
        double d13 = 0.0625D;
        double d14 = 0.625D;
        tessellator.addVertexWithUV((d + d3 * (1.0D - d14)) - d13, d1 + d14, (d2 + d4 * (1.0D - d14)) - d13, d5, d6);
        tessellator.addVertexWithUV((d + d3 * (1.0D - d14)) - d13, d1 + d14, d2 + d4 * (1.0D - d14) + d13, d5, d8);
        tessellator.addVertexWithUV(d + d3 * (1.0D - d14) + d13, d1 + d14, d2 + d4 * (1.0D - d14) + d13, d7, d8);
        tessellator.addVertexWithUV(d + d3 * (1.0D - d14) + d13, d1 + d14, (d2 + d4 * (1.0D - d14)) - d13, d7, d6);
        tessellator.addVertexWithUV(d - d13, d1 + 1.0D, d11, f, f2);
        tessellator.addVertexWithUV((d - d13) + d3, d1 + 0.0D, d11 + d4, f, f3);
        tessellator.addVertexWithUV((d - d13) + d3, d1 + 0.0D, d12 + d4, f1, f3);
        tessellator.addVertexWithUV(d - d13, d1 + 1.0D, d12, f1, f2);
        tessellator.addVertexWithUV(d + d13, d1 + 1.0D, d12, f, f2);
        tessellator.addVertexWithUV(d + d3 + d13, d1 + 0.0D, d12 + d4, f, f3);
        tessellator.addVertexWithUV(d + d3 + d13, d1 + 0.0D, d11 + d4, f1, f3);
        tessellator.addVertexWithUV(d + d13, d1 + 1.0D, d11, f1, f2);
        tessellator.addVertexWithUV(d9, d1 + 1.0D, d2 + d13, f, f2);
        tessellator.addVertexWithUV(d9 + d3, d1 + 0.0D, d2 + d13 + d4, f, f3);
        tessellator.addVertexWithUV(d10 + d3, d1 + 0.0D, d2 + d13 + d4, f1, f3);
        tessellator.addVertexWithUV(d10, d1 + 1.0D, d2 + d13, f1, f2);
        tessellator.addVertexWithUV(d10, d1 + 1.0D, d2 - d13, f, f2);
        tessellator.addVertexWithUV(d10 + d3, d1 + 0.0D, (d2 - d13) + d4, f, f3);
        tessellator.addVertexWithUV(d9 + d3, d1 + 0.0D, (d2 - d13) + d4, f1, f3);
        tessellator.addVertexWithUV(d9, d1 + 1.0D, d2 - d13, f1, f2);
    }

    public void renderCrossedSquares(Block block, int i, double d, double d1, double d2)
    {
        Tessellator tessellator = Tessellator.instance;
        int j = block.getBlockTextureFromSideAndMetadata(0, i);
        if(overrideBlockTexture >= 0)
        {
            j = overrideBlockTexture;
        }
        int k = (j & 0xf) << 4;
        int l = j & 0xf0;
        double d3 = (float)k / 256F;
        double d4 = ((float)k + 15.99F) / 256F;
        double d5 = (float)l / 256F;
        double d6 = ((float)l + 15.99F) / 256F;
        double d7 = (d + 0.5D) - 0.44999998807907104D;
        double d8 = d + 0.5D + 0.44999998807907104D;
        double d9 = (d2 + 0.5D) - 0.44999998807907104D;
        double d10 = d2 + 0.5D + 0.44999998807907104D;
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d4, d5);
    }

    public void func_1245_b(Block block, int i, double d, double d1, double d2)
    {
        Tessellator tessellator = Tessellator.instance;
        int j = block.getBlockTextureFromSideAndMetadata(0, i);
        if(overrideBlockTexture >= 0)
        {
            j = overrideBlockTexture;
        }
        int k = (j & 0xf) << 4;
        int l = j & 0xf0;
        double d3 = (float)k / 256F;
        double d4 = ((float)k + 15.99F) / 256F;
        double d5 = (float)l / 256F;
        double d6 = ((float)l + 15.99F) / 256F;
        double d7 = (d + 0.5D) - 0.25D;
        double d8 = d + 0.5D + 0.25D;
        double d9 = (d2 + 0.5D) - 0.5D;
        double d10 = d2 + 0.5D + 0.5D;
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d4, d5);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d4, d5);
        d7 = (d + 0.5D) - 0.5D;
        d8 = d + 0.5D + 0.5D;
        d9 = (d2 + 0.5D) - 0.25D;
        d10 = d2 + 0.5D + 0.25D;
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d4, d5);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d4, d5);
    }
    
    public float getRandomXYZOffset_Y(int x, int y, int z){
    	if(randomWater){
    		Random rand = new Random();
    		rand.setSeed((long)(x*x * y*y * z*z));;
    		return ((rand.nextFloat() - 0.5F) / 10F);
    	}
    	return 0F;
    }

    public boolean renderFluid(Block block, int posX, int posY, int posZ)
    {
        Tessellator tessellator = Tessellator.instance;
        boolean topBlockCheck = block.shouldSideBeRendered(renderIBlockAccess, posX, posY + 1, posZ, 1);
        boolean bottomBlockCheck = block.shouldSideBeRendered(renderIBlockAccess, posX, posY - 1, posZ, 0);
        boolean blockFaceCheck[] = new boolean[4];
        blockFaceCheck[0] = block.shouldSideBeRendered(renderIBlockAccess, posX, posY, posZ - 1, 2);
        blockFaceCheck[1] = block.shouldSideBeRendered(renderIBlockAccess, posX, posY, posZ + 1, 3);
        blockFaceCheck[2] = block.shouldSideBeRendered(renderIBlockAccess, posX - 1, posY, posZ, 4);
        blockFaceCheck[3] = block.shouldSideBeRendered(renderIBlockAccess, posX + 1, posY, posZ, 5);
        if(!topBlockCheck && !bottomBlockCheck && !blockFaceCheck[0] && !blockFaceCheck[1] && !blockFaceCheck[2] && !blockFaceCheck[3])
        {
            return false;
        }
        boolean flag2 = false;
        float f = 0.5F;
        float f1 = 1.0F;
        float f2 = 0.8F;
        float f3 = 0.6F;
        double d = 0.0D;
        double d1 = 1.0D;
        Material material = block.blockMaterial;
        int texIndexCheck = renderIBlockAccess.getBlockMetadata(posX, posY, posZ);
        float f4 = getFluidSideHeight(posX, posY, posZ, material) + getRandomXYZOffset_Y(posX, posY, posZ);
        float f5 = getFluidSideHeight(posX, posY, posZ + 1, material) + getRandomXYZOffset_Y(posX, posY, posZ + 1);
        float f6 = getFluidSideHeight(posX + 1, posY, posZ + 1, material) + getRandomXYZOffset_Y(posX + 1, posY, posZ + 1);
        float f7 = getFluidSideHeight(posX + 1, posY, posZ, material) + getRandomXYZOffset_Y(posX + 1, posY, posZ);
        if(renderAllFaces || topBlockCheck)
        {
            flag2 = true;
            int i1 = block.getBlockTextureFromSideAndMetadata(1, texIndexCheck);
            float f9 = (float)BlockFluids.getFlowDirectionRadians(renderIBlockAccess, posX, posY, posZ, material);
            if(f9 > -999F) //checks if the fluid is flowing in any direction
            {
                i1 = block.getBlockTextureFromSideAndMetadata(7, texIndexCheck);
            }
            int l1 = (i1 & 0xf) << 4;
            int j2 = i1 & 0xf0;
            double d2 = ((double)l1 + 8D) / 256D;
            double d3 = ((double)j2 + 8D) / 256D;
            if(f9 < -999F)
            {
                f9 = 0.0F;
            } else
            {
                d2 = (float)(l1 + 16) / 256F;
                d3 = (float)(j2 + 16) / 256F;
            }
            float f11 = (MathHelper.sin(f9) * 8F) / 256F;
            float f13 = (MathHelper.cos(f9) * 8F) / 256F;
            float f15 = block.getBlockBrightness(renderIBlockAccess, posX, posY, posZ);
            tessellator.setColorOpaque_F(f1 * f15, f1 * f15, f1 * f15);
            tessellator.addVertexWithUV(posX + 0, (float)posY + f4, posZ + 0, d2 - (double)f13 - (double)f11, (d3 - (double)f13) + (double)f11);
            tessellator.addVertexWithUV(posX + 0, (float)posY + f5, posZ + 1, (d2 - (double)f13) + (double)f11, d3 + (double)f13 + (double)f11);
            tessellator.addVertexWithUV(posX + 1, (float)posY + f6, posZ + 1, d2 + (double)f13 + (double)f11, (d3 + (double)f13) - (double)f11);
            tessellator.addVertexWithUV(posX + 1, (float)posY + f7, posZ + 0, (d2 + (double)f13) - (double)f11, d3 - (double)f13 - (double)f11);
        }
        if(renderAllFaces || bottomBlockCheck)
        {
            float f8 = block.getBlockBrightness(renderIBlockAccess, posX, posY - 1, posZ);
            tessellator.setColorOpaque_F(f * f8, f * f8, f * f8);
            func_1244_a(block, posX, posY, posZ, block.getTextureIndex(0));
            flag2 = true;
        }
        for(int sideIterator = 0; sideIterator < 4; sideIterator++)
        {
            int pointX = posX;
            int pointY = posY;
            int pointZ = posZ;
            if(sideIterator == 0)
            {
                pointZ--;
            }
            if(sideIterator == 1)
            {
                pointZ++;
            }
            if(sideIterator == 2)
            {
                pointX--;
            }
            if(sideIterator == 3)
            {
                pointX++;
            }
            int l2 = block.getBlockTextureFromSideAndMetadata(sideIterator + 2, texIndexCheck);
            int i3 = (l2 & 0xf) << 4;
            int j3 = l2 & 0xf0;
            if(!renderAllFaces && !blockFaceCheck[sideIterator])
            {
                continue;
            }
            float f10;
            float f12;
            float f14;
            float f16;
            float f17;
            float f18;
            if(sideIterator == 0)
            {
                f10 = f4;
                f12 = f7;
                f14 = posX;
                f17 = posX + 1;
                f16 = posZ;
                f18 = posZ;
            } else
            if(sideIterator == 1)
            {
                f10 = f6;
                f12 = f5;
                f14 = posX + 1;
                f17 = posX;
                f16 = posZ + 1;
                f18 = posZ + 1;
            } else
            if(sideIterator == 2)
            {
                f10 = f5;
                f12 = f4;
                f14 = posX;
                f17 = posX;
                f16 = posZ + 1;
                f18 = posZ;
            } else
            {
                f10 = f7;
                f12 = f6;
                f14 = posX + 1;
                f17 = posX + 1;
                f16 = posZ;
                f18 = posZ + 1;
            }
            flag2 = true;
            double d4 = (float)(i3 + 0) / 256F;
            double d5 = ((double)(i3 + 16) - 0.01D) / 256D;
            double d6 = ((float)j3 + (1.0F - f10) * 16F) / 256F;
            double d7 = ((float)j3 + (1.0F - f12) * 16F) / 256F;
            double d8 = ((double)(j3 + 16) - 0.01D) / 256D;
            float f19 = block.getBlockBrightness(renderIBlockAccess, pointX, pointY, pointZ);
            if(sideIterator < 2)
            {
                f19 *= f2;
            } else
            {
                f19 *= f3;
            }
            tessellator.setColorOpaque_F(f1 * f19, f1 * f19, f1 * f19);
            tessellator.addVertexWithUV(f14, (float)posY + f10, f16, d4, d6);
            tessellator.addVertexWithUV(f17, (float)posY + f12, f18, d5, d7);
            tessellator.addVertexWithUV(f17, posY + 0, f18, d5, d8);
            tessellator.addVertexWithUV(f14, posY + 0, f16, d4, d8);
        }

        block.minY = d;
        block.maxY = d1;
        return flag2;
    }

    private float getFluidSideHeight(int x, int y, int z, Material material)
    {
        int l = 0;
        float f = 0.0F;
        for(int sideIterator = 0; sideIterator < 4; sideIterator++)
        {
            int j1 = x - (sideIterator & 1);
            int k1 = y;
            int l1 = z - (sideIterator >> 1 & 1);
            if(renderIBlockAccess.getMaterialXYZ(j1, k1 + 1, l1) == material)
            {
                return 1.0F;
            }
            Material material1 = renderIBlockAccess.getMaterialXYZ(j1, k1, l1);
            if(material1 == material)
            {
                int i2 = renderIBlockAccess.getBlockMetadata(j1, k1, l1);
                if(i2 >= 8 || i2 == 0)
                {
                    f += BlockFluids.getFluidLevel(i2) * 10F;
                    l += 10;
                }
                f += BlockFluids.getFluidLevel(i2);
                l++;
                continue;
            }
            if(!material1.isSolidMaterial())
            {
                f++;
                l++;
            }
        }

        return 1.0F - f / (float)l;
    }

    public void func_1243_a(Block block, World world, int i, int j, int k)
    {
	        float bottomBrightness = 0.5F;
	        float topBrightness = 1.0F;
	        float ewBrightness = 0.8F;
	        float nsBrightness = 0.6F;
	        Tessellator tessellator = Tessellator.instance;
	        tessellator.startDrawingQuads();
	        float blockBrightnessLevel = block.getBlockBrightness(world, i, j, k);
	        float belowBrightnessLevel = block.getBlockBrightness(world, i, j - 1, k);
	        if(belowBrightnessLevel < blockBrightnessLevel)
	        {
	            belowBrightnessLevel = blockBrightnessLevel;
	        }
	        tessellator.setColorOpaque_F(bottomBrightness * belowBrightnessLevel, bottomBrightness * belowBrightnessLevel, bottomBrightness * belowBrightnessLevel);
	        func_1244_a(block, -0.5D, -0.5D, -0.5D, block.getTextureIndex(0));
	        belowBrightnessLevel = block.getBlockBrightness(world, i, j + 1, k);
	        if(belowBrightnessLevel < blockBrightnessLevel)
	        {
	            belowBrightnessLevel = blockBrightnessLevel;
	        }
	        tessellator.setColorOpaque_F(topBrightness * belowBrightnessLevel, topBrightness * belowBrightnessLevel, topBrightness * belowBrightnessLevel);
	        func_1217_b(block, -0.5D, -0.5D, -0.5D, block.getTextureIndex(1));
	        belowBrightnessLevel = block.getBlockBrightness(world, i, j, k - 1);
	        if(belowBrightnessLevel < blockBrightnessLevel)
	        {
	            belowBrightnessLevel = blockBrightnessLevel;
	        }
	        tessellator.setColorOpaque_F(ewBrightness * belowBrightnessLevel, ewBrightness * belowBrightnessLevel, ewBrightness * belowBrightnessLevel);
	        func_1220_c(block, -0.5D, -0.5D, -0.5D, block.getTextureIndex(2));
	        belowBrightnessLevel = block.getBlockBrightness(world, i, j, k + 1);
	        if(belowBrightnessLevel < blockBrightnessLevel)
	        {
	            belowBrightnessLevel = blockBrightnessLevel;
	        }
	        tessellator.setColorOpaque_F(ewBrightness * belowBrightnessLevel, ewBrightness * belowBrightnessLevel, ewBrightness * belowBrightnessLevel);
	        func_1225_d(block, -0.5D, -0.5D, -0.5D, block.getTextureIndex(3));
	        belowBrightnessLevel = block.getBlockBrightness(world, i - 1, j, k);
	        if(belowBrightnessLevel < blockBrightnessLevel)
	        {
	            belowBrightnessLevel = blockBrightnessLevel;
	        }
	        tessellator.setColorOpaque_F(nsBrightness * belowBrightnessLevel, nsBrightness * belowBrightnessLevel, nsBrightness * belowBrightnessLevel);
	        func_1231_e(block, -0.5D, -0.5D, -0.5D, block.getTextureIndex(4));
	        belowBrightnessLevel = block.getBlockBrightness(world, i + 1, j, k);
	        if(belowBrightnessLevel < blockBrightnessLevel)
	        {
	            belowBrightnessLevel = blockBrightnessLevel;
	        }
	        tessellator.setColorOpaque_F(nsBrightness * belowBrightnessLevel, nsBrightness * belowBrightnessLevel, nsBrightness * belowBrightnessLevel);
	        func_1236_f(block, -0.5D, -0.5D, -0.5D, block.getTextureIndex(5));
	        tessellator.draw();
    	
        
    }

    public boolean renderBlock(Block block, int i, int j, int k)
    {
        int l = block.colorMultiplier(renderIBlockAccess, i, j, k);
        float f = (float)(l >> 16 & 0xff) / 255F;
        float f1 = (float)(l >> 8 & 0xff) / 255F;
        float f2 = (float)(l & 0xff) / 255F;
        //return func_1215_a(block, i, j, k, f, f1, f2);
        return renderStandardBlockWithAmbientOcclusion(block, i, j, k, f, f1, f2);
    }
    
    public boolean renderStandardBlockWithAmbientOcclusion(Block block, int i, int j, int k, float f, float f1, float f2)
    {
        enableAO = true;
        boolean flag = false;
        boolean flag1 = true;
        boolean flag2 = true;
        boolean flag3 = true;
        boolean flag4 = true;
        boolean flag5 = true;
        boolean flag6 = true;
        aoLightValueXNeg = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k);
        aoLightValueYNeg = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k);
        aoLightValueZNeg = block.getBlockBrightness(renderIBlockAccess, i, j, k - 1);
        aoLightValueXPos = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k);
        aoLightValueYPos = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k);
        aoLightValueZPos = block.getBlockBrightness(renderIBlockAccess, i, j, k + 1);
        if(block.blockIndexInTexture == 3)
        {
            flag1 = flag3 = flag4 = flag5 = flag6 = false;
        }
        if(overrideBlockTexture >= 0)
        {
            flag1 = flag3 = flag4 = flag5 = flag6 = false;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j - 1, k, 0))
        {
            float f4;
            float f11;
            float f18;
            float f25;
            if(field_22352_G > 0)
            {
                j--;
                field_22376_n = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k);
                field_22374_p = block.getBlockBrightness(renderIBlockAccess, i, j, k - 1);
                field_22373_q = block.getBlockBrightness(renderIBlockAccess, i, j, k + 1);
                field_22371_s = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k);
                field_22377_m = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k - 1);
                field_22375_o = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k + 1);
                field_22372_r = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k - 1);
                field_22370_t = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k + 1);
                j++;
                f4 = (field_22375_o + field_22376_n + field_22373_q + aoLightValueYNeg) / 4F;
                f25 = (field_22373_q + aoLightValueYNeg + field_22370_t + field_22371_s) / 4F;
                f18 = (aoLightValueYNeg + field_22374_p + field_22371_s + field_22372_r) / 4F;
                f11 = (field_22376_n + field_22377_m + aoLightValueYNeg + field_22374_p) / 4F;
            } else
            {
                f4 = f11 = f18 = f25 = aoLightValueYNeg;
            }
            colorRedTopLeft = colorRedBottomLeft = colorRedBottomRight = colorRedTopRight = (flag1 ? f : 1.0F) * 0.5F;
            colorGreenTopLeft = colorGreenBottomLeft = colorGreenBottomRight = colorGreenTopRight = (flag1 ? f1 : 1.0F) * 0.5F;
            colorBlueTopLeft = colorBlueBottomLeft = colorBlueBottomRight = colorBlueTopRight = (flag1 ? f2 : 1.0F) * 0.5F;
            colorRedTopLeft *= f4;
            colorGreenTopLeft *= f4;
            colorBlueTopLeft *= f4;
            colorRedBottomLeft *= f11;
            colorGreenBottomLeft *= f11;
            colorBlueBottomLeft *= f11;
            colorRedBottomRight *= f18;
            colorGreenBottomRight *= f18;
            colorBlueBottomRight *= f18;
            colorRedTopRight *= f25;
            colorGreenTopRight *= f25;
            colorBlueTopRight *= f25;
            func_1244_a(block, (double)i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 0));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j + 1, k, 1))
        {
            float f5;
            float f12;
            float f19;
            float f26;
            if(field_22352_G > 0)
            {
                j++;
                field_22368_v = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k);
                field_22364_z = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k);
                field_22366_x = block.getBlockBrightness(renderIBlockAccess, i, j, k - 1);
                field_22362_A = block.getBlockBrightness(renderIBlockAccess, i, j, k + 1);
                field_22369_u = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k - 1);
                field_22365_y = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k - 1);
                field_22367_w = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k + 1);
                field_22360_B = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k + 1);
                j--;
                f26 = (field_22367_w + field_22368_v + field_22362_A + aoLightValueYPos) / 4F;
                f5 = (field_22362_A + aoLightValueYPos + field_22360_B + field_22364_z) / 4F;
                f12 = (aoLightValueYPos + field_22366_x + field_22364_z + field_22365_y) / 4F;
                f19 = (field_22368_v + field_22369_u + aoLightValueYPos + field_22366_x) / 4F;
            } else
            {
                f5 = f12 = f19 = f26 = aoLightValueYPos;
            }
            colorRedTopLeft = colorRedBottomLeft = colorRedBottomRight = colorRedTopRight = flag2 ? f : 1.0F;
            colorGreenTopLeft = colorGreenBottomLeft = colorGreenBottomRight = colorGreenTopRight = flag2 ? f1 : 1.0F;
            colorBlueTopLeft = colorBlueBottomLeft = colorBlueBottomRight = colorBlueTopRight = flag2 ? f2 : 1.0F;
            colorRedTopLeft *= f5;
            colorGreenTopLeft *= f5;
            colorBlueTopLeft *= f5;
            colorRedBottomLeft *= f12;
            colorGreenBottomLeft *= f12;
            colorBlueBottomLeft *= f12;
            colorRedBottomRight *= f19;
            colorGreenBottomRight *= f19;
            colorBlueBottomRight *= f19;
            colorRedTopRight *= f26;
            colorGreenTopRight *= f26;
            colorBlueTopRight *= f26;
            func_1217_b(block, (double)i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 1));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j, k - 1, 2))
        {
            float f6;
            float f13;
            float f20;
            float f27;
            if(field_22352_G > 0)
            {
                k--;
                field_22358_C = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k);
                field_22374_p = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k);
                field_22366_x = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k);
                field_22356_D = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k);
                field_22377_m = block.getBlockBrightness(renderIBlockAccess, i - 1, j - 1, k);
                field_22369_u = block.getBlockBrightness(renderIBlockAccess, i - 1, j + 1, k);
                field_22372_r = block.getBlockBrightness(renderIBlockAccess, i + 1, j - 1, k);
                field_22365_y = block.getBlockBrightness(renderIBlockAccess, i + 1, j + 1, k);
                k++;
                f6 = (field_22358_C + field_22369_u + aoLightValueZNeg + field_22366_x) / 4F;
                f13 = (aoLightValueZNeg + field_22366_x + field_22356_D + field_22365_y) / 4F;
                f20 = (field_22374_p + aoLightValueZNeg + field_22372_r + field_22356_D) / 4F;
                f27 = (field_22377_m + field_22358_C + field_22374_p + aoLightValueZNeg) / 4F;
            } else
            {
                f6 = f13 = f20 = f27 = aoLightValueZNeg;
            }
            colorRedTopLeft = colorRedBottomLeft = colorRedBottomRight = colorRedTopRight = (flag3 ? f : 1.0F) * 0.8F;
            colorGreenTopLeft = colorGreenBottomLeft = colorGreenBottomRight = colorGreenTopRight = (flag3 ? f1 : 1.0F) * 0.8F;
            colorBlueTopLeft = colorBlueBottomLeft = colorBlueBottomRight = colorBlueTopRight = (flag3 ? f2 : 1.0F) * 0.8F;
            colorRedTopLeft *= f6;
            colorGreenTopLeft *= f6;
            colorBlueTopLeft *= f6;
            colorRedBottomLeft *= f13;
            colorGreenBottomLeft *= f13;
            colorBlueBottomLeft *= f13;
            colorRedBottomRight *= f20;
            colorGreenBottomRight *= f20;
            colorBlueBottomRight *= f20;
            colorRedTopRight *= f27;
            colorGreenTopRight *= f27;
            colorBlueTopRight *= f27;
            int l = block.getTextureIndex(renderIBlockAccess, i, j, k, 2);
            func_1220_c(block, (double)i, j, k, l);
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j, k + 1, 3))
        {
            float f7;
            float f14;
            float f21;
            float f28;
            if(field_22352_G > 0)
            {
                k++;
                field_22354_E = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k);
                field_22353_F = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k);
                field_22373_q = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k);
                field_22362_A = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k);
                field_22375_o = block.getBlockBrightness(renderIBlockAccess, i - 1, j - 1, k);
                field_22367_w = block.getBlockBrightness(renderIBlockAccess, i - 1, j + 1, k);
                field_22370_t = block.getBlockBrightness(renderIBlockAccess, i + 1, j - 1, k);
                field_22360_B = block.getBlockBrightness(renderIBlockAccess, i + 1, j + 1, k);
                k--;
                f7 = (field_22354_E + field_22367_w + aoLightValueZPos + field_22362_A) / 4F;
                f28 = (aoLightValueZPos + field_22362_A + field_22353_F + field_22360_B) / 4F;
                f21 = (field_22373_q + aoLightValueZPos + field_22370_t + field_22353_F) / 4F;
                f14 = (field_22375_o + field_22354_E + field_22373_q + aoLightValueZPos) / 4F;
            } else
            {
                f7 = f14 = f21 = f28 = aoLightValueZPos;
            }
            colorRedTopLeft = colorRedBottomLeft = colorRedBottomRight = colorRedTopRight = (flag4 ? f : 1.0F) * 0.8F;
            colorGreenTopLeft = colorGreenBottomLeft = colorGreenBottomRight = colorGreenTopRight = (flag4 ? f1 : 1.0F) * 0.8F;
            colorBlueTopLeft = colorBlueBottomLeft = colorBlueBottomRight = colorBlueTopRight = (flag4 ? f2 : 1.0F) * 0.8F;
            colorRedTopLeft *= f7;
            colorGreenTopLeft *= f7;
            colorBlueTopLeft *= f7;
            colorRedBottomLeft *= f14;
            colorGreenBottomLeft *= f14;
            colorBlueBottomLeft *= f14;
            colorRedBottomRight *= f21;
            colorGreenBottomRight *= f21;
            colorBlueBottomRight *= f21;
            colorRedTopRight *= f28;
            colorGreenTopRight *= f28;
            colorBlueTopRight *= f28;
            func_1225_d(block, (double)i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 3));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i - 1, j, k, 4))
        {
            float f8;
            float f15;
            float f22;
            float f29;
            if(field_22352_G > 0)
            {
                i--;
                field_22376_n = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k);
                field_22358_C = block.getBlockBrightness(renderIBlockAccess, i, j, k - 1);
                field_22354_E = block.getBlockBrightness(renderIBlockAccess, i, j, k + 1);
                field_22368_v = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k);
                field_22377_m = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k - 1);
                field_22375_o = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k + 1);
                field_22369_u = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k - 1);
                field_22367_w = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k + 1);
                i++;
                f29 = (field_22376_n + field_22375_o + aoLightValueXNeg + field_22354_E) / 4F;
                f8 = (aoLightValueXNeg + field_22354_E + field_22368_v + field_22367_w) / 4F;
                f15 = (field_22358_C + aoLightValueXNeg + field_22369_u + field_22368_v) / 4F;
                f22 = (field_22377_m + field_22376_n + field_22358_C + aoLightValueXNeg) / 4F;
            } else
            {
                f8 = f15 = f22 = f29 = aoLightValueXNeg;
            }
            colorRedTopLeft = colorRedBottomLeft = colorRedBottomRight = colorRedTopRight = (flag5 ? f : 1.0F) * 0.6F;
            colorGreenTopLeft = colorGreenBottomLeft = colorGreenBottomRight = colorGreenTopRight = (flag5 ? f1 : 1.0F) * 0.6F;
            colorBlueTopLeft = colorBlueBottomLeft = colorBlueBottomRight = colorBlueTopRight = (flag5 ? f2 : 1.0F) * 0.6F;
            colorRedTopLeft *= f8;
            colorGreenTopLeft *= f8;
            colorBlueTopLeft *= f8;
            colorRedBottomLeft *= f15;
            colorGreenBottomLeft *= f15;
            colorBlueBottomLeft *= f15;
            colorRedBottomRight *= f22;
            colorGreenBottomRight *= f22;
            colorBlueBottomRight *= f22;
            colorRedTopRight *= f29;
            colorGreenTopRight *= f29;
            colorBlueTopRight *= f29;
            int j1 = block.getTextureIndex(renderIBlockAccess, i, j, k, 4);
            func_1231_e(block, (double)i, j, k, j1);
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i + 1, j, k, 5))
        {
            float f9;
            float f16;
            float f23;
            float f30;
            if(field_22352_G > 0)
            {
                i++;
                field_22371_s = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k);
                field_22356_D = block.getBlockBrightness(renderIBlockAccess, i, j, k - 1);
                field_22353_F = block.getBlockBrightness(renderIBlockAccess, i, j, k + 1);
                field_22364_z = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k);
                field_22372_r = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k - 1);
                field_22370_t = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k + 1);
                field_22365_y = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k - 1);
                field_22360_B = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k + 1);
                i--;
                f9 = (field_22371_s + field_22370_t + aoLightValueXPos + field_22353_F) / 4F;
                f30 = (aoLightValueXPos + field_22353_F + field_22364_z + field_22360_B) / 4F;
                f23 = (field_22356_D + aoLightValueXPos + field_22365_y + field_22364_z) / 4F;
                f16 = (field_22372_r + field_22371_s + field_22356_D + aoLightValueXPos) / 4F;
            } else
            {
                f9 = f16 = f23 = f30 = aoLightValueXPos;
            }
            colorRedTopLeft = colorRedBottomLeft = colorRedBottomRight = colorRedTopRight = (flag6 ? f : 1.0F) * 0.6F;
            colorGreenTopLeft = colorGreenBottomLeft = colorGreenBottomRight = colorGreenTopRight = (flag6 ? f1 : 1.0F) * 0.6F;
            colorBlueTopLeft = colorBlueBottomLeft = colorBlueBottomRight = colorBlueTopRight = (flag6 ? f2 : 1.0F) * 0.6F;
            colorRedTopLeft *= f9;
            colorGreenTopLeft *= f9;
            colorBlueTopLeft *= f9;
            colorRedBottomLeft *= f16;
            colorGreenBottomLeft *= f16;
            colorBlueBottomLeft *= f16;
            colorRedBottomRight *= f23;
            colorGreenBottomRight *= f23;
            colorBlueBottomRight *= f23;
            colorRedTopRight *= f30;
            colorGreenTopRight *= f30;
            colorBlueTopRight *= f30;
            int k1 = block.getTextureIndex(renderIBlockAccess, i, j, k, 5);
            func_1236_f(block, (double)i, j, k, k1);
            flag = true;
        }
        enableAO = false;
        return flag;
    }

    public boolean func_1215_a(Block block, int i, int j, int k, float f, float f1, float f2)
    {
        Tessellator tessellator = Tessellator.instance;
        boolean flag = false;
        float f3 = 0.5F;
        float f4 = 1.0F;
        float f5 = 0.8F;
        float f6 = 0.6F;
        float f7 = f3 * f;
        float f8 = f4 * f;
        float f9 = f5 * f;
        float f10 = f6 * f;
        float f11 = f3 * f1;
        float f12 = f4 * f1;
        float f13 = f5 * f1;
        float f14 = f6 * f1;
        float f15 = f3 * f2;
        float f16 = f4 * f2;
        float f17 = f5 * f2;
        float f18 = f6 * f2;
        float f19 = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j - 1, k, 0))
        {
            float f20 = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k);
            tessellator.setColorOpaque_F(f7 * f20, f11 * f20, f15 * f20);
            func_1244_a(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 0));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j + 1, k, 1))
        {
            float f21 = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k);
            if(block.maxY != 1.0D && !block.blockMaterial.getIsGroundCover())
            {
                f21 = f19;
            }
            tessellator.setColorOpaque_F(f8 * f21, f12 * f21, f16 * f21);
            func_1217_b(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 1));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j, k - 1, 2))
        {
            float f22 = block.getBlockBrightness(renderIBlockAccess, i, j, k - 1);
            if(block.minZ > 0.0D)
            {
                f22 = f19;
            }
            tessellator.setColorOpaque_F(f9 * f22, f13 * f22, f17 * f22);
            func_1220_c(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 2));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j, k + 1, 3))
        {
            float f23 = block.getBlockBrightness(renderIBlockAccess, i, j, k + 1);
            if(block.maxZ < 1.0D)
            {
                f23 = f19;
            }
            tessellator.setColorOpaque_F(f9 * f23, f13 * f23, f17 * f23);
            func_1225_d(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 3));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i - 1, j, k, 4))
        {
            float f24 = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k);
            if(block.minX > 0.0D)
            {
                f24 = f19;
            }
            tessellator.setColorOpaque_F(f10 * f24, f14 * f24, f18 * f24);
            func_1231_e(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 4));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i + 1, j, k, 5))
        {
            float f25 = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k);
            if(block.maxX < 1.0D)
            {
                f25 = f19;
            }
            tessellator.setColorOpaque_F(f10 * f25, f14 * f25, f18 * f25);
            func_1236_f(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 5));
            flag = true;
        }
        return flag;
    }

    public boolean renderCactus(Block block, int i, int j, int k)
    {
        int l = block.colorMultiplier(renderIBlockAccess, i, j, k);
        float f = (float)(l >> 16 & 0xff) / 255F;
        float f1 = (float)(l >> 8 & 0xff) / 255F;
        float f2 = (float)(l & 0xff) / 255F;
        return func_1230_b(block, i, j, k, f, f1, f2);
    }

    public boolean func_1230_b(Block block, int i, int j, int k, float f, float f1, float f2)
    {
        Tessellator tessellator = Tessellator.instance;
        boolean flag = false;
        float f3 = 0.5F;
        float f4 = 1.0F;
        float f5 = 0.8F;
        float f6 = 0.6F;
        float f7 = f3 * f;
        float f8 = f4 * f;
        float f9 = f5 * f;
        float f10 = f6 * f;
        float f11 = f3 * f1;
        float f12 = f4 * f1;
        float f13 = f5 * f1;
        float f14 = f6 * f1;
        float f15 = f3 * f2;
        float f16 = f4 * f2;
        float f17 = f5 * f2;
        float f18 = f6 * f2;
        float f19 = 0.0625F;
        float f20 = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j - 1, k, 0))
        {
            float f21 = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k);
            tessellator.setColorOpaque_F(f7 * f21, f11 * f21, f15 * f21);
            func_1244_a(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 0));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j + 1, k, 1))
        {
            float f22 = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k);
            if(block.maxY != 1.0D && !block.blockMaterial.getIsGroundCover())
            {
                f22 = f20;
            }
            tessellator.setColorOpaque_F(f8 * f22, f12 * f22, f16 * f22);
            func_1217_b(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 1));
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j, k - 1, 2))
        {
            float f23 = block.getBlockBrightness(renderIBlockAccess, i, j, k - 1);
            if(block.minZ > 0.0D)
            {
                f23 = f20;
            }
            tessellator.setColorOpaque_F(f9 * f23, f13 * f23, f17 * f23);
            tessellator.setTranslationF(0.0F, 0.0F, f19);
            func_1220_c(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 2));
            tessellator.setTranslationF(0.0F, 0.0F, -f19);
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i, j, k + 1, 3))
        {
            float f24 = block.getBlockBrightness(renderIBlockAccess, i, j, k + 1);
            if(block.maxZ < 1.0D)
            {
                f24 = f20;
            }
            tessellator.setColorOpaque_F(f9 * f24, f13 * f24, f17 * f24);
            tessellator.setTranslationF(0.0F, 0.0F, -f19);
            func_1225_d(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 3));
            tessellator.setTranslationF(0.0F, 0.0F, f19);
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i - 1, j, k, 4))
        {
            float f25 = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k);
            if(block.minX > 0.0D)
            {
                f25 = f20;
            }
            tessellator.setColorOpaque_F(f10 * f25, f14 * f25, f18 * f25);
            tessellator.setTranslationF(f19, 0.0F, 0.0F);
            func_1231_e(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 4));
            tessellator.setTranslationF(-f19, 0.0F, 0.0F);
            flag = true;
        }
        if(renderAllFaces || block.shouldSideBeRendered(renderIBlockAccess, i + 1, j, k, 5))
        {
            float f26 = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k);
            if(block.maxX < 1.0D)
            {
                f26 = f20;
            }
            tessellator.setColorOpaque_F(f10 * f26, f14 * f26, f18 * f26);
            tessellator.setTranslationF(-f19, 0.0F, 0.0F);
            func_1236_f(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 5));
            tessellator.setTranslationF(f19, 0.0F, 0.0F);
            flag = true;
        }
        return flag;
    }

    public boolean renderPressurePlate(Block block, int i, int j, int k)
    {
        boolean flag = false;
        float f = 0.375F;
        float f1 = 0.625F;
        block.setBlockBounds(f, 0.0F, f, f1, 1.0F, f1);
        renderBlock(block, i, j, k);
        
        boolean blockNorth = false;
        boolean blockEast = false;
        boolean blockSouth = false;
        boolean blockWest = false;
        		
        if(Block.allBlocks[renderIBlockAccess.getBlockId(i - 1, j, k)] != null){
	        if(Block.allBlocks[renderIBlockAccess.getBlockId(i - 1, j, k)].isOpaqueCube() || Block.allBlocks[renderIBlockAccess.getBlockId(i - 1, j, k)] == block){
	        	blockSouth = true;
	        }
        }
        
        if(Block.allBlocks[renderIBlockAccess.getBlockId(i + 1, j, k)] != null){
	        if(Block.allBlocks[renderIBlockAccess.getBlockId(i + 1, j, k)].isOpaqueCube() || Block.allBlocks[renderIBlockAccess.getBlockId(i + 1, j, k)] == block){
	        	blockNorth = true;
	        }
        }
        
        if(Block.allBlocks[renderIBlockAccess.getBlockId(i, j, k - 1)] != null){
	        if(Block.allBlocks[renderIBlockAccess.getBlockId(i, j, k - 1)].isOpaqueCube() || Block.allBlocks[renderIBlockAccess.getBlockId(i, j, k - 1)] == block){
	        	blockEast = true;
	        }
        }
        
        if(Block.allBlocks[renderIBlockAccess.getBlockId(i, j, k + 1)] != null){
	        if(Block.allBlocks[renderIBlockAccess.getBlockId(i, j, k + 1)].isOpaqueCube() || Block.allBlocks[renderIBlockAccess.getBlockId(i, j, k + 1)] == block){
	        	blockWest = true;
	        }
        }
        
        boolean flag1 = blockNorth || blockSouth;//renderIBlockAccess.getBlock(i - 1, j, k) != 0 || renderIBlockAccess.getBlock(i + 1, j, k) != 0;
        boolean flag2 = blockEast || blockWest;//renderIBlockAccess.getBlock(i, j, k - 1) != 0 || renderIBlockAccess.getBlock(i, j, k + 1) != 0;

        
        boolean flag3 = blockSouth;//renderIBlockAccess.getBlock(i - 1, j, k) != 0;
        boolean flag4 = blockNorth;//renderIBlockAccess.getBlock(i + 1, j, k) != 0;
        boolean flag5 = blockEast;//renderIBlockAccess.getBlock(i, j, k - 1) != 0;
        boolean flag6 = blockWest;//renderIBlockAccess.getBlock(i, j, k + 1) != 0;
        if(!flag1 && !flag2)
        {
            flag1 = true;
        }
        f = 0.4375F;
        f1 = 0.5625F;
        float f2 = 0.75F;
        float f3 = 0.9375F;
        float f4 = flag3 ? 0.0F : f;
        float f5 = flag4 ? 1.0F : f1;
        float f6 = flag5 ? 0.0F : f;
        float f7 = flag6 ? 1.0F : f1;
        if(flag1)
        {
            block.setBlockBounds(f4, f2, f, f5, f3, f1);
            renderBlock(block, i, j, k);
        }
        if(flag2)
        {
            block.setBlockBounds(f, f2, f6, f1, f3, f7);
            renderBlock(block, i, j, k);
        }
        f2 = 0.375F;
        f3 = 0.5625F;
        if(flag1)
        {
            block.setBlockBounds(f4, f2, f, f5, f3, f1);
            renderBlock(block, i, j, k);
        }
        if(flag2)
        {
            block.setBlockBounds(f, f2, f6, f1, f3, f7);
            renderBlock(block, i, j, k);
        }
        block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        return flag;
    }

    public boolean renderStairs(Block block, int i, int j, int k)
    {
        boolean flag = false;
        int l = renderIBlockAccess.getBlockMetadata(i, j, k);
        if(l == 0)
        {
            block.setBlockBounds(0.0F, 0.0F, 0.0F, 0.5F, 0.5F, 1.0F);
            renderBlock(block, i, j, k);
            block.setBlockBounds(0.5F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            renderBlock(block, i, j, k);
        } else
        if(l == 1)
        {
            block.setBlockBounds(0.0F, 0.0F, 0.0F, 0.5F, 1.0F, 1.0F);
            renderBlock(block, i, j, k);
            block.setBlockBounds(0.5F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
            renderBlock(block, i, j, k);
        } else
        if(l == 2)
        {
            block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 0.5F);
            renderBlock(block, i, j, k);
            block.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 1.0F, 1.0F);
            renderBlock(block, i, j, k);
        } else
        if(l == 3)
        {
            block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.5F);
            renderBlock(block, i, j, k);
            block.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 0.5F, 1.0F);
            renderBlock(block, i, j, k);
        }
        block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        return flag;
    }

    public boolean renderDoor(Block block, int i, int j, int k)
    {
        Tessellator tessellator = Tessellator.instance;
        BlockDoor blockdoor = (BlockDoor)block;
        boolean flag = false;
        float f = 0.5F;
        float f1 = 1.0F;
        float f2 = 0.8F;
        float f3 = 0.6F;
        float f4 = block.getBlockBrightness(renderIBlockAccess, i, j, k);
        float f5 = block.getBlockBrightness(renderIBlockAccess, i, j - 1, k);
        if(blockdoor.minY > 0.0D)
        {
            f5 = f4;
        }
        if(Block.lightValue[block.blockID] > 0)
        {
            f5 = 1.0F;
        }
        tessellator.setColorOpaque_F(f * f5, f * f5, f * f5);
        func_1244_a(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 0));
        flag = true;
        f5 = block.getBlockBrightness(renderIBlockAccess, i, j + 1, k);
        if(blockdoor.maxY < 1.0D)
        {
            f5 = f4;
        }
        if(Block.lightValue[block.blockID] > 0)
        {
            f5 = 1.0F;
        }
        tessellator.setColorOpaque_F(f1 * f5, f1 * f5, f1 * f5);
        func_1217_b(block, i, j, k, block.getTextureIndex(renderIBlockAccess, i, j, k, 1));
        flag = true;
        f5 = block.getBlockBrightness(renderIBlockAccess, i, j, k - 1);
        if(blockdoor.minZ > 0.0D)
        {
            f5 = f4;
        }
        if(Block.lightValue[block.blockID] > 0)
        {
            f5 = 1.0F;
        }
        tessellator.setColorOpaque_F(f2 * f5, f2 * f5, f2 * f5);
        int l = block.getTextureIndex(renderIBlockAccess, i, j, k, 2);
        if(l < 0)
        {
            flipTexture = true;
            l = -l;
        }
        func_1220_c(block, i, j, k, l);
        flag = true;
        flipTexture = false;
        f5 = block.getBlockBrightness(renderIBlockAccess, i, j, k + 1);
        if(blockdoor.maxZ < 1.0D)
        {
            f5 = f4;
        }
        if(Block.lightValue[block.blockID] > 0)
        {
            f5 = 1.0F;
        }
        tessellator.setColorOpaque_F(f2 * f5, f2 * f5, f2 * f5);
        l = block.getTextureIndex(renderIBlockAccess, i, j, k, 3);
        if(l < 0)
        {
            flipTexture = true;
            l = -l;
        }
        func_1225_d(block, i, j, k, l);
        flag = true;
        flipTexture = false;
        f5 = block.getBlockBrightness(renderIBlockAccess, i - 1, j, k);
        if(blockdoor.minX > 0.0D)
        {
            f5 = f4;
        }
        if(Block.lightValue[block.blockID] > 0)
        {
            f5 = 1.0F;
        }
        tessellator.setColorOpaque_F(f3 * f5, f3 * f5, f3 * f5);
        l = block.getTextureIndex(renderIBlockAccess, i, j, k, 4);
        if(l < 0)
        {
            flipTexture = true;
            l = -l;
        }
        func_1231_e(block, i, j, k, l);
        flag = true;
        flipTexture = false;
        f5 = block.getBlockBrightness(renderIBlockAccess, i + 1, j, k);
        if(blockdoor.maxX < 1.0D)
        {
            f5 = f4;
        }
        if(Block.lightValue[block.blockID] > 0)
        {
            f5 = 1.0F;
        }
        tessellator.setColorOpaque_F(f3 * f5, f3 * f5, f3 * f5);
        l = block.getTextureIndex(renderIBlockAccess, i, j, k, 5);
        if(l < 0)
        {
            flipTexture = true;
            l = -l;
        }
        func_1236_f(block, i, j, k, l);
        flag = true;
        flipTexture = false;
        return flag;
    }

    public void func_1244_a(Block block, double d, double d1, double d2, 
            int i)
    {
        Tessellator tessellator = Tessellator.instance;
        if(overrideBlockTexture >= 0)
        {
            i = overrideBlockTexture;
        }
        int j = (i & 0xf) << 4;
        int k = i & 0xf0;
        double d3 = ((double)j + block.minX * 16D) / 256D;
        double d4 = (((double)j + block.maxX * 16D) - 0.01D) / 256D;
        double d5 = ((double)k + block.minZ * 16D) / 256D;
        double d6 = (((double)k + block.maxZ * 16D) - 0.01D) / 256D;
        if(block.minX < 0.0D || block.maxX > 1.0D)
        {
            d3 = ((float)j + 0.0F) / 256F;
            d4 = ((float)j + 15.99F) / 256F;
        }
        if(block.minZ < 0.0D || block.maxZ > 1.0D)
        {
            d5 = ((float)k + 0.0F) / 256F;
            d6 = ((float)k + 15.99F) / 256F;
        }
        double d7 = d4;
        double d8 = d3;
        double d9 = d5;
        double d10 = d6;
        if(field_31082_l == 2)
        {
            d3 = ((double)j + block.minZ * 16D) / 256D;
            d5 = ((double)(k + 16) - block.maxX * 16D) / 256D;
            d4 = ((double)j + block.maxZ * 16D) / 256D;
            d6 = ((double)(k + 16) - block.minX * 16D) / 256D;
            d7 = d4;
            d8 = d3;
            d9 = d5;
            d10 = d6;
            d7 = d3;
            d8 = d4;
            d5 = d6;
            d6 = d9;
        } else
        if(field_31082_l == 1)
        {
            d3 = ((double)(j + 16) - block.maxZ * 16D) / 256D;
            d5 = ((double)k + block.minX * 16D) / 256D;
            d4 = ((double)(j + 16) - block.minZ * 16D) / 256D;
            d6 = ((double)k + block.maxX * 16D) / 256D;
            d7 = d4;
            d8 = d3;
            d9 = d5;
            d10 = d6;
            d3 = d7;
            d4 = d8;
            d9 = d6;
            d10 = d5;
        } else
        if(field_31082_l == 3)
        {
            d3 = ((double)(j + 16) - block.minX * 16D) / 256D;
            d4 = ((double)(j + 16) - block.maxX * 16D - 0.01D) / 256D;
            d5 = ((double)(k + 16) - block.minZ * 16D) / 256D;
            d6 = ((double)(k + 16) - block.maxZ * 16D - 0.01D) / 256D;
            d7 = d4;
            d8 = d3;
            d9 = d5;
            d10 = d6;
        }
        double d11 = d + block.minX;
        double d12 = d + block.maxX;
        double d13 = d1 + block.minY;
        double d14 = d2 + block.minZ;
        double d15 = d2 + block.maxZ;
        if(enableAO)
        {
            tessellator.setColorOpaque_F(colorRedTopLeft, colorGreenTopLeft, colorBlueTopLeft);
            tessellator.addVertexWithUV(d11, d13, d15, d8, d10);
            tessellator.setColorOpaque_F(colorRedBottomLeft, colorGreenBottomLeft, colorBlueBottomLeft);
            tessellator.addVertexWithUV(d11, d13, d14, d3, d5);
            tessellator.setColorOpaque_F(colorRedBottomRight, colorGreenBottomRight, colorBlueBottomRight);
            tessellator.addVertexWithUV(d12, d13, d14, d7, d9);
            tessellator.setColorOpaque_F(colorRedTopRight, colorGreenTopRight, colorBlueTopRight);
            tessellator.addVertexWithUV(d12, d13, d15, d4, d6);
        } else
        {
            tessellator.addVertexWithUV(d11, d13, d15, d8, d10);
            tessellator.addVertexWithUV(d11, d13, d14, d3, d5);
            tessellator.addVertexWithUV(d12, d13, d14, d7, d9);
            tessellator.addVertexWithUV(d12, d13, d15, d4, d6);
        }
    }

    public void func_1217_b(Block block, double d, double d1, double d2, 
            int i)
    {
        Tessellator tessellator = Tessellator.instance;
        if(overrideBlockTexture >= 0)
        {
            i = overrideBlockTexture;
        }
        int j = (i & 0xf) << 4;
        int k = i & 0xf0;
        double d3 = ((double)j + block.minX * 16D) / 256D;
        double d4 = (((double)j + block.maxX * 16D) - 0.01D) / 256D;
        double d5 = ((double)k + block.minZ * 16D) / 256D;
        double d6 = (((double)k + block.maxZ * 16D) - 0.01D) / 256D;
        if(block.minX < 0.0D || block.maxX > 1.0D)
        {
            d3 = ((float)j + 0.0F) / 256F;
            d4 = ((float)j + 15.99F) / 256F;
        }
        if(block.minZ < 0.0D || block.maxZ > 1.0D)
        {
            d5 = ((float)k + 0.0F) / 256F;
            d6 = ((float)k + 15.99F) / 256F;
        }
        double d7 = d4;
        double d8 = d3;
        double d9 = d5;
        double d10 = d6;
        if(field_31083_k == 1)
        {
            d3 = ((double)j + block.minZ * 16D) / 256D;
            d5 = ((double)(k + 16) - block.maxX * 16D) / 256D;
            d4 = ((double)j + block.maxZ * 16D) / 256D;
            d6 = ((double)(k + 16) - block.minX * 16D) / 256D;
            d7 = d4;
            d8 = d3;
            d9 = d5;
            d10 = d6;
            d7 = d3;
            d8 = d4;
            d5 = d6;
            d6 = d9;
        } else
        if(field_31083_k == 2)
        {
            d3 = ((double)(j + 16) - block.maxZ * 16D) / 256D;
            d5 = ((double)k + block.minX * 16D) / 256D;
            d4 = ((double)(j + 16) - block.minZ * 16D) / 256D;
            d6 = ((double)k + block.maxX * 16D) / 256D;
            d7 = d4;
            d8 = d3;
            d9 = d5;
            d10 = d6;
            d3 = d7;
            d4 = d8;
            d9 = d6;
            d10 = d5;
        } else
        if(field_31083_k == 3)
        {
            d3 = ((double)(j + 16) - block.minX * 16D) / 256D;
            d4 = ((double)(j + 16) - block.maxX * 16D - 0.01D) / 256D;
            d5 = ((double)(k + 16) - block.minZ * 16D) / 256D;
            d6 = ((double)(k + 16) - block.maxZ * 16D - 0.01D) / 256D;
            d7 = d4;
            d8 = d3;
            d9 = d5;
            d10 = d6;
        }
        double d11 = d + block.minX;
        double d12 = d + block.maxX;
        double d13 = d1 + block.maxY;
        double d14 = d2 + block.minZ;
        double d15 = d2 + block.maxZ;
        if(enableAO)
        {
            tessellator.setColorOpaque_F(colorRedTopLeft, colorGreenTopLeft, colorBlueTopLeft);
            tessellator.addVertexWithUV(d12, d13, d15, d4, d6);
            tessellator.setColorOpaque_F(colorRedBottomLeft, colorGreenBottomLeft, colorBlueBottomLeft);
            tessellator.addVertexWithUV(d12, d13, d14, d7, d9);
            tessellator.setColorOpaque_F(colorRedBottomRight, colorGreenBottomRight, colorBlueBottomRight);
            tessellator.addVertexWithUV(d11, d13, d14, d3, d5);
            tessellator.setColorOpaque_F(colorRedTopRight, colorGreenTopRight, colorBlueTopRight);
            tessellator.addVertexWithUV(d11, d13, d15, d8, d10);
        } else
        {
            tessellator.addVertexWithUV(d12, d13, d15, d4, d6);
            tessellator.addVertexWithUV(d12, d13, d14, d7, d9);
            tessellator.addVertexWithUV(d11, d13, d14, d3, d5);
            tessellator.addVertexWithUV(d11, d13, d15, d8, d10);
        }
    }

    public void func_1220_c(Block block, double d, double d1, double d2, 
            int i)
    {
        Tessellator tessellator = Tessellator.instance;
        if(overrideBlockTexture >= 0)
        {
            i = overrideBlockTexture;
        }
        int j = (i & 0xf) << 4;
        int k = i & 0xf0;
        double d3 = ((double)j + block.minX * 16D) / 256D;
        double d4 = (((double)j + block.maxX * 16D) - 0.01D) / 256D;
        double d5 = ((double)(k + 16) - block.maxY * 16D) / 256D;
        double d6 = ((double)(k + 16) - block.minY * 16D - 0.01D) / 256D;
        if(flipTexture)
        {
            double d7 = d3;
            d3 = d4;
            d4 = d7;
        }
        if(block.minX < 0.0D || block.maxX > 1.0D)
        {
            d3 = ((float)j + 0.0F) / 256F;
            d4 = ((float)j + 15.99F) / 256F;
        }
        if(block.minY < 0.0D || block.maxY > 1.0D)
        {
            d5 = ((float)k + 0.0F) / 256F;
            d6 = ((float)k + 15.99F) / 256F;
        }
        double d8 = d4;
        double d9 = d3;
        double d10 = d5;
        double d11 = d6;
        if(field_31087_g == 2)
        {
            d3 = ((double)j + block.minY * 16D) / 256D;
            d5 = ((double)(k + 16) - block.minX * 16D) / 256D;
            d4 = ((double)j + block.maxY * 16D) / 256D;
            d6 = ((double)(k + 16) - block.maxX * 16D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
            d8 = d3;
            d9 = d4;
            d5 = d6;
            d6 = d10;
        } else
        if(field_31087_g == 1)
        {
            d3 = ((double)(j + 16) - block.maxY * 16D) / 256D;
            d5 = ((double)k + block.maxX * 16D) / 256D;
            d4 = ((double)(j + 16) - block.minY * 16D) / 256D;
            d6 = ((double)k + block.minX * 16D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
            d3 = d8;
            d4 = d9;
            d10 = d6;
            d11 = d5;
        } else
        if(field_31087_g == 3)
        {
            d3 = ((double)(j + 16) - block.minX * 16D) / 256D;
            d4 = ((double)(j + 16) - block.maxX * 16D - 0.01D) / 256D;
            d5 = ((double)k + block.maxY * 16D) / 256D;
            d6 = (((double)k + block.minY * 16D) - 0.01D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
        }
        double d12 = d + block.minX;
        double d13 = d + block.maxX;
        double d14 = d1 + block.minY;
        double d15 = d1 + block.maxY;
        double d16 = d2 + block.minZ;
        if(enableAO)
        {
            tessellator.setColorOpaque_F(colorRedTopLeft, colorGreenTopLeft, colorBlueTopLeft);
            tessellator.addVertexWithUV(d12, d15, d16, d8, d10);
            tessellator.setColorOpaque_F(colorRedBottomLeft, colorGreenBottomLeft, colorBlueBottomLeft);
            tessellator.addVertexWithUV(d13, d15, d16, d3, d5);
            tessellator.setColorOpaque_F(colorRedBottomRight, colorGreenBottomRight, colorBlueBottomRight);
            tessellator.addVertexWithUV(d13, d14, d16, d9, d11);
            tessellator.setColorOpaque_F(colorRedTopRight, colorGreenTopRight, colorBlueTopRight);
            tessellator.addVertexWithUV(d12, d14, d16, d4, d6);
        } else
        {
            tessellator.addVertexWithUV(d12, d15, d16, d8, d10);
            tessellator.addVertexWithUV(d13, d15, d16, d3, d5);
            tessellator.addVertexWithUV(d13, d14, d16, d9, d11);
            tessellator.addVertexWithUV(d12, d14, d16, d4, d6);
        }
    }

    public void func_1225_d(Block block, double d, double d1, double d2, int i)
    {
        Tessellator tessellator = Tessellator.instance;
        if(overrideBlockTexture >= 0)
        {
            i = overrideBlockTexture;
        }
        int j = (i & 0xf) << 4;
        int k = i & 0xf0;
        double d3 = ((double)j + block.minX * 16D) / 256D;
        double d4 = (((double)j + block.maxX * 16D) - 0.01D) / 256D;
        double d5 = ((double)(k + 16) - block.maxY * 16D) / 256D;
        double d6 = ((double)(k + 16) - block.minY * 16D - 0.01D) / 256D;
        if(flipTexture)
        {
            double d7 = d3;
            d3 = d4;
            d4 = d7;
        }
        if(block.minX < 0.0D || block.maxX > 1.0D)
        {
            d3 = ((float)j + 0.0F) / 256F;
            d4 = ((float)j + 15.99F) / 256F;
        }
        if(block.minY < 0.0D || block.maxY > 1.0D)
        {
            d5 = ((float)k + 0.0F) / 256F;
            d6 = ((float)k + 15.99F) / 256F;
        }
        double d8 = d4;
        double d9 = d3;
        double d10 = d5;
        double d11 = d6;
        if(field_31086_h == 1)
        {
            d3 = ((double)j + block.minY * 16D) / 256D;
            d6 = ((double)(k + 16) - block.minX * 16D) / 256D;
            d4 = ((double)j + block.maxY * 16D) / 256D;
            d5 = ((double)(k + 16) - block.maxX * 16D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
            d8 = d3;
            d9 = d4;
            d5 = d6;
            d6 = d10;
        } else
        if(field_31086_h == 2)
        {
            d3 = ((double)(j + 16) - block.maxY * 16D) / 256D;
            d5 = ((double)k + block.minX * 16D) / 256D;
            d4 = ((double)(j + 16) - block.minY * 16D) / 256D;
            d6 = ((double)k + block.maxX * 16D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
            d3 = d8;
            d4 = d9;
            d10 = d6;
            d11 = d5;
        } else
        if(field_31086_h == 3)
        {
            d3 = ((double)(j + 16) - block.minX * 16D) / 256D;
            d4 = ((double)(j + 16) - block.maxX * 16D - 0.01D) / 256D;
            d5 = ((double)k + block.maxY * 16D) / 256D;
            d6 = (((double)k + block.minY * 16D) - 0.01D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
        }
        double d12 = d + block.minX;
        double d13 = d + block.maxX;
        double d14 = d1 + block.minY;
        double d15 = d1 + block.maxY;
        double d16 = d2 + block.maxZ;
        if(enableAO)
        {
            tessellator.setColorOpaque_F(colorRedTopLeft, colorGreenTopLeft, colorBlueTopLeft);
            tessellator.addVertexWithUV(d12, d15, d16, d3, d5);
            tessellator.setColorOpaque_F(colorRedBottomLeft, colorGreenBottomLeft, colorBlueBottomLeft);
            tessellator.addVertexWithUV(d12, d14, d16, d9, d11);
            tessellator.setColorOpaque_F(colorRedBottomRight, colorGreenBottomRight, colorBlueBottomRight);
            tessellator.addVertexWithUV(d13, d14, d16, d4, d6);
            tessellator.setColorOpaque_F(colorRedTopRight, colorGreenTopRight, colorBlueTopRight);
            tessellator.addVertexWithUV(d13, d15, d16, d8, d10);
        } else
        {
            tessellator.addVertexWithUV(d12, d15, d16, d3, d5);
            tessellator.addVertexWithUV(d12, d14, d16, d9, d11);
            tessellator.addVertexWithUV(d13, d14, d16, d4, d6);
            tessellator.addVertexWithUV(d13, d15, d16, d8, d10);
        }
    }

    public void func_1231_e(Block block, double d, double d1, double d2, int i)
    {
        Tessellator tessellator = Tessellator.instance;
        if(overrideBlockTexture >= 0)
        {
            i = overrideBlockTexture;
        }
        int j = (i & 0xf) << 4;
        int k = i & 0xf0;
        double d3 = ((double)j + block.minZ * 16D) / 256D;
        double d4 = (((double)j + block.maxZ * 16D) - 0.01D) / 256D;
        double d5 = ((double)(k + 16) - block.maxY * 16D) / 256D;
        double d6 = ((double)(k + 16) - block.minY * 16D - 0.01D) / 256D;
        if(flipTexture)
        {
            double d7 = d3;
            d3 = d4;
            d4 = d7;
        }
        if(block.minZ < 0.0D || block.maxZ > 1.0D)
        {
            d3 = ((float)j + 0.0F) / 256F;
            d4 = ((float)j + 15.99F) / 256F;
        }
        if(block.minY < 0.0D || block.maxY > 1.0D)
        {
            d5 = ((float)k + 0.0F) / 256F;
            d6 = ((float)k + 15.99F) / 256F;
        }
        double d8 = d4;
        double d9 = d3;
        double d10 = d5;
        double d11 = d6;
        if(field_31084_j == 1)
        {
            d3 = ((double)j + block.minY * 16D) / 256D;
            d5 = ((double)(k + 16) - block.maxZ * 16D) / 256D;
            d4 = ((double)j + block.maxY * 16D) / 256D;
            d6 = ((double)(k + 16) - block.minZ * 16D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
            d8 = d3;
            d9 = d4;
            d5 = d6;
            d6 = d10;
        } else
        if(field_31084_j == 2)
        {
            d3 = ((double)(j + 16) - block.maxY * 16D) / 256D;
            d5 = ((double)k + block.minZ * 16D) / 256D;
            d4 = ((double)(j + 16) - block.minY * 16D) / 256D;
            d6 = ((double)k + block.maxZ * 16D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
            d3 = d8;
            d4 = d9;
            d10 = d6;
            d11 = d5;
        } else
        if(field_31084_j == 3)
        {
            d3 = ((double)(j + 16) - block.minZ * 16D) / 256D;
            d4 = ((double)(j + 16) - block.maxZ * 16D - 0.01D) / 256D;
            d5 = ((double)k + block.maxY * 16D) / 256D;
            d6 = (((double)k + block.minY * 16D) - 0.01D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
        }
        double d12 = d + block.minX;
        double d13 = d1 + block.minY;
        double d14 = d1 + block.maxY;
        double d15 = d2 + block.minZ;
        double d16 = d2 + block.maxZ;
        if(enableAO)
        {
            tessellator.setColorOpaque_F(colorRedTopLeft, colorGreenTopLeft, colorBlueTopLeft);
            tessellator.addVertexWithUV(d12, d14, d16, d8, d10);
            tessellator.setColorOpaque_F(colorRedBottomLeft, colorGreenBottomLeft, colorBlueBottomLeft);
            tessellator.addVertexWithUV(d12, d14, d15, d3, d5);
            tessellator.setColorOpaque_F(colorRedBottomRight, colorGreenBottomRight, colorBlueBottomRight);
            tessellator.addVertexWithUV(d12, d13, d15, d9, d11);
            tessellator.setColorOpaque_F(colorRedTopRight, colorGreenTopRight, colorBlueTopRight);
            tessellator.addVertexWithUV(d12, d13, d16, d4, d6);
        } else
        {
            tessellator.addVertexWithUV(d12, d14, d16, d8, d10);
            tessellator.addVertexWithUV(d12, d14, d15, d3, d5);
            tessellator.addVertexWithUV(d12, d13, d15, d9, d11);
            tessellator.addVertexWithUV(d12, d13, d16, d4, d6);
        }
    }

    public void func_1236_f(Block block, double d, double d1, double d2, int i)
    {
        Tessellator tessellator = Tessellator.instance;
        if(overrideBlockTexture >= 0)
        {
            i = overrideBlockTexture;
        }
        int j = (i & 0xf) << 4;
        int k = i & 0xf0;
        double d3 = ((double)j + block.minZ * 16D) / 256D;
        double d4 = (((double)j + block.maxZ * 16D) - 0.01D) / 256D;
        double d5 = ((double)(k + 16) - block.maxY * 16D) / 256D;
        double d6 = ((double)(k + 16) - block.minY * 16D - 0.01D) / 256D;
        if(flipTexture)
        {
            double d7 = d3;
            d3 = d4;
            d4 = d7;
        }
        if(block.minZ < 0.0D || block.maxZ > 1.0D)
        {
            d3 = ((float)j + 0.0F) / 256F;
            d4 = ((float)j + 15.99F) / 256F;
        }
        if(block.minY < 0.0D || block.maxY > 1.0D)
        {
            d5 = ((float)k + 0.0F) / 256F;
            d6 = ((float)k + 15.99F) / 256F;
        }
        double d8 = d4;
        double d9 = d3;
        double d10 = d5;
        double d11 = d6;
        if(field_31085_i == 2)
        {
            d3 = ((double)j + block.minY * 16D) / 256D;
            d5 = ((double)(k + 16) - block.minZ * 16D) / 256D;
            d4 = ((double)j + block.maxY * 16D) / 256D;
            d6 = ((double)(k + 16) - block.maxZ * 16D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
            d8 = d3;
            d9 = d4;
            d5 = d6;
            d6 = d10;
        } else
        if(field_31085_i == 1)
        {
            d3 = ((double)(j + 16) - block.maxY * 16D) / 256D;
            d5 = ((double)k + block.maxZ * 16D) / 256D;
            d4 = ((double)(j + 16) - block.minY * 16D) / 256D;
            d6 = ((double)k + block.minZ * 16D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
            d3 = d8;
            d4 = d9;
            d10 = d6;
            d11 = d5;
        } else
        if(field_31085_i == 3)
        {
            d3 = ((double)(j + 16) - block.minZ * 16D) / 256D;
            d4 = ((double)(j + 16) - block.maxZ * 16D - 0.01D) / 256D;
            d5 = ((double)k + block.maxY * 16D) / 256D;
            d6 = (((double)k + block.minY * 16D) - 0.01D) / 256D;
            d8 = d4;
            d9 = d3;
            d10 = d5;
            d11 = d6;
        }
        double d12 = d + block.maxX;
        double d13 = d1 + block.minY;
        double d14 = d1 + block.maxY;
        double d15 = d2 + block.minZ;
        double d16 = d2 + block.maxZ;
        if(enableAO)
        {
            tessellator.setColorOpaque_F(colorRedTopLeft, colorGreenTopLeft, colorBlueTopLeft);
            tessellator.addVertexWithUV(d12, d13, d16, d9, d11);
            tessellator.setColorOpaque_F(colorRedBottomLeft, colorGreenBottomLeft, colorBlueBottomLeft);
            tessellator.addVertexWithUV(d12, d13, d15, d4, d6);
            tessellator.setColorOpaque_F(colorRedBottomRight, colorGreenBottomRight, colorBlueBottomRight);
            tessellator.addVertexWithUV(d12, d14, d15, d8, d10);
            tessellator.setColorOpaque_F(colorRedTopRight, colorGreenTopRight, colorBlueTopRight);
            tessellator.addVertexWithUV(d12, d14, d16, d3, d5);
        } else
        {
            tessellator.addVertexWithUV(d12, d13, d16, d9, d11);
            tessellator.addVertexWithUV(d12, d13, d15, d4, d6);
            tessellator.addVertexWithUV(d12, d14, d15, d8, d10);
            tessellator.addVertexWithUV(d12, d14, d16, d3, d5);
        }
    }

    public void renderHeldItems(Block block, float f)
    {
        int i = block.getRenderType();
        Tessellator tessellator = Tessellator.instance;
        if(i == 0 || i == 4)
        {
            block.setBlockBoundsForItemRender();
            GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
            float f1 = 0.5F;
            float f2 = 1.0F;
            float f3 = 0.8F;
            float f4 = 0.6F;
            tessellator.startDrawingQuads();
            tessellator.setColorRGBA_F(f2, f2, f2, f);
            func_1244_a(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(0));
            tessellator.setColorRGBA_F(f1, f1, f1, f);
            func_1217_b(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(1));
            tessellator.setColorRGBA_F(f3, f3, f3, f);
            func_1220_c(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(2));
            func_1225_d(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(3));
            tessellator.setColorRGBA_F(f4, f4, f4, f);
            func_1231_e(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(4));
            func_1236_f(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(5));
            tessellator.draw();
            GL11.glTranslatef(0.5F, 0.5F, 0.5F);
        }
    }

    public void renderThrownItems(Block block)
    {
        byte byte0 = -1;
        Tessellator tessellator = Tessellator.instance;
        int i = block.getRenderType();
        if(i == 0 || i == 4)
        {
            block.setBlockBoundsForItemRender();
            GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, -1F, 0.0F);
            func_1244_a(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(0));
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 1.0F, 0.0F);
            func_1217_b(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(1));
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 0.0F, -1F);
            func_1220_c(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(2));
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 0.0F, 1.0F);
            func_1225_d(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(3));
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(-1F, 0.0F, 0.0F);
            func_1231_e(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(4));
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(1.0F, 0.0F, 0.0F);
            func_1236_f(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(5));
            tessellator.draw();
            GL11.glTranslatef(0.5F, 0.5F, 0.5F);
        } else
        if(i == 1)
        {
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, -1F, 0.0F);
            renderCrossedSquares(block, byte0, -0.5D, -0.5D, -0.5D);
            tessellator.draw();
        } else
        if(i == 13)
        {
            block.setBlockBoundsForItemRender();
            GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
            float f = 0.0625F;
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, -1F, 0.0F);
            func_1244_a(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(0));
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 1.0F, 0.0F);
            func_1217_b(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(1));
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 0.0F, -1F);
            tessellator.setTranslationF(0.0F, 0.0F, f);
            func_1220_c(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(2));
            tessellator.setTranslationF(0.0F, 0.0F, -f);
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 0.0F, 1.0F);
            tessellator.setTranslationF(0.0F, 0.0F, -f);
            func_1225_d(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(3));
            tessellator.setTranslationF(0.0F, 0.0F, f);
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(-1F, 0.0F, 0.0F);
            tessellator.setTranslationF(f, 0.0F, 0.0F);
            func_1231_e(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(4));
            tessellator.setTranslationF(-f, 0.0F, 0.0F);
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(1.0F, 0.0F, 0.0F);
            tessellator.setTranslationF(-f, 0.0F, 0.0F);
            func_1236_f(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(5));
            tessellator.setTranslationF(f, 0.0F, 0.0F);
            tessellator.draw();
            GL11.glTranslatef(0.5F, 0.5F, 0.5F);
        } else
        if(i == 6)
        {
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, -1F, 0.0F);
            func_1245_b(block, byte0, -0.5D, -0.5D, -0.5D);
            tessellator.draw();
        } else
        if(i == 2)
        {
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, -1F, 0.0F);
            func_1237_a(block, -0.5D, -0.5D, -0.5D, 0.0D, 0.0D);
            tessellator.draw();
        } else
        if(i == 10)
        {
            for(int j = 0; j < 2; j++)
            {
                if(j == 0)
                {
                    block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.5F);
                }
                if(j == 1)
                {
                    block.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 0.5F, 1.0F);
                }
                GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0F, -1F, 0.0F);
                func_1244_a(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(0));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0F, 1.0F, 0.0F);
                func_1217_b(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(1));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0F, 0.0F, -1F);
                func_1220_c(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(2));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0F, 0.0F, 1.0F);
                func_1225_d(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(3));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(-1F, 0.0F, 0.0F);
                func_1231_e(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(4));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(1.0F, 0.0F, 0.0F);
                func_1236_f(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(5));
                tessellator.draw();
                GL11.glTranslatef(0.5F, 0.5F, 0.5F);
            }

        } else
        if(i == 11)
        {
            for(int k = 0; k < 4; k++)
            {
                float f1 = 0.125F;
                if(k == 0)
                {
                    block.setBlockBounds(0.5F - f1, 0.0F, 0.0F, 0.5F + f1, 1.0F, f1 * 2.0F);
                }
                if(k == 1)
                {
                    block.setBlockBounds(0.5F - f1, 0.0F, 1.0F - f1 * 2.0F, 0.5F + f1, 1.0F, 1.0F);
                }
                f1 = 0.0625F;
                if(k == 2)
                {
                    block.setBlockBounds(0.5F - f1, 1.0F - f1 * 3F, -f1 * 2.0F, 0.5F + f1, 1.0F - f1, 1.0F + f1 * 2.0F);
                }
                if(k == 3)
                {
                    block.setBlockBounds(0.5F - f1, 0.5F - f1 * 3F, -f1 * 2.0F, 0.5F + f1, 0.5F - f1, 1.0F + f1 * 2.0F);
                }
                GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0F, -1F, 0.0F);
                func_1244_a(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(0));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0F, 1.0F, 0.0F);
                func_1217_b(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(1));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0F, 0.0F, -1F);
                func_1220_c(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(2));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0F, 0.0F, 1.0F);
                func_1225_d(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(3));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(-1F, 0.0F, 0.0F);
                func_1231_e(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(4));
                tessellator.draw();
                tessellator.startDrawingQuads();
                tessellator.setNormal(1.0F, 0.0F, 0.0F);
                func_1236_f(block, 0.0D, 0.0D, 0.0D, block.getTextureIndex(5));
                tessellator.draw();
                GL11.glTranslatef(0.5F, 0.5F, 0.5F);
            }

            block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
    }

    public static boolean getRenderItemType(int i)
    {
        if(i == 0)
        {
            return true;
        }
        if(i == 13)
        {
            return true;
        }
        if(i == 10)
        {
            return true;
        }
        if(i == 4)
        {
            return true;
        }
        return i == 11;
    }

    private IBlockAccess renderIBlockAccess;
    private int overrideBlockTexture;
    private boolean flipTexture;
    private boolean renderAllFaces;
    private boolean randomWater = false;
    
    public boolean field_31088_b;
    private int field_31087_g;
    private int field_31086_h;
    private int field_31085_i;
    private int field_31084_j;
    private int field_31083_k;
    private int field_31082_l;
    private boolean enableAO;
    private float aoLightValueXNeg;
    private float aoLightValueYNeg;
    private float aoLightValueZNeg;
    private float aoLightValueXPos;
    private float aoLightValueYPos;
    private float aoLightValueZPos;
    private float field_22377_m;
    private float field_22376_n;
    private float field_22375_o;
    private float field_22374_p;
    private float field_22373_q;
    private float field_22372_r;
    private float field_22371_s;
    private float field_22370_t;
    private float field_22369_u;
    private float field_22368_v;
    private float field_22367_w;
    private float field_22366_x;
    private float field_22365_y;
    private float field_22364_z;
    private float field_22362_A;
    private float field_22360_B;
    private float field_22358_C;
    private float field_22356_D;
    private float field_22354_E;
    private float field_22353_F;
    private int field_22352_G;
    private float colorRedTopLeft;
    private float colorRedBottomLeft;
    private float colorRedBottomRight;
    private float colorRedTopRight;
    private float colorGreenTopLeft;
    private float colorGreenBottomLeft;
    private float colorGreenBottomRight;
    private float colorGreenTopRight;
    private float colorBlueTopLeft;
    private float colorBlueBottomLeft;
    private float colorBlueBottomRight;
    private float colorBlueTopRight;
    private boolean field_22339_T;
    private boolean field_22338_U;
    private boolean field_22337_V;
    private boolean field_22336_W;
    private boolean field_22335_X;
    private boolean field_22334_Y;
    private boolean field_22333_Z;
    private boolean field_22363_aa;
    private boolean field_22361_ab;
    private boolean field_22359_ac;
    private boolean field_22357_ad;
    private boolean field_22355_ae;
}
