package com.mojang.minecraft.level.tile;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.util.ArrayList;
import java.util.Random;

import org.lwjgl.util.Color;

import com.mojang.minecraft.entity.Entity;
import com.mojang.minecraft.entity.EntityItem;
import com.mojang.minecraft.entity.EntityLiving;
import com.mojang.minecraft.entity.EntityPlayer;
import com.mojang.minecraft.entity.MovingObjectPosition;
import com.mojang.minecraft.entity.item.Item;
import com.mojang.minecraft.entity.item.ItemBlock;
import com.mojang.minecraft.entity.item.ItemStack;
import com.mojang.minecraft.entity.tile.IBlockAccess;
import com.mojang.minecraft.entity.tile.TileEntityGear;
import com.mojang.minecraft.entity.tile.TileEntitySign;
import com.mojang.minecraft.enums.EnumMobType;
import com.mojang.minecraft.level.World;
import com.mojang.minecraft.level.tile.material.Material;
import com.mojang.minecraft.level.tile.phys.AxisAlignedBB;
import com.mojang.minecraft.render.Vec3D;


public class Block
{
	//public Icon blockIcon;

    protected Block(int i, Material material1)
    {
        stepSound = soundPowderFootstep;
        field_357_bm = 1.0F;
        slipperiness = 0.6F;
        primaryColor = new Color(127, 127, 127, 0);
        secondaryColor = new Color(127, 127, 127, 0);
        if(allBlocks[i] != null)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Slot ").append(i).append(" is already occupied by ").append(allBlocks[i]).append(" when adding ").append(this).toString());
        } else
        {
            blockMaterial = material1;
            allBlocks[i] = this;
            blockID = i;
            setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            opaqueCubeLookup[i] = isOpaqueCube();
            lightOpacity[i] = isOpaqueCube() ? 255 : 0;
            field_340_s[i] = func_212_i();
            isBlockContainer[i] = false;
            return;
        }
    }

    protected Block(int i, int j, Material material1)
    {
        this(i, material1);
        blockIndexInTexture = j;
    }
    
    protected Block setColor(Color color){
    	primaryColor = color;
    	return this;
    }
    
    protected Block setColor(Color color, Color color2){
    	primaryColor = color;
    	secondaryColor = color2;
    	return this;    	
    }

    protected Block setStepSound(StepSound stepsound)
    {
        stepSound = stepsound;
        return this;
    }

    protected Block setLightOpacity(int i)
    {
        lightOpacity[blockID] = i;
        return this;
    }

    protected Block setLightValue(float f)
    {
        lightValue[blockID] = (int)(15F * f);
        return this;
    }

    protected Block setResistance(float f)
    {
        blockResistance = f * 3F;
        return this;
    }

    private boolean func_212_i()
    {
        return false;
    }

    public boolean renderAsNormalBlock()
    {
        return true;
    }

    public int getRenderType()
    {
        return 0;
    }

    protected Block setHardness(float f)
    {
        blockHardness = f;
        if(blockResistance < f * 5F)
        {
            blockResistance = f * 5F;
        }
        return this;
    }

    protected void setTickOnLoad(boolean flag)
    {
        tickOnLoad[blockID] = flag;
    }

    public void setBlockBounds(float f, float f1, float f2, float f3, float f4, float f5)
    {
        minX = f;
        minY = f1;
        minZ = f2;
        maxX = f3;
        maxY = f4;
        maxZ = f5;
    }

    public float getBlockBrightness(IBlockAccess iblockaccess, int i, int j, int k)
    {
    	if(iblockaccess.getMaterialXYZ(i, j, k) == Material.leaves)
    	{
			float brightness = iblockaccess.getBrightness(i, j, k);
			if(brightness > 0.2F)
			{
				brightness = 0.2F;
			}
			return brightness;
    	}
        return iblockaccess.getBrightness(i, j, k);
    }

    public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int x, int y, int z, int face)
    {
    	if(face == 1 && iblockaccess.getBlockId(x, y, z) == snow.blockID){
    		return false;
    	}
        if(face == 0 && minY > 0.0D)
        {
            return true;
        }
        if(face == 1 && maxY < 1.0D)
        {
            return true;
        }
        if(face == 2 && minZ > 0.0D)
        {
            return true;
        }
        if(face == 3 && maxZ < 1.0D)
        {
            return true;
        }
        if(face == 4 && minX > 0.0D)
        {
            return true;
        }
        if(face == 5 && maxX < 1.0D)
        {
            return true;
        } else
        {
            return !iblockaccess.isBlockNormalCube(x, y, z);
        }
    }

    public int getTextureIndex(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        return getBlockTextureFromSideAndMetadata(l, iblockaccess.getBlockMetadata(i, j, k));
    }

    public int getBlockTextureFromSideAndMetadata(int i, int j)
    {
        return getTextureIndex(i);
    }

    public int getTextureIndex(int i)
    {
        return blockIndexInTexture;
    }

    public AxisAlignedBB getSelectedCollisionBoundingBoxFromPool(World world, int i, int j, int k)
    {
        return AxisAlignedBB.getBoundingBoxFromPool((double)i + minX, (double)j + minY, (double)k + minZ, (double)i + maxX, (double)j + maxY, (double)k + maxZ);
    }

    public void getCollidingBoundingBoxes(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, ArrayList<AxisAlignedBB> arraylist)
    {
        AxisAlignedBB axisalignedbb1 = getCollisionBoundingBoxFromPool(world, i, j, k);
        if(axisalignedbb1 != null && axisalignedbb.intersectsWith(axisalignedbb1))
        {
            arraylist.add(axisalignedbb1);
        }
    }

    public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
    {
        return AxisAlignedBB.getBoundingBoxFromPool((double)i + minX, (double)j + minY, (double)k + minZ, (double)i + maxX, (double)j + maxY, (double)k + maxZ);
    }

    public boolean isOpaqueCube()
    {
        return true;
    }

    public boolean canCollideCheck(int i, boolean flag)
    {
        return isCollidable();
    }

    public boolean isCollidable()
    {
        return true;
    }

    public void updateTick(World world, int i, int j, int k, Random random)
    {
    }

    public void randomDisplayTick(World world, int i, int j, int k, Random random)
    {
    }

    public void dropBlockAsItemWithChance(World world, int i, int j, int k, int l)
    {
    }

    public void onNeighborBlockChange(World world, int i, int j, int k, int l)
    {
    }

    public int tickRate()
    {
        return 10;
    }

    public void onBlockAdded(World world, int i, int j, int k)
    {
    }

    public void onBlockRemoval(World world, int i, int j, int k)
    {
    }

    public int quantityDropped(Random random)
    {
        return 1;
    }

    public int idDropped(int i, Random random)
    {
        return blockID;
    }

    public float blockStrength(EntityPlayer entityplayer)
    {
        if(blockHardness < 0.0F)
        {
            return 0.0F;
        }
        if(!entityplayer.checkBreakBlock(this))
        {
            return 1.0F / blockHardness / 100F;
        } else
        {
            return entityplayer.getMiningInhibitors(this) / blockHardness / 30F;
        }
    }

    public void dropBlockAsItem(World world, int i, int j, int k, int l)
    {
        dropBlockAsItemWithChance(world, i, j, k, l, 1.0F);
    }

    public void dropBlockAsItemWithChance(World world, int i, int j, int k, int l, float f)
    {
        if(world.multiplayerWorld)
        {
            return;
        }
        int i1 = quantityDropped(world.rand);
        for(int j1 = 0; j1 < i1; j1++)
        {
            if(world.rand.nextFloat() > f)
            {
                continue;
            }
            int k1 = idDropped(l, world.rand);
            if(k1 > 0)
            {
                /*float f1 = 0.7F;
                double d = (double)(world.rand.nextFloat() * f1) + (double)(1.0F - f1) * 0.5D;
                double d1 = (double)(world.rand.nextFloat() * f1) + (double)(1.0F - f1) * 0.5D;
                double d2 = (double)(world.rand.nextFloat() * f1) + (double)(1.0F - f1) * 0.5D;
                EntityItem entityitem = new EntityItem(world, (double)i + d, (double)j + d1, (double)k + d2, new ItemStack(k1));
                entityitem.delayBeforeCanPickup = 10;
                world.entityJoinedWorld(entityitem);*/
            	dropBlockAsItem_do(world, i, j, k, new ItemStack(k1, 1, damageDropped(l)));
            }
        }

    }
    
    public void dropBlockGoldTouch(World world, int x, int y, int z, int damage, float f)
    {
        if(world.multiplayerWorld)
        {
            return;
        }
        int i1 = 1;//quantityDropped(world.rand);
        for(int j1 = 0; j1 < i1; j1++)
        {
            if(world.rand.nextFloat() > f)
            {
                continue;
            }
            int id = blockID;/*idDropped(l, world.rand);*/
            if(id > 0 && id != crops.blockID && id != signPost.blockID && id != pressurePlateWoodIdle.blockID && id != doorWood.blockID && id != doorSteel.blockID && id != lightBulbOn.blockID && id != pyramidion.blockID)
            {
                /*float f1 = 0.7F;
                double d = (double)(world.rand.nextFloat() * f1) + (double)(1.0F - f1) * 0.5D;
                double d1 = (double)(world.rand.nextFloat() * f1) + (double)(1.0F - f1) * 0.5D;
                double d2 = (double)(world.rand.nextFloat() * f1) + (double)(1.0F - f1) * 0.5D;
                EntityItem entityitem = new EntityItem(world, (double)i + d, (double)j + d1, (double)k + d2, new ItemStack(k1));
                entityitem.delayBeforeCanPickup = 10;
                world.entityJoinedWorld(entityitem);*/
            	dropBlockAsItem_do(world, x, y, z, new ItemStack(id, 1, damageDropped(damage)));
            }else if(id == crops.blockID || id == signPost.blockID || id == pressurePlateWoodIdle.blockID || id == doorWood.blockID || id == doorSteel.blockID || id == lightBulbOn.blockID){
            	dropBlockAsItem(world, x, y, z, damage);
            }
        }

    }
    
    protected void dropBlockAsItem_do(World world, int i, int j, int k, ItemStack itemstack)
    {
        if(world.multiplayerWorld)
        {
            return;
        } else
        {
            float f = 0.7F;
            double d = (double)(world.rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
            double d1 = (double)(world.rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
            double d2 = (double)(world.rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
            EntityItem entityitem = new EntityItem(world, (double)i + d, (double)j + d1, (double)k + d2, itemstack);
            entityitem.delayBeforeCanPickup = 10;
            world.entityJoinedWorld(entityitem);
            return;
        }
    }
    
    protected int damageDropped(int i)
    {
        return 0;
    }

    public float getExplosionResistance(Entity entity)
    {
        return blockResistance / 5F;
    }

    public MovingObjectPosition collisionRayTrace(World world, int x, int y, int z, Vec3D vec3d, Vec3D vec3d1)
    {
        setBlockBoundsBasedOnState(world, x, y, z);
        vec3d = vec3d.addVector(-x, -y, -z);
        vec3d1 = vec3d1.addVector(-x, -y, -z);
        Vec3D vec3d2 = vec3d.getIntermediateWithXValue(vec3d1, minX);
        Vec3D vec3d3 = vec3d.getIntermediateWithXValue(vec3d1, maxX);
        Vec3D vec3d4 = vec3d.getIntermediateWithYValue(vec3d1, minY);
        Vec3D vec3d5 = vec3d.getIntermediateWithYValue(vec3d1, maxY);
        Vec3D vec3d6 = vec3d.getIntermediateWithZValue(vec3d1, minZ);
        Vec3D vec3d7 = vec3d.getIntermediateWithZValue(vec3d1, maxZ);
        if(!isVecInsideYZBounds(vec3d2))
        {
            vec3d2 = null;
        }
        if(!isVecInsideYZBounds(vec3d3))
        {
            vec3d3 = null;
        }
        if(!isVecInsideXZBounds(vec3d4))
        {
            vec3d4 = null;
        }
        if(!isVecInsideXZBounds(vec3d5))
        {
            vec3d5 = null;
        }
        if(!isVecInsideXYBounds(vec3d6))
        {
            vec3d6 = null;
        }
        if(!isVecInsideXYBounds(vec3d7))
        {
            vec3d7 = null;
        }
        Vec3D vec3d8 = null;
        if(vec3d2 != null && (vec3d8 == null || vec3d.distanceTo(vec3d2) < vec3d.distanceTo(vec3d8)))
        {
            vec3d8 = vec3d2;
        }
        if(vec3d3 != null && (vec3d8 == null || vec3d.distanceTo(vec3d3) < vec3d.distanceTo(vec3d8)))
        {
            vec3d8 = vec3d3;
        }
        if(vec3d4 != null && (vec3d8 == null || vec3d.distanceTo(vec3d4) < vec3d.distanceTo(vec3d8)))
        {
            vec3d8 = vec3d4;
        }
        if(vec3d5 != null && (vec3d8 == null || vec3d.distanceTo(vec3d5) < vec3d.distanceTo(vec3d8)))
        {
            vec3d8 = vec3d5;
        }
        if(vec3d6 != null && (vec3d8 == null || vec3d.distanceTo(vec3d6) < vec3d.distanceTo(vec3d8)))
        {
            vec3d8 = vec3d6;
        }
        if(vec3d7 != null && (vec3d8 == null || vec3d.distanceTo(vec3d7) < vec3d.distanceTo(vec3d8)))
        {
            vec3d8 = vec3d7;
        }
        if(vec3d8 == null)
        {
            return null;
        }
        byte byte0 = -1;
        if(vec3d8 == vec3d2)
        {
            byte0 = 4;
        }
        if(vec3d8 == vec3d3)
        {
            byte0 = 5;
        }
        if(vec3d8 == vec3d4)
        {
            byte0 = 0;
        }
        if(vec3d8 == vec3d5)
        {
            byte0 = 1;
        }
        if(vec3d8 == vec3d6)
        {
            byte0 = 2;
        }
        if(vec3d8 == vec3d7)
        {
            byte0 = 3;
        }
        return new MovingObjectPosition(x, y, z, byte0, vec3d8.addVector(x, y, z));
    }

    private boolean isVecInsideYZBounds(Vec3D vec3d)
    {
        if(vec3d == null)
        {
            return false;
        } else
        {
            return vec3d.yCoord >= minY && vec3d.yCoord <= maxY && vec3d.zCoord >= minZ && vec3d.zCoord <= maxZ;
        }
    }

    private boolean isVecInsideXZBounds(Vec3D vec3d)
    {
        if(vec3d == null)
        {
            return false;
        } else
        {
            return vec3d.xCoord >= minX && vec3d.xCoord <= maxX && vec3d.zCoord >= minZ && vec3d.zCoord <= maxZ;
        }
    }

    private boolean isVecInsideXYBounds(Vec3D vec3d)
    {
        if(vec3d == null)
        {
            return false;
        } else
        {
            return vec3d.xCoord >= minX && vec3d.xCoord <= maxX && vec3d.yCoord >= minY && vec3d.yCoord <= maxY;
        }
    }

    public void onBlockDestroyedByExplosion(World world, int i, int j, int k)
    {
    }

    public int getRenderBlockPass()
    {
        return 0;
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        int l = world.getBlockId(i, j, k);
        return l == 0 || allBlocks[l].blockMaterial.getIsGroundCover();
    }

    public boolean blockActivated(World world, int i, int j, int k, EntityPlayer entityplayer)
    {
        return false;
    }

    public void onEntityWalking(World world, int i, int j, int k, Entity entity)
    {
    }

    public void onBlockPlaced(World world, int i, int j, int k, int l)
    {
    }

    public void onBlockClicked(World world, int i, int j, int k, EntityPlayer entityplayer)
    {
    }

    public void velocityToAddToEntity(World world, int i, int j, int k, Entity entity, Vec3D vec3d)
    {
    }

    public void setBlockBoundsBasedOnState(IBlockAccess iblockaccess, int i, int j, int k)
    {
    }

    public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
    {
        return 0xffffff;
    }

    public boolean isPoweringTo(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        return false;
    }

    public boolean canProvidePower()
    {
        return false;
    }

    public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
    {
    }

    public boolean isIndirectlyPoweringTo(World world, int i, int j, int k, int l)
    {
        return false;
    }

    public void setBlockBoundsForItemRender()
    {
    }

    public void harvestBlock(World world, int i, int j, int k, int l)
    {
        dropBlockAsItem(world, i, j, k, l);
    }

    public boolean canBlockStay(World world, int i, int j, int k)
    {
        return true;
    }
    
    public void applyGearPower(){
    	
    }
    
    public void removeGearPower(){
    	
    }
    
    public boolean isGearPowered(){
    	return false;
    }
    
    public int getConnectedGearsCount(World world, int i, int j, int k){
    	return 0;
    }
    
    public ArrayList<Vec3D> getConnectedGears(World world, int i, int j, int k){
    	ArrayList<Vec3D> blocklist = new ArrayList<Vec3D>();
    	if(world.getBlockId(i - 1, j, k) == Block.gear.blockID){
    		blocklist.add(Vec3D.createVectorHelper(i - 1, j, k));
    	}
    	if(world.getBlockId(i + 1, j, k) == Block.gear.blockID){
    		blocklist.add(Vec3D.createVectorHelper(i + 1, j, k));
    	}
    	if(world.getBlockId(i, j, k - 1) == Block.gear.blockID){
    		blocklist.add(Vec3D.createVectorHelper(i, j, k - 1));
    	}
    	if(world.getBlockId(i, j, k + 1) == Block.gear.blockID){
    		blocklist.add(Vec3D.createVectorHelper(i, j, k + 1));
    	}    	
    	return blocklist;
    }
    
    public ArrayList<Vec3D> getConnectedBlocks(World world, int i, int j, int k){
    	return new ArrayList<Vec3D>();
    }

    static Class<?> _mthclass$(String s)
    {
        try
        {
            return Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }

    public static final StepSound soundPowderFootstep;
    public static final StepSound soundWoodFootstep;
    public static final StepSound soundGravelFootstep;
    public static final StepSound soundGrassFootstep;
    public static final StepSound soundStoneFootstep;
    public static final StepSound soundMetalFootstep;
    public static final StepSound soundGlassFootstep;
    public static final StepSound soundClothFootstep;
    public static final StepSound soundSandFootstep;
    public static final StepSound soundNoFootstep;
    public static final Block allBlocks[];
    public static final boolean tickOnLoad[] = new boolean[256];
    public static final boolean opaqueCubeLookup[] = new boolean[256];
    public static final boolean isBlockContainer[] = new boolean[256];
    public static final int lightOpacity[] = new int[256];
    public static final boolean field_340_s[] = new boolean[256];
    public static final int lightValue[] = new int[256];
    public static final Block stone;
    public static final BlockGrass grass;
    public static final Block dirt;
    public static final Block cobblestone;
    public static final Block planks;
    public static final Block sapling;
    public static final Block bedrock;
    public static final Block waterMoving;
    public static final Block waterStill;
    public static final Block lavaMoving;
    public static final Block lavaStill;
    public static final Block sand;
    public static final Block gravel;
    public static final Block oreGold;
    public static final Block oreIron;
    public static final Block oreCoal;
    public static final Block wood;
    public static final BlockLeaves leaves;
    public static final Block sponge;
    public static final Block glass;
    public static final Block cloth_red;
    public static final Block cloth_orange;
    public static final Block cloth_yellow;
    public static final Block cloth_lime;
    public static final Block cloth_green;
    public static final Block cloth_teal;
    public static final Block cloth_cyan;
    public static final Block cloth_blue;
    public static final Block cloth_indigo;
    public static final Block cloth_violet;
    public static final Block cloth_lilac;
    public static final Block cloth_pink;
    public static final Block cloth_magenta;
    public static final Block cloth_darkgray;
    public static final Block cloth;
    public static final Block cloth_lightgray;
    public static final BlockFlower plantYellow;
    public static final BlockFlower plantRed;
    public static final BlockFlower mushroomBrown;
    public static final BlockFlower mushroomRed;
    public static final Block blockGold;
    public static final Block blockSteel;
    public static final Block stairDouble;
    public static final Block stairSingle;
    public static final Block brick;
    public static final Block tnt;
    public static final Block bookShelf;
    public static final Block cobblestoneMossy;
    public static final Block obsidian;
    public static final Block torchWood;
    public static final BlockFire fire;
    public static final Block mobSpawner;
    public static final Block stairCompact_Wood;
    public static final Block crate;
    public static final Block redstoneWire;
    public static final Block oreDiamond;
    public static final Block blockDiamond;
    public static final Block workbench;
    public static final Block crops;
    public static final Block tilledField;
    public static final Block stoneOvenIdle;
    public static final Block stoneOvenActive;
    public static final Block signPost;
    public static final Block doorWood;
    public static final Block ladder;
    public static final Block minecartTrack;
    public static final Block stairCompactStone;
    public static final Block pressurePlateWoodIdle;
    public static final Block lever;
    public static final Block pressurePlateStone;
    public static final Block doorSteel;
    public static final Block pressurePlateWood;
    public static final Block oreRed;
    public static final Block oreRedstoneGlowing;
    public static final Block torchRedstoneIdle;
    public static final Block torchRedstoneActive;
    public static final Block button;
    public static final Block snow;
    public static final Block ice;
    public static final Block blockSnow;
    public static final Block cactus;
    public static final Block blockClay;
    public static final Block reed;
    public static final Block jukebox;
    public static final Block fence;
    public static final Block gear;
    public static final Block spongeInactive;
    public static final BlockFlower plantBlue;
    public static final Block oreCopper;
    public static final Block motor;
    public static final Block generator;
    public static final Block blockCopper;
    public static final Block brickMossy;
    public static final Block bleedingObsidian;
    public static final Block web;
    public static final Block pressurePlateSteel;
    public static final Block lightBulb;
    public static final Block lightBulbOn;
    public static final Block pyramidion;
    public int blockIndexInTexture;
    public final int blockID;
    protected float blockHardness;
    protected float blockResistance;
    public double minX;
    public double minY;
    public double minZ;
    public double maxX;
    public double maxY;
    public double maxZ;
    public StepSound stepSound;
    public float field_357_bm;
    public final Material blockMaterial;
    public float slipperiness;
    public int blockGearPower = 0;
    public Color primaryColor;
    public Color secondaryColor;

    static 
    {
        soundPowderFootstep = new StepSound("stone", 1.0F, 1.0F);
        soundWoodFootstep = new StepSound("wood", 1.0F, 1.0F);
        soundGravelFootstep = new StepSound("gravel", 1.0F, 1.0F);
        soundGrassFootstep = new StepSound("grass", 1.0F, 1.0F);
        soundStoneFootstep = new StepSound("stone", 1.0F, 1.0F);
        soundMetalFootstep = new StepSound("stone", 1.0F, 1.5F);
        soundGlassFootstep = new StepSoundStone("stone", 1.0F, 1.0F);
        soundClothFootstep = new StepSound("cloth", 1.0F, 1.0F);
        soundSandFootstep = new StepSoundSand("sand", 1.0F, 1.0F);
        soundNoFootstep = new StepSound("stone", 0.0F, 0.0F);
        allBlocks = new Block[256];
        stone = (new BlockStone(1, 1)).setHardness(1.5F).setResistance(10F).setStepSound(soundStoneFootstep);
        grass = (BlockGrass)(new BlockGrass(2)).setHardness(0.6F).setStepSound(soundGrassFootstep);
        dirt = (new BlockDirt(3, 2)).setHardness(0.5F).setStepSound(soundGravelFootstep);
        cobblestone = (new Block(4, 16, Material.rock)).setHardness(2.0F).setResistance(10F).setStepSound(soundStoneFootstep);
        planks = (new Block(5, 4, Material.wood)).setHardness(2.0F).setResistance(5F).setStepSound(soundWoodFootstep);
        sapling = (new BlockSapling(6, 15)).setHardness(0.0F).setStepSound(soundGrassFootstep);
        bedrock = (new Block(7, 17, Material.rock)).setHardness(-1F).setResistance(6000000F).setStepSound(soundStoneFootstep);
        waterMoving = (new BlockFlowing(8, Material.water)).setHardness(100F).setLightOpacity(3).setStepSound(soundNoFootstep);
        waterStill = (new BlockStationary(9, Material.water)).setHardness(100F).setLightOpacity(3).setStepSound(soundNoFootstep);
        lavaMoving = (new BlockFlowing(10, Material.lava)).setHardness(0.0F).setLightValue(1.0F).setLightOpacity(255).setStepSound(soundNoFootstep);
        lavaStill = (new BlockStationary(11, Material.lava)).setHardness(100F).setLightValue(1.0F).setLightOpacity(255).setStepSound(soundNoFootstep);
        sand = (new BlockSand(12, 18)).setHardness(0.5F).setStepSound(soundSandFootstep);
        gravel = (new BlockGravel(13, 19)).setHardness(0.6F).setStepSound(soundGravelFootstep);
        oreGold = (new BlockOre(14, 32)).setHardness(3F).setResistance(5F).setStepSound(soundStoneFootstep);
        oreIron = (new BlockOre(15, 33)).setHardness(3F).setResistance(5F).setStepSound(soundStoneFootstep);
        oreCoal = (new BlockOre(16, 34)).setHardness(3F).setResistance(5F).setStepSound(soundStoneFootstep);
        wood = (new BlockLog(17)).setHardness(2.0F).setStepSound(soundWoodFootstep);
        leaves = (BlockLeaves)(new BlockLeaves(18, 52)).setHardness(0.2F).setLightOpacity(1).setStepSound(soundGrassFootstep);
        sponge = (new BlockSponge(19)).setHardness(0.6F).setStepSound(soundGrassFootstep);
        glass = (new BlockGlass(20, 49, Material.glass, false)).setHardness(0.3F).setStepSound(soundGlassFootstep);
        cloth_red = (new Block(21, 144, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_orange = (new Block(22, 145, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_yellow = (new Block(23, 146, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_lime = (new Block(24, 147, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_green = (new Block(25, 148, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_teal = (new Block(26, 149, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_cyan = (new Block(27, 150, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_blue = (new Block(28, 151, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_indigo = (new Block(29, 152, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_violet = (new Block(30, 153, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_lilac = (new Block(31, 154, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_pink = (new Block(32, 155, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_magenta = (new Block(33, 156, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_darkgray = (new Block(34, 157, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth = (new Block(35, 64, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        cloth_lightgray = (new Block(36, 158, Material.cloth)).setHardness(0.8F).setStepSound(soundClothFootstep);
        plantYellow = (BlockFlower)(new BlockFlower(37, 13)).setHardness(0.0F).setStepSound(soundGrassFootstep);
        plantRed = (BlockFlower)(new BlockFlower(38, 12)).setHardness(0.0F).setStepSound(soundGrassFootstep);
        mushroomBrown = (BlockFlower)(new BlockMushroom(39, 29)).setHardness(0.0F).setStepSound(soundGrassFootstep).setLightValue(0.125F);
        mushroomRed = (BlockFlower)(new BlockMushroom(40, 28)).setHardness(0.0F).setStepSound(soundGrassFootstep);
        blockGold = (new BlockOreBlock(41, 39)).setHardness(3F).setResistance(10F).setStepSound(soundMetalFootstep);
        blockSteel = (new BlockOreBlock(42, 38)).setHardness(5F).setResistance(10F).setStepSound(soundMetalFootstep);
        stairDouble = (new BlockStep(43, true)).setHardness(2.0F).setResistance(10F).setStepSound(soundStoneFootstep);
        stairSingle = (new BlockStep(44, false)).setHardness(2.0F).setResistance(10F).setStepSound(soundStoneFootstep);
        brick = (new Block(45, 7, Material.rock)).setHardness(2.0F).setResistance(10F).setStepSound(soundStoneFootstep);
        tnt = (new BlockTNT(46, 8)).setHardness(0.0F).setStepSound(soundGrassFootstep);
        bookShelf = (new BlockBookshelf(47, 35)).setHardness(1.5F).setStepSound(soundWoodFootstep);
        cobblestoneMossy = (new Block(48, 36, Material.rock)).setHardness(2.0F).setResistance(10F).setStepSound(soundStoneFootstep);
        obsidian = (new BlockObsidian(49, 37)).setHardness(10F).setResistance(2000F).setStepSound(soundStoneFootstep);
        torchWood = (new BlockTorch(50, 80)).setHardness(0.0F).setLightValue(0.9375F).setStepSound(soundWoodFootstep);
        fire = (BlockFire)(new BlockFire(51, 31)).setHardness(0.0F).setLightValue(1.0F).setStepSound(soundWoodFootstep);
        mobSpawner = (new BlockMobSpawner(52, 65)).setHardness(5F).setStepSound(soundMetalFootstep);
        stairCompact_Wood = new BlockStairs(53, planks);
        crate = (new BlockChest(54)).setHardness(2.5F).setStepSound(soundWoodFootstep);
        redstoneWire = (new BlockRedstoneWire(55, 84)).setHardness(0.0F).setStepSound(soundPowderFootstep);
        oreDiamond = (new BlockOre(56, 50)).setHardness(3F).setResistance(5F).setStepSound(soundStoneFootstep);
        blockDiamond = (new BlockOreBlock(57, 40)).setHardness(5F).setResistance(10F).setStepSound(soundMetalFootstep);
        workbench = (new BlockWorkbench(58)).setHardness(2.5F).setStepSound(soundWoodFootstep);
        crops = (new BlockCrops(59, 88)).setHardness(0.0F).setStepSound(soundGrassFootstep);
        tilledField = (new BlockSoil(60)).setHardness(0.6F).setStepSound(soundGravelFootstep);
        stoneOvenIdle = (new BlockFurnace(61, false)).setHardness(3.5F).setStepSound(soundStoneFootstep);
        stoneOvenActive = (new BlockFurnace(62, true)).setHardness(3.5F).setStepSound(soundStoneFootstep).setLightValue(0.875F);
        signPost = (new BlockSign(63, TileEntitySign.class, true)).setHardness(1.0F).setStepSound(soundWoodFootstep);
        doorWood = (new BlockDoor(64, Material.wood)).setHardness(3F).setStepSound(soundWoodFootstep);
        ladder = (new BlockLadder(65, 83)).setHardness(0.4F).setStepSound(soundWoodFootstep);
        minecartTrack = (new BlockMinecartTrack(66, 128)).setHardness(0.7F).setStepSound(soundMetalFootstep);
        stairCompactStone = new BlockStairs(67, cobblestone);
        pressurePlateWoodIdle = (new BlockSign(68, TileEntitySign.class, false)).setHardness(1.0F).setStepSound(soundWoodFootstep);
        lever = (new BlockLever(69, 96)).setHardness(0.5F).setStepSound(soundWoodFootstep);
        pressurePlateStone = (new BlockPressurePlate(70, stone.blockIndexInTexture, EnumMobType.mobs)).setHardness(0.5F).setStepSound(soundStoneFootstep);
        doorSteel = (new BlockDoor(71, Material.iron)).setHardness(5F).setStepSound(soundMetalFootstep);
        pressurePlateWood = (new BlockPressurePlate(72, planks.blockIndexInTexture, EnumMobType.everything)).setHardness(0.5F).setStepSound(soundWoodFootstep);
        oreRed = (new BlockRedstoneOre(73, 51, false)).setHardness(3F).setResistance(5F).setStepSound(soundStoneFootstep);
        oreRedstoneGlowing = (new BlockRedstoneOre(74, 51, true)).setLightValue(0.625F).setHardness(3F).setResistance(5F).setStepSound(soundStoneFootstep);
        torchRedstoneIdle = (new BlockRedstoneTorch(75, 115, false)).setHardness(0.0F).setStepSound(soundWoodFootstep);
        torchRedstoneActive = (new BlockRedstoneTorch(76, 99, true)).setHardness(0.0F).setLightValue(0.5F).setStepSound(soundWoodFootstep);
        button = (new BlockButton(77, stone.blockIndexInTexture)).setHardness(0.5F).setStepSound(soundStoneFootstep);
        snow = (new BlockSnow(78, 66)).setHardness(0.1F).setStepSound(soundClothFootstep);
        ice = (new BlockIce(79, 67)).setHardness(0.5F).setLightOpacity(3).setStepSound(soundGlassFootstep);
        blockSnow = (new BlockSnowBlock(80, 66)).setHardness(0.2F).setStepSound(soundClothFootstep);
        cactus = (new BlockCactus(81, 70)).setHardness(0.4F).setStepSound(soundClothFootstep);
        blockClay = (new BlockClay(82, 72)).setHardness(0.6F).setStepSound(soundGravelFootstep);
        reed = (new BlockReed(83, 73)).setHardness(0.0F).setStepSound(soundGrassFootstep);
        jukebox = (new BlockJukeBox(84, 74)).setHardness(2.0F).setResistance(10F).setStepSound(soundStoneFootstep);
        fence = (new BlockFence(85, 4)).setHardness(2.0F).setResistance(5F).setStepSound(soundWoodFootstep);
        gear = (new BlockGear(86, 62)).setHardness(0.5F).setResistance(5F).setStepSound(soundPowderFootstep);
        spongeInactive = (new BlockSpongeInactive(87)).setHardness(0.6F).setStepSound(soundGrassFootstep);
        plantBlue = (BlockFlower)(new BlockFlower(88, 14)).setHardness(0.0F).setStepSound(soundGrassFootstep);
        oreCopper = (new BlockOre(89, 76)).setHardness(3F).setResistance(5F).setStepSound(soundStoneFootstep);
        motor = (new BlockMotor(90, 113, Material.iron, true, 30)).setHardness(3.5F).setStepSound(soundMetalFootstep).setLightValue(0.875F);
        generator = (new BlockMotor(91, 114, Material.iron, false, -1)).setHardness(3.5F).setStepSound(soundMetalFootstep).setLightValue(0.875F);
        blockCopper = (new BlockOreBlock(92, 176)).setHardness(5F).setResistance(10F).setStepSound(soundMetalFootstep);
        brickMossy = (new Block(93, 77, Material.rock)).setHardness(2.0F).setResistance(10F).setStepSound(soundStoneFootstep);
        bleedingObsidian = (new BlockBleedingObsidian(94, 116)).setHardness(10F).setResistance(2000F).setStepSound(soundStoneFootstep);
        web = (new BlockWeb(95, 11)).setHardness(2F).setStepSound(soundClothFootstep);
        pressurePlateSteel = (new BlockPressurePlate(96, blockSteel.blockIndexInTexture, EnumMobType.players)).setHardness(0.5F).setStepSound(soundMetalFootstep);
        lightBulb = (new BlockLightBulb(97)).setHardness(0.5F).setStepSound(soundGlassFootstep);
        lightBulbOn = (new BlockLightBulb(98)).setHardness(0.5F).setStepSound(soundGlassFootstep).setLightValue(1);
        pyramidion = (new BlockPyramidion(99, 104)).setHardness(0.5F).setStepSound(soundMetalFootstep).setLightValue(1);
        for(int i = 0; i < 256; i++)
        {
            if(allBlocks[i] != null)
            {
                Item.itemsList[i] = new ItemBlock(i - 256);
            }
        }

    }
    
    public void onBlockPlacedBy(World world, int i, int j, int k, EntityLiving entityliving)
    {
    }


	public void goldTouch() {
		//System.out.println("GOLDTOUCH");
		
	}
	
	public void notGoldTouch(){
		
	}

	public int getTextureIndex(int n, int n2, int n3) {
		return getTextureIndex(0);
	}
}
