// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.List;
import net.minecraft.client.Minecraft;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            GuiContainer, ContainerCreative, EntityPlayer, AchievementList, 
//            PlayerController, GuiInventory, Slot, EntityPlayerSP, 
//            InventoryPlayer, ItemStack, Container, FontRenderer, 
//            RenderEngine, GuiButton, GuiAchievements, GuiStats, 
//            InventoryBasic

public class GuiContainerCreative extends GuiContainer
{

    public GuiContainerCreative(EntityPlayer entityplayer)
    {
        super(new ContainerCreative(entityplayer));
        field_35312_g = 0.0F;
        field_35313_h = false;
        entityplayer.craftingInventory = inventorySlots;
        allowUserInput = true;
        entityplayer.addStat(AchievementList.openInventory, 1);
        ySize = 208;
    }

    public void updateScreen()
    {
    	field.updateCursorCounter();
    	
    	if(field.isFocused) {
            Keyboard.enableRepeatEvents(true);
    	} else {
            Keyboard.enableRepeatEvents(false);
    	}
    	
        if(!mc.playerController.func_35640_h())
        {
            mc.displayGuiScreen(new GuiInventory(mc.thePlayer));
        }
    }

    protected void func_35309_a(Slot slot, int i, int j, boolean flag)
    {
        if(slot != null)
        {
            if(slot.inventory == field_35311_f)
            {
                InventoryPlayer inventoryplayer = mc.thePlayer.inventory;
                ItemStack itemstack1 = inventoryplayer.getItemStack();
                ItemStack itemstack4 = slot.getStack();
                if(itemstack1 != null && itemstack4 != null && itemstack1.itemID == itemstack4.itemID)
                {
                    if(j == 0)
                    {
                        if(flag)
                        {
                            itemstack1.stackSize = itemstack1.getMaxStackSize();
                        } else
                        if(itemstack1.stackSize < itemstack1.getMaxStackSize())
                        {
                            itemstack1.stackSize++;
                        }
                    } else
                    if(itemstack1.stackSize <= 1)
                    {
                        inventoryplayer.setItemStack(null);
                    } else
                    {
                        itemstack1.stackSize--;
                    }
                } else
                if(itemstack1 != null)
                {
                    inventoryplayer.setItemStack(null);
                } else
                if(itemstack4 == null)
                {
                    inventoryplayer.setItemStack(null);
                } else
                if(itemstack1 == null || itemstack1.itemID != itemstack4.itemID)
                {
                    inventoryplayer.setItemStack(ItemStack.copyItemStack(itemstack4));
                    ItemStack itemstack2 = inventoryplayer.getItemStack();
                    if(flag)
                    {
                        itemstack2.stackSize = itemstack2.getMaxStackSize();
                    }
                }
            } else
            {
                inventorySlots.slotClick(slot.slotNumber, j, flag, mc.thePlayer);
                ItemStack itemstack = inventorySlots.getSlot(slot.slotNumber).getStack();
                mc.playerController.func_35637_a(itemstack, (slot.slotNumber - inventorySlots.inventorySlots.size()) + 9 + 36);
            }
        } else
        {
            InventoryPlayer inventoryplayer1 = mc.thePlayer.inventory;
            if(inventoryplayer1.getItemStack() != null)
            {
                if(j == 0)
                {
                    mc.thePlayer.dropPlayerItem(inventoryplayer1.getItemStack());
                    mc.playerController.func_35639_a(inventoryplayer1.getItemStack());
                    inventoryplayer1.setItemStack(null);
                }
                if(j == 1)
                {
                    ItemStack itemstack3 = inventoryplayer1.getItemStack().splitStack(1);
                    mc.thePlayer.dropPlayerItem(itemstack3);
                    mc.playerController.func_35639_a(itemstack3);
                    if(inventoryplayer1.getItemStack().stackSize == 0)
                    {
                        inventoryplayer1.setItemStack(null);
                    }
                }
            }
        }
    }

    public void initGui()
    {
    	controlList.clear();
        if(!mc.playerController.func_35640_h())
        {
            mc.displayGuiScreen(new GuiInventory(mc.thePlayer));
        }
        else {
        	String creativebuttontext = "Survival Inventory";
        	int buttonlength = fontRenderer.getStringWidth("Survival Inventory") + 4;
            controlList.add(new GuiButton(0, width / 2 - (buttonlength / 2), height / 2 - 116, buttonlength, 12, creativebuttontext));
            if(!mc.theWorld.multiplayerWorld) {
                controlList.add(new GuiButton(1, 0, 0, 95, 20, "Creative Options"));
            }
        }
        field = new GuiTextField(this, fontRenderer, width / 2 + 5, height / 2 - 100, 79, 10, "");
        field.setMaxStringLength(12);
    }

    protected void drawGuiContainerForegroundLayer()
    {
        fontRenderer.drawString("Item selection", 8, 6, 0x404040);
    }

    public void handleMouseInput()
    {
        super.handleMouseInput();
        int i = Mouse.getEventDWheel();
        if(i != 0)
        {
            int j = (((ContainerCreative)inventorySlots).field_35375_a.size() / 8 - 8) + 1;
            if(i > 0)
            {
                i = 1;
            }
            if(i < 0)
            {
                i = -1;
            }
            field_35312_g -= (double)i / (double)j;
            if(field_35312_g < 0.0F)
            {
                field_35312_g = 0.0F;
            }
            if(field_35312_g > 1.0F)
            {
                field_35312_g = 1.0F;
            }
            ((ContainerCreative)inventorySlots).func_35374_a(field_35312_g);
        }
    }

    public void drawScreen(int i, int j, float f)
    {
        boolean flag = Mouse.isButtonDown(0);
        int k = (width - xSize) / 2;
        int l = (height - ySize) / 2;
        int i1 = k + 155;
        int j1 = l + 17;
        int k1 = i1 + 14;
        int l1 = j1 + 160 + 2;
        if(!field_35314_i && flag && i >= i1 && j >= j1 && i < k1 && j < l1)
        {
            field_35313_h = true;
        }
        if(!flag)
        {
            field_35313_h = false;
        }
        field_35314_i = flag;
        if(field_35313_h)
        {
            field_35312_g = (float)(j - (j1 + 8)) / ((float)(l1 - j1) - 16F);
            if(field_35312_g < 0.0F)
            {
                field_35312_g = 0.0F;
            }
            if(field_35312_g > 1.0F)
            {
                field_35312_g = 1.0F;
            }
            ((ContainerCreative)inventorySlots).func_35374_a(field_35312_g);
        }
        super.drawScreen(i, j, f);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glDisable(2896 /*GL_LIGHTING*/);
    }

    protected void drawGuiContainerBackgroundLayer(float f)
    {
    	GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        int i = mc.renderEngine.getTexture("/gui/allitems.png");
        mc.renderEngine.bindTexture(i);
        int j = (width - xSize) / 2;
        int k = (height - ySize) / 2;
        drawTexturedModalRect(j, k, 0, 0, xSize, ySize);
        int i1 = k + 17;
        int j1 = i1 + 160 + 2;
        
        boolean enoughItemsToScroll = ((ContainerCreative)inventorySlots).field_35375_a.size() > 64;
        float scroll = enoughItemsToScroll ? field_35312_g : 0;
        if(!enoughItemsToScroll) {
            GL11.glColor4f(1.0F - .25F, 1.0F - .25F, 1.0F - .25F, 1.0F);
        }
        drawTexturedModalRect(j + 154, k + 17 + (int)((float)(j1 - i1 - 17) * scroll), 0, 208, 16, 16);
        
        field.drawTextBox();
        if(field.getText().equals("")) {
        	field.drawString(fontRenderer, "Search...", width / 2 + 9, height / 2 - 99, 0xa0a0a0);
        }
    }

    protected void actionPerformed(GuiButton guibutton)
    {
        if(guibutton.id == 0)
        {
        	mc.thePlayer.closeScreen();
        	int x = Mouse.getX();
        	int y = Mouse.getY();
        	mc.displayGuiScreen(new GuiInventory(mc.thePlayer));
        	Mouse.setCursorPosition(x, y);
        } else if (guibutton.id == 1 && mc.playerController.func_35640_h()) {
        	mc.displayGuiScreen(new GuiCreativeControls(mc.thePlayer, 1));
        }
    }

    protected void keyTyped(char c, int i) {
    	if(field.isFocused && i != Keyboard.KEY_ESCAPE) {
            Keyboard.enableRepeatEvents(true);
    		field.textboxKeyTyped(c, i);
        	((ContainerCreative)inventorySlots).updateSlots(field.getText());
        	((ContainerCreative)inventorySlots).func_35374_a(field_35312_g);
    	} else {
            Keyboard.enableRepeatEvents(false);
        	super.keyTyped(c, i);
    	}
    }
    
    protected void mouseClicked(int i, int j, int k)
    {
        super.mouseClicked(i, j, k);
        field.mouseClicked(i, j, k);
    }
    
    static InventoryBasic func_35310_g()
    {
        return field_35311_f;
    }

    private static InventoryBasic field_35311_f = new InventoryBasic("tmp", 72);
    private float field_35312_g;
    private boolean field_35313_h;
    private boolean field_35314_i;
    private GuiTextField field;

}
