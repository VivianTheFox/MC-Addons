Made by Logan
Created for Minecraft Beta 1.8.1
Date Created: January 18th, 2020

================================

The goal of this mod is to try porting the Beta 1.7.3 lighting engine out and plop it into Beta 1.8.1, 
with mixed success in this current iteration of the mod.

Overall. The mod mostly works, albeit with some minor issues that I still need to work out before a full release of this mod.
Most notably the issues I've noticed while testing is that sheep wool, particles, and held items (both in third and first person) do not pay attention to current lighting conditions. Beta 1.8 shifted where a lot of the lighting is processed around to different class files in order to get the new lighting engine working, and I haven't yet figured out every class file that was changed in order for me to flip it back to what it originally was.



TL;DR: I've got most of the lighting engine ported, however certain small elements of it still don't work properly. I recommend using this mod for testing purposes, just to have a bit of fun poking around at Beta with the older lighting engine. 

================================

Note: Feel completely free to use any of my source code I have in here for whatever you want. I have zero idea whether or not I'll pick up this same project later on to finish it, as it is a bit annoying to work on and I've already tired myself out on it :)