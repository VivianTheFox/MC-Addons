Mod made by Logan

Note: This is the laziest mod I've ever thrown together. Expect bugs, glitches, and weird crashes.