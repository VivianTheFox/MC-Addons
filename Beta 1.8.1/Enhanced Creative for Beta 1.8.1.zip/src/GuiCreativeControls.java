package net.minecraft.src;

import java.util.Random;

public class GuiCreativeControls extends GuiScreen {

    public GuiCreativeControls(EntityPlayer entityplayer, int i)
    {
        super();
        StringTranslate stringtranslate = StringTranslate.getInstance();
        screenTitle = stringtranslate.translateKey("World Settings");
        inventoryID = i;
    }

	public boolean doesGuiPauseGame() {
		return false;
	}
	
	public void initGui()
    {
		StringTranslate stringtranslate = StringTranslate.getInstance();
    	String israining = "OFF";
    	if(mc.theWorld.worldInfo.getIsRaining() && !mc.theWorld.worldProvider.isNether) {
    		israining = "ON";
    	}

    	String isthundering = "OFF";
    	if(mc.theWorld.worldInfo.getIsThundering() && !mc.theWorld.worldProvider.isNether) {
    		isthundering = "ON";
    	}
    	
    	boolean flag = !mc.theWorld.worldProvider.hasNoSky;

    	GuiButton daybutton = new GuiButton(0, width / 2 - 100, height / 4, 98, 20, "Day Time");
    	GuiButton nightbutton = new GuiButton(1, width / 2 + 2, height / 4, 98, 20, "Night Time");
    	GuiButton rainbutton = new GuiButton(2, width / 2 - 100, height / 4 + 24, 98, 20, "Rain:" + " " + israining);
    	GuiButton thunderbutton = new GuiButton(3, width / 2 + 2, height / 4 + 24, 98, 20, "Thunder" + " " + isthundering);
    	
    	daybutton.enabled = flag;
    	nightbutton.enabled = flag;
    	rainbutton.enabled = flag;
    	thunderbutton.enabled = flag;
    	
        controlList.add(daybutton);
        controlList.add(nightbutton);
        controlList.add(rainbutton);
        controlList.add(thunderbutton);
        controlList.add(new GuiButton(4, width / 2 - 100, height / 4 + 48, "Back to Inventory"));
    }
	
	protected void goBack() {
		if(inventoryID == 0)
	    	mc.displayGuiScreen(new GuiInventory(mc.thePlayer));
		else if(inventoryID == 1)
	    	mc.displayGuiScreen(new GuiContainerCreative(mc.thePlayer));
	}
	
    protected void actionPerformed(GuiButton guibutton)
    {
    	Random rand = new Random();
    	int time = rand.nextInt(0x29040) + 12000;
    	
    	if(mc.playerController.func_35640_h() && !mc.theWorld.multiplayerWorld)
    	{
            if(guibutton.id == 0)
            {
            	mc.theWorld.worldInfo.setWorldTime(0);
            }
            else if (guibutton.id == 1) {
            	mc.theWorld.worldInfo.setWorldTime(14000);
            }
            else if (guibutton.id == 2) {
            	mc.theWorld.worldInfo.setIsRaining(!mc.theWorld.worldInfo.getIsRaining());
            	if(!mc.theWorld.worldInfo.getIsRaining()) {
            		mc.theWorld.worldInfo.setRainTime(rand.nextInt(0x29040) + 12000);
            		if(mc.theWorld.worldInfo.getIsThundering()) {
                        mc.theWorld.worldInfo.setIsThundering(false);
                		mc.theWorld.worldInfo.setThunderTime(0);
            		}
            	} else 
            	{
            		mc.theWorld.worldInfo.setRainTime(0);
            	}
    	    	mc.displayGuiScreen(new GuiCreativeControls(mc.thePlayer, inventoryID));
            }
            else if (guibutton.id == 3) {
            	mc.theWorld.worldInfo.setIsThundering(!mc.theWorld.worldInfo.getIsThundering());
            	if(!mc.theWorld.worldInfo.getIsThundering()) {
            		mc.theWorld.worldInfo.setThunderTime(time);
            	} else 
            	{
            		if(!mc.theWorld.worldInfo.getIsRaining()) {
                        mc.theWorld.worldInfo.setIsRaining(true);
                		mc.theWorld.worldInfo.setRainTime(time);
            		}
            		mc.theWorld.worldInfo.setThunderTime(0);
            	}
    	    	mc.displayGuiScreen(new GuiCreativeControls(mc.thePlayer, inventoryID));
            }
            else if (guibutton.id == 4) {
            	goBack();
            }
    	} else if(!mc.playerController.func_35640_h()) {
	    	mc.displayGuiScreen(new GuiInventory(mc.thePlayer));
    	}
    }

    public void drawScreen(int i, int j, float f)
    {
        drawDefaultBackground();
        drawCenteredString(fontRenderer, screenTitle, width / 2, height / 4 - 16, 0xffffff);
        super.drawScreen(i, j, f);
    }
    
    private int inventoryID;
    protected String screenTitle;

}
