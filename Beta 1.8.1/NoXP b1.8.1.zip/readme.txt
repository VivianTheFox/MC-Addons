GuiIngame is edited to disable the rendering of the XP bars, as well as to move
the health bar and hunger bar to the level they would've been pre-adventure update

EntityXPOrb is edited by changing the onUpdate() function to immediately delete the XP orb.
So XP still exists within the game, it's just the entity that you'd gain them from no longer
is able to exist.